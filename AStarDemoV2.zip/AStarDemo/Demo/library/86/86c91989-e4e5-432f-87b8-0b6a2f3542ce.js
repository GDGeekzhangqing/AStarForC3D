System.register(["cc", "code-quality:cr", "./AStarNode"], function (_export, _context) {
  "use strict";

  var _cclegacy, _reporterNs, _decorator, Component, AStarNode, E_Node_Type, _dec, _class, _class2, _temp, _crd, ccclass, property, AStarMgr;

  function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

  function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

  function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

  function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

  function _reportPossibleCrUseOfAStarNode(extras) {
    _reporterNs.report("AStarNode", "./AStarNode", _context.meta, extras);
  }

  function _reportPossibleCrUseOfE_Node_Type(extras) {
    _reporterNs.report("E_Node_Type", "./AStarNode", _context.meta, extras);
  }

  _export({
    _dec: void 0,
    _class: void 0,
    _class2: void 0,
    _temp: void 0
  });

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
    }, function (_codeQualityCr) {
      _reporterNs = _codeQualityCr;
    }, function (_AStarNode) {
      AStarNode = _AStarNode.AStarNode;
      E_Node_Type = _AStarNode.E_Node_Type;
    }],
    execute: function () {
      _cclegacy._RF.push({}, "86c91mJ5OVDL4e4C2ovNULO", "AStarMgr", _context.meta);

      _crd = true;
      ccclass = _decorator.ccclass;
      property = _decorator.property; /// <summary>
      /// AStar寻路算法的基本原理就是不停的找自己周围的点，选出一个新的点作为起点再循环的找
      /// 1.寻路消耗公式：
      ///           f(寻路消耗)=g(离起点的距离)+h(离终点的距离)
      /// 2.开启列表：
      /// 每次从新的点找周围的点时，如果周围的点已经在开启列表或者关闭列表中了，我们就不去管它了
      /// 3.关闭列表：
      /// 每次往关闭列表中放点时，我们都应该判断这个点是不是和终点一样，如果是一样证明路径找完了，如果不一样，继续找。
      /// 4.格子对象的父对象   
      /// </summary>

      _export("AStarMgr", AStarMgr = (_dec = ccclass('AStartMgr'), _dec(_class = (_temp = _class2 = /*#__PURE__*/function (_Component) {
        _inherits(AStarMgr, _Component);

        _createClass(AStarMgr, null, [{
          key: "Instance",
          value: function Instance() {
            return this.instance;
          }
          /**
           * 地图的宽
           */

        }]);

        function AStarMgr() {
          var _this;

          _classCallCheck(this, AStarMgr);

          _this = _possibleConstructorReturn(this, _getPrototypeOf(AStarMgr).call(this));
          _this.nodes = new Array();
          _this.openLst = new Array();
          _this.closeLst = new Array();
          _this.path = new Array();
          AStarMgr.instance = _assertThisInitialized(_this);
          return _this;
        }

        _createClass(AStarMgr, [{
          key: "Init",
          value: function Init() {
            //AStarMgr.instance=this;
            console.log("初始化AStarMgr...");
          }
          /**
           * 初始化地图
           * @param w 地图的宽
           * @param h 地图的高
           */

        }, {
          key: "InitMapInfo",
          value: function InitMapInfo(w, h) {
            //根据宽高 创建格子 阻挡的问题 我们可以随机阻挡
            //因为我们现在没有地图相关的数据
            var self = this; //记录宽高

            self.mapW = w;
            self.mapH = h; //声明容器可以装多少个格子
            //self.nodes= new AStarNode[w][h];
            //生成格子

            for (var i = 0; i < w; ++i) {
              //console.log("self.nodes.length:" + self.nodes.length);
              self.nodes[i] = [];

              for (var j = 0; j < h; ++j) {
                //用三目运算符随机生成阻挡格子
                //应该从地图配置表读取生成的
                var nodeObj = new (_crd && AStarNode === void 0 ? (_reportPossibleCrUseOfAStarNode({
                  error: Error()
                }), AStarNode) : AStarNode)(i, j, self.RandomNum(0, 100) < 20 ? (_crd && E_Node_Type === void 0 ? (_reportPossibleCrUseOfE_Node_Type({
                  error: Error()
                }), E_Node_Type) : E_Node_Type).Stop : (_crd && E_Node_Type === void 0 ? (_reportPossibleCrUseOfE_Node_Type({
                  error: Error()
                }), E_Node_Type) : E_Node_Type).Walk);
                self.nodes[i][j] = nodeObj;
              }
            }
          }
          /**
           * 寻路方法
           * @param startPos 开始点
           * @param endPos 结束点
           */

        }, {
          key: "FindPath",
          value: function FindPath(startPos, endPos) {
            var self = this; //实际项目中 传入的点往往是 坐标系中的点
            //我们这里省略换算的步骤 直接认为它是传进来的格子坐标
            //首先判断 传入的两个点 是否合法
            //1.首先 要在地图范围内
            //如果不合法 应该直接 返回null 意味着不能寻路

            if (startPos.x < 0 || startPos.x >= this.mapW || startPos.y < 0 || startPos.y >= this.mapH || endPos.x < 0 || endPos.x >= this.mapW || endPos.y < 0 || endPos.y >= this.mapH) {
              console.log("开始或者结束点在地图格子范围外");
              return null;
            } //2.要不是阻挡
            //得到起点和终点  对应的格子


            var start = self.nodes[startPos.x][startPos.y];
            var end = self.nodes[endPos.x][endPos.y];

            if (start.type == (_crd && E_Node_Type === void 0 ? (_reportPossibleCrUseOfE_Node_Type({
              error: Error()
            }), E_Node_Type) : E_Node_Type).Stop || end.type == (_crd && E_Node_Type === void 0 ? (_reportPossibleCrUseOfE_Node_Type({
              error: Error()
            }), E_Node_Type) : E_Node_Type).Stop) {
              console.log("开始或者结束点是阻挡");
              return null;
            } //清空上一次相关的数据 避免他们影响  这一次的寻路计算
            //清空关闭和开启列表


            self.closeLst = [];
            self.openLst = []; //把开始点放入关闭列表中

            start.father = null;
            start.f = 0;
            start.g = 0;
            start.h = 0;
            self.closeLst.push(start);

            while (true) {
              //从起点开始 找周围的点 并放入开启列表中
              //左上  x-1 y-1
              self.FindNearlyNodeToOpenLst(start.x - 1, start.y - 1, 1.4, start, end); //上 x  y-1

              self.FindNearlyNodeToOpenLst(start.x, start.y - 1, 1, start, end); //右上  x+1 y-1

              self.FindNearlyNodeToOpenLst(start.x + 1, start.y - 1, 1.4, start, end); //左 x-1 y

              self.FindNearlyNodeToOpenLst(start.x - 1, start.y, 1, start, end); //右 x+1 y

              self.FindNearlyNodeToOpenLst(start.x + 1, start.y, 1, start, end); //左下 x-1 y+1

              self.FindNearlyNodeToOpenLst(start.x - 1, start.y + 1, 1.4, start, end); //下 x y+1

              self.FindNearlyNodeToOpenLst(start.x, start.y + 1, 1, start, end); //右下 x+1 y+1

              self.FindNearlyNodeToOpenLst(start.x + 1, start.y + 1, 1.4, start, end); //死路判断  开启列表为空 都还没有找到终点 就认为是死路

              if (self.openLst.length == 0) {
                console.log("死路...");
                return null;
              } //选出开启列表中 寻路消耗最小的点


              self.openLst.sort(self.SortOpenLst);
              console.log("****************");

              for (var i = 0; i < self.openLst.length; ++i) {
                var targetNode = self.openLst[i];
                console.log("点:" + targetNode.x + " ," + targetNode.y + "  :g=" + targetNode.g + "  h=" + targetNode.h + "  f=" + targetNode.f);
              } //放入关闭列表中 然后再从开启列表中移除


              self.closeLst.push(self.openLst[0]); //找得这个点 又变成新的起点 进入下一次寻路计算了

              start = self.openLst[0];
              self.openLst.shift(); //如果这个点已经是终点 那么得到最终结果返回出去
              //如果这个点 不是终点 那么继续寻路

              if (start == end) {
                //找完了 找到路径
                //返回路径
                self.path = [];
                self.path.push(end); //father是空时是找到start点，start点的father就是空

                while (end.father != null) {
                  self.path.push(end.father);
                  end = end.father;
                } //列表翻正得到正确的路径


                self.path.reverse();
                return self.path;
              }
            }
          }
          /**
           * 排序函数
           * @param a 
           * @param b 
           */

        }, {
          key: "SortOpenLst",
          value: function SortOpenLst(a, b) {
            if (a.f > b.f) return 1;else if (a.f == b.f) return 1;else return -1;
          }
          /**
           *  把临近的点放入开启列表中的函数
           * @param x 
           * @param y 
           * @param g 
           * @param father 
           * @param end 
           */

        }, {
          key: "FindNearlyNodeToOpenLst",
          value: function FindNearlyNodeToOpenLst(x, y, g, father, end) {
            var self = this; //边界判断

            if (x < 0 || x >= self.mapW || y < 0 || y >= self.mapH) return; //在范围内 再去取点

            var tempNode = self.nodes[x][y]; //判断这些点 是否是边界 是否是阻挡 是否在开启或者关闭列表 如果都不是 才放入开启列表

            if (tempNode == null || tempNode.type == (_crd && E_Node_Type === void 0 ? (_reportPossibleCrUseOfE_Node_Type({
              error: Error()
            }), E_Node_Type) : E_Node_Type).Stop || self.IsInArray(self.closeLst, tempNode) || self.IsInArray(self.openLst, tempNode)) return; //计算f值
            //f=g+h
            //记录父对象

            tempNode.father = father; //计算g  我离起点的距离  就是我父亲离起点的距离 +我离我父亲的距离

            tempNode.g = father.g + g; //曼哈顿街区算法

            tempNode.h = Math.abs(end.x - tempNode.x) + Math.abs(end.y - tempNode.y);
            tempNode.f = tempNode.g + tempNode.h; //如果通过了上面的合法验证 存放到开启列表中

            self.openLst.push(tempNode);
          }
          /**
           * 是否在数组里
           * @param arr 
           * @param target
           */

        }, {
          key: "IsInArray",
          value: function IsInArray(arr, target) {
            var isExit = false;
            arr.find(function (val) {
              if (val == target) return isExit = true;
            });
            return isExit;
          }
          /**
           * 生成随机数
           * @param min 最小值
           * @param max 最大值
           */

        }, {
          key: "RandomNum",
          value: function RandomNum(min, max) {
            switch (arguments.length) {
              case 1:
                return parseInt((Math.random() * min + 1).toString(), 10);
                break;

              case 2:
                return parseInt((Math.random() * (max - min + 1) + min).toString(), 10);
                break;

              default:
                return 0;
                break;
            }
          }
        }]);

        return AStarMgr;
      }(Component), _class2.instance = null, _temp)) || _class));

      _crd = false;

      _cclegacy._RF.pop();
    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vRDovQ29Db3MzRExzdC9BU3RhckRlbW8vRGVtby9hc3NldHMvc2NyaXB0cy9BU3Rhck1nci50cyJdLCJuYW1lcyI6WyJfZGVjb3JhdG9yIiwiQ29tcG9uZW50IiwiQVN0YXJOb2RlIiwiRV9Ob2RlX1R5cGUiLCJjY2NsYXNzIiwicHJvcGVydHkiLCJBU3Rhck1nciIsImluc3RhbmNlIiwibm9kZXMiLCJBcnJheSIsIm9wZW5Mc3QiLCJjbG9zZUxzdCIsInBhdGgiLCJjb25zb2xlIiwibG9nIiwidyIsImgiLCJzZWxmIiwibWFwVyIsIm1hcEgiLCJpIiwiaiIsIm5vZGVPYmoiLCJSYW5kb21OdW0iLCJTdG9wIiwiV2FsayIsInN0YXJ0UG9zIiwiZW5kUG9zIiwieCIsInkiLCJzdGFydCIsImVuZCIsInR5cGUiLCJmYXRoZXIiLCJmIiwiZyIsInB1c2giLCJGaW5kTmVhcmx5Tm9kZVRvT3BlbkxzdCIsImxlbmd0aCIsInNvcnQiLCJTb3J0T3BlbkxzdCIsInRhcmdldE5vZGUiLCJzaGlmdCIsInJldmVyc2UiLCJhIiwiYiIsInRlbXBOb2RlIiwiSXNJbkFycmF5IiwiTWF0aCIsImFicyIsImFyciIsInRhcmdldCIsImlzRXhpdCIsImZpbmQiLCJ2YWwiLCJtaW4iLCJtYXgiLCJhcmd1bWVudHMiLCJwYXJzZUludCIsInJhbmRvbSIsInRvU3RyaW5nIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFTQSxNQUFBQSxVLE9BQUFBLFU7QUFBWUMsTUFBQUEsUyxPQUFBQSxTOzs7O0FBQ1pDLE1BQUFBLFMsY0FBQUEsUztBQUFXQyxNQUFBQSxXLGNBQUFBLFc7Ozs7OztBQUNaQyxNQUFBQSxPLEdBQXNCSixVLENBQXRCSSxPO0FBQVNDLE1BQUFBLFEsR0FBYUwsVSxDQUFiSyxRLEVBRWpCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzswQkFFYUMsUSxXQURaRixPQUFPLENBQUMsV0FBRCxDOzs7OztxQ0FLK0I7QUFDL0IsbUJBQU8sS0FBS0csUUFBWjtBQUNIO0FBRUQ7Ozs7OztBQThCQSw0QkFBYztBQUFBOztBQUFBOztBQUNWO0FBRFUsZ0JBakJQQyxLQWlCTyxHQWpCYSxJQUFJQyxLQUFKLEVBaUJiO0FBQUEsZ0JBWk5DLE9BWU0sR0FaZ0IsSUFBSUQsS0FBSixFQVloQjtBQUFBLGdCQVBORSxRQU9NLEdBUGlCLElBQUlGLEtBQUosRUFPakI7QUFBQSxnQkFGTkcsSUFFTSxHQUZhLElBQUlILEtBQUosRUFFYjtBQUVWSCxVQUFBQSxRQUFRLENBQUNDLFFBQVQ7QUFGVTtBQUdiOzs7O2lDQUdhO0FBQ1Y7QUFDQU0sWUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksZ0JBQVo7QUFDSDtBQUVEOzs7Ozs7OztzQ0FLbUJDLEMsRUFBR0MsQyxFQUFHO0FBQ3JCO0FBQ0E7QUFFQSxnQkFBSUMsSUFBSSxHQUFHLElBQVgsQ0FKcUIsQ0FNckI7O0FBQ0FBLFlBQUFBLElBQUksQ0FBQ0MsSUFBTCxHQUFZSCxDQUFaO0FBQ0FFLFlBQUFBLElBQUksQ0FBQ0UsSUFBTCxHQUFZSCxDQUFaLENBUnFCLENBVXJCO0FBQ0E7QUFFQTs7QUFDQSxpQkFBSyxJQUFJSSxDQUFTLEdBQUcsQ0FBckIsRUFBd0JBLENBQUMsR0FBR0wsQ0FBNUIsRUFBK0IsRUFBRUssQ0FBakMsRUFBb0M7QUFDaEM7QUFDQUgsY0FBQUEsSUFBSSxDQUFDVCxLQUFMLENBQVdZLENBQVgsSUFBZ0IsRUFBaEI7O0FBQ0EsbUJBQUssSUFBSUMsQ0FBUyxHQUFHLENBQXJCLEVBQXdCQSxDQUFDLEdBQUdMLENBQTVCLEVBQStCLEVBQUVLLENBQWpDLEVBQW9DO0FBQ2hDO0FBQ0E7QUFDQSxvQkFBSUMsT0FBa0IsR0FBRztBQUFBO0FBQUEsNENBQWNGLENBQWQsRUFBaUJDLENBQWpCLEVBQXFCSixJQUFJLENBQUNNLFNBQUwsQ0FBZSxDQUFmLEVBQWtCLEdBQWxCLElBQXlCLEVBQXpCLEdBQThCO0FBQUE7QUFBQSxnREFBWUMsSUFBMUMsR0FBaUQ7QUFBQTtBQUFBLGdEQUFZQyxJQUFsRixDQUF6QjtBQUNBUixnQkFBQUEsSUFBSSxDQUFDVCxLQUFMLENBQVdZLENBQVgsRUFBY0MsQ0FBZCxJQUFtQkMsT0FBbkI7QUFDSDtBQUNKO0FBQ0o7QUFFRDs7Ozs7Ozs7bUNBS2dCSSxRLEVBQWdCQyxNLEVBQWM7QUFDMUMsZ0JBQUlWLElBQUksR0FBRyxJQUFYLENBRDBDLENBRTFDO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7O0FBQ0EsZ0JBQUlTLFFBQVEsQ0FBQ0UsQ0FBVCxHQUFhLENBQWIsSUFBa0JGLFFBQVEsQ0FBQ0UsQ0FBVCxJQUFjLEtBQUtWLElBQXJDLElBQ0FRLFFBQVEsQ0FBQ0csQ0FBVCxHQUFhLENBRGIsSUFDa0JILFFBQVEsQ0FBQ0csQ0FBVCxJQUFjLEtBQUtWLElBRHJDLElBRUFRLE1BQU0sQ0FBQ0MsQ0FBUCxHQUFXLENBRlgsSUFFZ0JELE1BQU0sQ0FBQ0MsQ0FBUCxJQUFZLEtBQUtWLElBRmpDLElBR0FTLE1BQU0sQ0FBQ0UsQ0FBUCxHQUFXLENBSFgsSUFHZ0JGLE1BQU0sQ0FBQ0UsQ0FBUCxJQUFZLEtBQUtWLElBSHJDLEVBRzJDO0FBQ3ZDTixjQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxpQkFBWjtBQUNBLHFCQUFPLElBQVA7QUFDSCxhQWR5QyxDQWUxQztBQUNBOzs7QUFDQSxnQkFBSWdCLEtBQWdCLEdBQUdiLElBQUksQ0FBQ1QsS0FBTCxDQUFXa0IsUUFBUSxDQUFDRSxDQUFwQixFQUF1QkYsUUFBUSxDQUFDRyxDQUFoQyxDQUF2QjtBQUNBLGdCQUFJRSxHQUFjLEdBQUdkLElBQUksQ0FBQ1QsS0FBTCxDQUFXbUIsTUFBTSxDQUFDQyxDQUFsQixFQUFxQkQsTUFBTSxDQUFDRSxDQUE1QixDQUFyQjs7QUFFQSxnQkFBSUMsS0FBSyxDQUFDRSxJQUFOLElBQWM7QUFBQTtBQUFBLDRDQUFZUixJQUExQixJQUFrQ08sR0FBRyxDQUFDQyxJQUFKLElBQVk7QUFBQTtBQUFBLDRDQUFZUixJQUE5RCxFQUFvRTtBQUNoRVgsY0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksWUFBWjtBQUNBLHFCQUFPLElBQVA7QUFDSCxhQXZCeUMsQ0F5QjFDO0FBRUE7OztBQUNBRyxZQUFBQSxJQUFJLENBQUNOLFFBQUwsR0FBZ0IsRUFBaEI7QUFDQU0sWUFBQUEsSUFBSSxDQUFDUCxPQUFMLEdBQWUsRUFBZixDQTdCMEMsQ0ErQjFDOztBQUNBb0IsWUFBQUEsS0FBSyxDQUFDRyxNQUFOLEdBQWUsSUFBZjtBQUNBSCxZQUFBQSxLQUFLLENBQUNJLENBQU4sR0FBVSxDQUFWO0FBQ0FKLFlBQUFBLEtBQUssQ0FBQ0ssQ0FBTixHQUFVLENBQVY7QUFDQUwsWUFBQUEsS0FBSyxDQUFDZCxDQUFOLEdBQVUsQ0FBVjtBQUNBQyxZQUFBQSxJQUFJLENBQUNOLFFBQUwsQ0FBY3lCLElBQWQsQ0FBbUJOLEtBQW5COztBQUVBLG1CQUFPLElBQVAsRUFBYTtBQUNUO0FBQ0E7QUFDQWIsY0FBQUEsSUFBSSxDQUFDb0IsdUJBQUwsQ0FBNkJQLEtBQUssQ0FBQ0YsQ0FBTixHQUFVLENBQXZDLEVBQTBDRSxLQUFLLENBQUNELENBQU4sR0FBVSxDQUFwRCxFQUF1RCxHQUF2RCxFQUE0REMsS0FBNUQsRUFBbUVDLEdBQW5FLEVBSFMsQ0FLVDs7QUFDQWQsY0FBQUEsSUFBSSxDQUFDb0IsdUJBQUwsQ0FBNkJQLEtBQUssQ0FBQ0YsQ0FBbkMsRUFBc0NFLEtBQUssQ0FBQ0QsQ0FBTixHQUFVLENBQWhELEVBQW1ELENBQW5ELEVBQXNEQyxLQUF0RCxFQUE2REMsR0FBN0QsRUFOUyxDQVFUOztBQUNBZCxjQUFBQSxJQUFJLENBQUNvQix1QkFBTCxDQUE2QlAsS0FBSyxDQUFDRixDQUFOLEdBQVUsQ0FBdkMsRUFBMENFLEtBQUssQ0FBQ0QsQ0FBTixHQUFVLENBQXBELEVBQXVELEdBQXZELEVBQTREQyxLQUE1RCxFQUFtRUMsR0FBbkUsRUFUUyxDQVdUOztBQUNBZCxjQUFBQSxJQUFJLENBQUNvQix1QkFBTCxDQUE2QlAsS0FBSyxDQUFDRixDQUFOLEdBQVUsQ0FBdkMsRUFBMENFLEtBQUssQ0FBQ0QsQ0FBaEQsRUFBbUQsQ0FBbkQsRUFBc0RDLEtBQXRELEVBQTZEQyxHQUE3RCxFQVpTLENBY1Q7O0FBQ0FkLGNBQUFBLElBQUksQ0FBQ29CLHVCQUFMLENBQTZCUCxLQUFLLENBQUNGLENBQU4sR0FBVSxDQUF2QyxFQUEwQ0UsS0FBSyxDQUFDRCxDQUFoRCxFQUFtRCxDQUFuRCxFQUFzREMsS0FBdEQsRUFBNkRDLEdBQTdELEVBZlMsQ0FpQlQ7O0FBQ0FkLGNBQUFBLElBQUksQ0FBQ29CLHVCQUFMLENBQTZCUCxLQUFLLENBQUNGLENBQU4sR0FBVSxDQUF2QyxFQUEwQ0UsS0FBSyxDQUFDRCxDQUFOLEdBQVUsQ0FBcEQsRUFBdUQsR0FBdkQsRUFBNERDLEtBQTVELEVBQW1FQyxHQUFuRSxFQWxCUyxDQW9CVDs7QUFDQWQsY0FBQUEsSUFBSSxDQUFDb0IsdUJBQUwsQ0FBNkJQLEtBQUssQ0FBQ0YsQ0FBbkMsRUFBc0NFLEtBQUssQ0FBQ0QsQ0FBTixHQUFVLENBQWhELEVBQW1ELENBQW5ELEVBQXNEQyxLQUF0RCxFQUE2REMsR0FBN0QsRUFyQlMsQ0F1QlQ7O0FBQ0FkLGNBQUFBLElBQUksQ0FBQ29CLHVCQUFMLENBQTZCUCxLQUFLLENBQUNGLENBQU4sR0FBVSxDQUF2QyxFQUEwQ0UsS0FBSyxDQUFDRCxDQUFOLEdBQVUsQ0FBcEQsRUFBdUQsR0FBdkQsRUFBNERDLEtBQTVELEVBQW1FQyxHQUFuRSxFQXhCUyxDQTBCVDs7QUFDQSxrQkFBSWQsSUFBSSxDQUFDUCxPQUFMLENBQWE0QixNQUFiLElBQXVCLENBQTNCLEVBQThCO0FBQzFCekIsZ0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVo7QUFDQSx1QkFBTyxJQUFQO0FBQ0gsZUE5QlEsQ0FnQ1Q7OztBQUNBRyxjQUFBQSxJQUFJLENBQUNQLE9BQUwsQ0FBYTZCLElBQWIsQ0FBa0J0QixJQUFJLENBQUN1QixXQUF2QjtBQUNBM0IsY0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksa0JBQVo7O0FBQ0EsbUJBQUssSUFBSU0sQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR0gsSUFBSSxDQUFDUCxPQUFMLENBQWE0QixNQUFqQyxFQUF5QyxFQUFFbEIsQ0FBM0MsRUFBOEM7QUFDMUMsb0JBQUlxQixVQUFVLEdBQUd4QixJQUFJLENBQUNQLE9BQUwsQ0FBYVUsQ0FBYixDQUFqQjtBQUNBUCxnQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBTzJCLFVBQVUsQ0FBQ2IsQ0FBbEIsR0FBc0IsSUFBdEIsR0FBNkJhLFVBQVUsQ0FBQ1osQ0FBeEMsR0FBNEMsT0FBNUMsR0FBc0RZLFVBQVUsQ0FBQ04sQ0FBakUsR0FBcUUsTUFBckUsR0FBOEVNLFVBQVUsQ0FBQ3pCLENBQXpGLEdBQTZGLE1BQTdGLEdBQXNHeUIsVUFBVSxDQUFDUCxDQUE3SDtBQUNILGVBdENRLENBd0NUOzs7QUFDQWpCLGNBQUFBLElBQUksQ0FBQ04sUUFBTCxDQUFjeUIsSUFBZCxDQUFtQm5CLElBQUksQ0FBQ1AsT0FBTCxDQUFhLENBQWIsQ0FBbkIsRUF6Q1MsQ0EwQ1Q7O0FBQ0FvQixjQUFBQSxLQUFLLEdBQUdiLElBQUksQ0FBQ1AsT0FBTCxDQUFhLENBQWIsQ0FBUjtBQUNBTyxjQUFBQSxJQUFJLENBQUNQLE9BQUwsQ0FBYWdDLEtBQWIsR0E1Q1MsQ0E2Q1Q7QUFDQTs7QUFDQSxrQkFBSVosS0FBSyxJQUFJQyxHQUFiLEVBQWtCO0FBQ2Q7QUFDQTtBQUNBZCxnQkFBQUEsSUFBSSxDQUFDTCxJQUFMLEdBQVksRUFBWjtBQUNBSyxnQkFBQUEsSUFBSSxDQUFDTCxJQUFMLENBQVV3QixJQUFWLENBQWVMLEdBQWYsRUFKYyxDQUtkOztBQUNBLHVCQUFPQSxHQUFHLENBQUNFLE1BQUosSUFBYyxJQUFyQixFQUEyQjtBQUN2QmhCLGtCQUFBQSxJQUFJLENBQUNMLElBQUwsQ0FBVXdCLElBQVYsQ0FBZUwsR0FBRyxDQUFDRSxNQUFuQjtBQUNBRixrQkFBQUEsR0FBRyxHQUFHQSxHQUFHLENBQUNFLE1BQVY7QUFDSCxpQkFUYSxDQVdkOzs7QUFDQWhCLGdCQUFBQSxJQUFJLENBQUNMLElBQUwsQ0FBVStCLE9BQVY7QUFDQSx1QkFBTzFCLElBQUksQ0FBQ0wsSUFBWjtBQUNIO0FBQ0o7QUFDSjtBQUVEOzs7Ozs7OztzQ0FLb0JnQyxDLEVBQUdDLEMsRUFBUTtBQUMzQixnQkFBSUQsQ0FBQyxDQUFDVixDQUFGLEdBQU1XLENBQUMsQ0FBQ1gsQ0FBWixFQUNJLE9BQU8sQ0FBUCxDQURKLEtBRUssSUFBSVUsQ0FBQyxDQUFDVixDQUFGLElBQU9XLENBQUMsQ0FBQ1gsQ0FBYixFQUNELE9BQU8sQ0FBUCxDQURDLEtBR0QsT0FBTyxDQUFDLENBQVI7QUFDUDtBQUdEOzs7Ozs7Ozs7OztrREFRZ0NOLEMsRUFBR0MsQyxFQUFHTSxDLEVBQUdGLE0sRUFBUUYsRyxFQUFLO0FBRWxELGdCQUFJZCxJQUFJLEdBQUcsSUFBWCxDQUZrRCxDQUlsRDs7QUFDQSxnQkFBSVcsQ0FBQyxHQUFHLENBQUosSUFBU0EsQ0FBQyxJQUFJWCxJQUFJLENBQUNDLElBQW5CLElBQ0FXLENBQUMsR0FBRyxDQURKLElBQ1NBLENBQUMsSUFBSVosSUFBSSxDQUFDRSxJQUR2QixFQUVJLE9BUDhDLENBU2xEOztBQUNBLGdCQUFJMkIsUUFBUSxHQUFHN0IsSUFBSSxDQUFDVCxLQUFMLENBQVdvQixDQUFYLEVBQWNDLENBQWQsQ0FBZixDQVZrRCxDQVdsRDs7QUFDQSxnQkFBSWlCLFFBQVEsSUFBSSxJQUFaLElBQ0FBLFFBQVEsQ0FBQ2QsSUFBVCxJQUFpQjtBQUFBO0FBQUEsNENBQVlSLElBRDdCLElBRUFQLElBQUksQ0FBQzhCLFNBQUwsQ0FBZTlCLElBQUksQ0FBQ04sUUFBcEIsRUFBOEJtQyxRQUE5QixDQUZBLElBR0E3QixJQUFJLENBQUM4QixTQUFMLENBQWU5QixJQUFJLENBQUNQLE9BQXBCLEVBQTZCb0MsUUFBN0IsQ0FISixFQUlJLE9BaEI4QyxDQWtCbEQ7QUFDQTtBQUNBOztBQUNBQSxZQUFBQSxRQUFRLENBQUNiLE1BQVQsR0FBa0JBLE1BQWxCLENBckJrRCxDQXNCbEQ7O0FBQ0FhLFlBQUFBLFFBQVEsQ0FBQ1gsQ0FBVCxHQUFhRixNQUFNLENBQUNFLENBQVAsR0FBV0EsQ0FBeEIsQ0F2QmtELENBd0JsRDs7QUFDQVcsWUFBQUEsUUFBUSxDQUFDOUIsQ0FBVCxHQUFhZ0MsSUFBSSxDQUFDQyxHQUFMLENBQVNsQixHQUFHLENBQUNILENBQUosR0FBUWtCLFFBQVEsQ0FBQ2xCLENBQTFCLElBQStCb0IsSUFBSSxDQUFDQyxHQUFMLENBQVNsQixHQUFHLENBQUNGLENBQUosR0FBUWlCLFFBQVEsQ0FBQ2pCLENBQTFCLENBQTVDO0FBQ0FpQixZQUFBQSxRQUFRLENBQUNaLENBQVQsR0FBYVksUUFBUSxDQUFDWCxDQUFULEdBQWFXLFFBQVEsQ0FBQzlCLENBQW5DLENBMUJrRCxDQTRCbEQ7O0FBQ0FDLFlBQUFBLElBQUksQ0FBQ1AsT0FBTCxDQUFhMEIsSUFBYixDQUFrQlUsUUFBbEI7QUFDSDtBQUVEOzs7Ozs7OztvQ0FLa0JJLEcsRUFBaUJDLE0sRUFBaUI7QUFFaEQsZ0JBQUlDLE1BQWUsR0FBRyxLQUF0QjtBQUVBRixZQUFBQSxHQUFHLENBQUNHLElBQUosQ0FBUyxVQUFVQyxHQUFWLEVBQWU7QUFDcEIsa0JBQUlBLEdBQUcsSUFBSUgsTUFBWCxFQUNJLE9BQU9DLE1BQU0sR0FBRyxJQUFoQjtBQUNQLGFBSEQ7QUFLQSxtQkFBT0EsTUFBUDtBQUNIO0FBR0Q7Ozs7Ozs7O29DQUtrQkcsRyxFQUFhQyxHLEVBQWE7QUFDeEMsb0JBQVFDLFNBQVMsQ0FBQ25CLE1BQWxCO0FBQ0ksbUJBQUssQ0FBTDtBQUNJLHVCQUFPb0IsUUFBUSxDQUFDLENBQUNWLElBQUksQ0FBQ1csTUFBTCxLQUFnQkosR0FBaEIsR0FBc0IsQ0FBdkIsRUFBMEJLLFFBQTFCLEVBQUQsRUFBdUMsRUFBdkMsQ0FBZjtBQUNBOztBQUNKLG1CQUFLLENBQUw7QUFDSSx1QkFBT0YsUUFBUSxDQUFDLENBQUNWLElBQUksQ0FBQ1csTUFBTCxNQUFpQkgsR0FBRyxHQUFHRCxHQUFOLEdBQVksQ0FBN0IsSUFBa0NBLEdBQW5DLEVBQXdDSyxRQUF4QyxFQUFELEVBQXFELEVBQXJELENBQWY7QUFDQTs7QUFDSjtBQUNJLHVCQUFPLENBQVA7QUFDQTtBQVRSO0FBV0g7Ozs7UUF0UnlCM0QsUyxXQUVYTSxRLEdBQXFCLEkiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBfZGVjb3JhdG9yLCBDb21wb25lbnQsIE5vZGUsIFZlYzMsIFZlYzIsIGFuaW1hdGlvbiB9IGZyb20gJ2NjJztcclxuaW1wb3J0IHsgQVN0YXJOb2RlLCBFX05vZGVfVHlwZSB9IGZyb20gJy4vQVN0YXJOb2RlJztcclxuY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gX2RlY29yYXRvcjtcclxuXHJcbi8vLyA8c3VtbWFyeT5cclxuLy8vIEFTdGFy5a+76Lev566X5rOV55qE5Z+65pys5Y6f55CG5bCx5piv5LiN5YGc55qE5om+6Ieq5bex5ZGo5Zu055qE54K577yM6YCJ5Ye65LiA5Liq5paw55qE54K55L2c5Li66LW354K55YaN5b6q546v55qE5om+XHJcbi8vLyAxLuWvu+i3r+a2iOiAl+WFrOW8j++8mlxyXG4vLy8gICAgICAgICAgIGYo5a+76Lev5raI6ICXKT1nKOemu+i1t+eCueeahOi3neemuykraCjnprvnu4jngrnnmoTot53nprspXHJcbi8vLyAyLuW8gOWQr+WIl+ihqO+8mlxyXG4vLy8g5q+P5qyh5LuO5paw55qE54K55om+5ZGo5Zu055qE54K55pe277yM5aaC5p6c5ZGo5Zu055qE54K55bey57uP5Zyo5byA5ZCv5YiX6KGo5oiW6ICF5YWz6Zet5YiX6KGo5Lit5LqG77yM5oiR5Lus5bCx5LiN5Y67566h5a6D5LqGXHJcbi8vLyAzLuWFs+mXreWIl+ihqO+8mlxyXG4vLy8g5q+P5qyh5b6A5YWz6Zet5YiX6KGo5Lit5pS+54K55pe277yM5oiR5Lus6YO95bqU6K+l5Yik5pat6L+Z5Liq54K55piv5LiN5piv5ZKM57uI54K55LiA5qC377yM5aaC5p6c5piv5LiA5qC36K+B5piO6Lev5b6E5om+5a6M5LqG77yM5aaC5p6c5LiN5LiA5qC377yM57un57ut5om+44CCXHJcbi8vLyA0LuagvOWtkOWvueixoeeahOeItuWvueixoSAgIFxyXG4vLy8gPC9zdW1tYXJ5PlxyXG5AY2NjbGFzcygnQVN0YXJ0TWdyJylcclxuZXhwb3J0IGNsYXNzIEFTdGFyTWdyIGV4dGVuZHMgQ29tcG9uZW50IHtcclxuXHJcbiAgICBwcml2YXRlIHN0YXRpYyBpbnN0YW5jZTogQVN0YXJNZ3IgPSBudWxsO1xyXG5cclxuICAgIHB1YmxpYyBzdGF0aWMgSW5zdGFuY2UoKTogQVN0YXJNZ3Ige1xyXG4gICAgICAgIHJldHVybiB0aGlzLmluc3RhbmNlO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICog5Zyw5Zu+55qE5a69XHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgbWFwVzogbnVtYmVyO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICog5Zyw5Zu+55qE6auYXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgbWFwSDogbnVtYmVyO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICog5Zyw5Zu+55u45YWz5omA5pyJ55qE5qC85a2Q5a+56LGh5a655ZmoXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBub2RlczogQXJyYXk8YW55PiA9IG5ldyBBcnJheTxhbnk+KCk7XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiDlvIDlkK/liJfooahcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBvcGVuTHN0OiBBcnJheTxhbnk+ID0gbmV3IEFycmF5PGFueT4oKTtcclxuXHJcbiAgICAvKipcclxuICAgICAqICDlhbPpl63liJfooahcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBjbG9zZUxzdDogQXJyYXk8YW55PiA9IG5ldyBBcnJheTxhbnk+KCk7XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiDot6/lvoRcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBwYXRoOiBBcnJheTxhbnk+ID0gbmV3IEFycmF5PGFueT4oKTtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcigpIHtcclxuICAgICAgICBzdXBlcigpO1xyXG4gICAgICAgIEFTdGFyTWdyLmluc3RhbmNlID0gdGhpcztcclxuICAgIH1cclxuXHJcblxyXG4gICAgcHVibGljIEluaXQoKSB7XHJcbiAgICAgICAgLy9BU3Rhck1nci5pbnN0YW5jZT10aGlzO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwi5Yid5aeL5YyWQVN0YXJNZ3IuLi5cIik7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiDliJ3lp4vljJblnLDlm75cclxuICAgICAqIEBwYXJhbSB3IOWcsOWbvueahOWuvVxyXG4gICAgICogQHBhcmFtIGgg5Zyw5Zu+55qE6auYXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBJbml0TWFwSW5mbyh3LCBoKSB7XHJcbiAgICAgICAgLy/moLnmja7lrr3pq5gg5Yib5bu65qC85a2QIOmYu+aMoeeahOmXrumimCDmiJHku6zlj6/ku6Xpmo/mnLrpmLvmjKFcclxuICAgICAgICAvL+WboOS4uuaIkeS7rOeOsOWcqOayoeacieWcsOWbvuebuOWFs+eahOaVsOaNrlxyXG5cclxuICAgICAgICBsZXQgc2VsZiA9IHRoaXM7XHJcblxyXG4gICAgICAgIC8v6K6w5b2V5a696auYXHJcbiAgICAgICAgc2VsZi5tYXBXID0gdztcclxuICAgICAgICBzZWxmLm1hcEggPSBoO1xyXG5cclxuICAgICAgICAvL+WjsOaYjuWuueWZqOWPr+S7peijheWkmuWwkeS4quagvOWtkFxyXG4gICAgICAgIC8vc2VsZi5ub2Rlcz0gbmV3IEFTdGFyTm9kZVt3XVtoXTtcclxuXHJcbiAgICAgICAgLy/nlJ/miJDmoLzlrZBcclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdzsgKytpKSB7XHJcbiAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJzZWxmLm5vZGVzLmxlbmd0aDpcIiArIHNlbGYubm9kZXMubGVuZ3RoKTtcclxuICAgICAgICAgICAgc2VsZi5ub2Rlc1tpXSA9IFtdO1xyXG4gICAgICAgICAgICBmb3IgKGxldCBqOiBudW1iZXIgPSAwOyBqIDwgaDsgKytqKSB7XHJcbiAgICAgICAgICAgICAgICAvL+eUqOS4ieebrui/kOeul+espumaj+acuueUn+aIkOmYu+aMoeagvOWtkFxyXG4gICAgICAgICAgICAgICAgLy/lupTor6Xku47lnLDlm77phY3nva7ooajor7vlj5bnlJ/miJDnmoRcclxuICAgICAgICAgICAgICAgIGxldCBub2RlT2JqOiBBU3Rhck5vZGUgPSBuZXcgQVN0YXJOb2RlKGksIGosIChzZWxmLlJhbmRvbU51bSgwLCAxMDApIDwgMjAgPyBFX05vZGVfVHlwZS5TdG9wIDogRV9Ob2RlX1R5cGUuV2FsaykpO1xyXG4gICAgICAgICAgICAgICAgc2VsZi5ub2Rlc1tpXVtqXSA9IG5vZGVPYmo7ICBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIOWvu+i3r+aWueazlVxyXG4gICAgICogQHBhcmFtIHN0YXJ0UG9zIOW8gOWni+eCuVxyXG4gICAgICogQHBhcmFtIGVuZFBvcyDnu5PmnZ/ngrlcclxuICAgICAqL1xyXG4gICAgcHVibGljIEZpbmRQYXRoKHN0YXJ0UG9zOiBWZWMyLCBlbmRQb3M6IFZlYzIpIHtcclxuICAgICAgICBsZXQgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgLy/lrp7pmYXpobnnm67kuK0g5Lyg5YWl55qE54K55b6A5b6A5pivIOWdkOagh+ezu+S4reeahOeCuVxyXG4gICAgICAgIC8v5oiR5Lus6L+Z6YeM55yB55Wl5o2i566X55qE5q2l6aqkIOebtOaOpeiupOS4uuWug+aYr+S8oOi/m+adpeeahOagvOWtkOWdkOagh1xyXG5cclxuICAgICAgICAvL+mmluWFiOWIpOaWrSDkvKDlhaXnmoTkuKTkuKrngrkg5piv5ZCm5ZCI5rOVXHJcbiAgICAgICAgLy8xLummluWFiCDopoHlnKjlnLDlm77ojIPlm7TlhoVcclxuICAgICAgICAvL+WmguaenOS4jeWQiOazlSDlupTor6Xnm7TmjqUg6L+U5ZuebnVsbCDmhI/lkbPnnYDkuI3og73lr7vot69cclxuICAgICAgICBpZiAoc3RhcnRQb3MueCA8IDAgfHwgc3RhcnRQb3MueCA+PSB0aGlzLm1hcFcgfHxcclxuICAgICAgICAgICAgc3RhcnRQb3MueSA8IDAgfHwgc3RhcnRQb3MueSA+PSB0aGlzLm1hcEggfHxcclxuICAgICAgICAgICAgZW5kUG9zLnggPCAwIHx8IGVuZFBvcy54ID49IHRoaXMubWFwVyB8fFxyXG4gICAgICAgICAgICBlbmRQb3MueSA8IDAgfHwgZW5kUG9zLnkgPj0gdGhpcy5tYXBIKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwi5byA5aeL5oiW6ICF57uT5p2f54K55Zyo5Zyw5Zu+5qC85a2Q6IyD5Zu05aSWXCIpO1xyXG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8yLuimgeS4jeaYr+mYu+aMoVxyXG4gICAgICAgIC8v5b6X5Yiw6LW354K55ZKM57uI54K5ICDlr7nlupTnmoTmoLzlrZBcclxuICAgICAgICBsZXQgc3RhcnQ6IEFTdGFyTm9kZSA9IHNlbGYubm9kZXNbc3RhcnRQb3MueF1bc3RhcnRQb3MueV07XHJcbiAgICAgICAgbGV0IGVuZDogQVN0YXJOb2RlID0gc2VsZi5ub2Rlc1tlbmRQb3MueF1bZW5kUG9zLnldO1xyXG5cclxuICAgICAgICBpZiAoc3RhcnQudHlwZSA9PSBFX05vZGVfVHlwZS5TdG9wIHx8IGVuZC50eXBlID09IEVfTm9kZV9UeXBlLlN0b3ApIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCLlvIDlp4vmiJbogIXnu5PmnZ/ngrnmmK/pmLvmjKFcIik7XHJcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy/muIXnqbrkuIrkuIDmrKHnm7jlhbPnmoTmlbDmja4g6YG/5YWN5LuW5Lus5b2x5ZONICDov5nkuIDmrKHnmoTlr7vot6/orqHnrpdcclxuXHJcbiAgICAgICAgLy/muIXnqbrlhbPpl63lkozlvIDlkK/liJfooahcclxuICAgICAgICBzZWxmLmNsb3NlTHN0ID0gW107XHJcbiAgICAgICAgc2VsZi5vcGVuTHN0ID0gW107XHJcblxyXG4gICAgICAgIC8v5oqK5byA5aeL54K55pS+5YWl5YWz6Zet5YiX6KGo5LitXHJcbiAgICAgICAgc3RhcnQuZmF0aGVyID0gbnVsbDtcclxuICAgICAgICBzdGFydC5mID0gMDtcclxuICAgICAgICBzdGFydC5nID0gMDtcclxuICAgICAgICBzdGFydC5oID0gMDtcclxuICAgICAgICBzZWxmLmNsb3NlTHN0LnB1c2goc3RhcnQpO1xyXG5cclxuICAgICAgICB3aGlsZSAodHJ1ZSkge1xyXG4gICAgICAgICAgICAvL+S7jui1t+eCueW8gOWniyDmib7lkajlm7TnmoTngrkg5bm25pS+5YWl5byA5ZCv5YiX6KGo5LitXHJcbiAgICAgICAgICAgIC8v5bem5LiKICB4LTEgeS0xXHJcbiAgICAgICAgICAgIHNlbGYuRmluZE5lYXJseU5vZGVUb09wZW5Mc3Qoc3RhcnQueCAtIDEsIHN0YXJ0LnkgLSAxLCAxLjQsIHN0YXJ0LCBlbmQpO1xyXG5cclxuICAgICAgICAgICAgLy/kuIogeCAgeS0xXHJcbiAgICAgICAgICAgIHNlbGYuRmluZE5lYXJseU5vZGVUb09wZW5Mc3Qoc3RhcnQueCwgc3RhcnQueSAtIDEsIDEsIHN0YXJ0LCBlbmQpO1xyXG5cclxuICAgICAgICAgICAgLy/lj7PkuIogIHgrMSB5LTFcclxuICAgICAgICAgICAgc2VsZi5GaW5kTmVhcmx5Tm9kZVRvT3BlbkxzdChzdGFydC54ICsgMSwgc3RhcnQueSAtIDEsIDEuNCwgc3RhcnQsIGVuZCk7XHJcblxyXG4gICAgICAgICAgICAvL+W3piB4LTEgeVxyXG4gICAgICAgICAgICBzZWxmLkZpbmROZWFybHlOb2RlVG9PcGVuTHN0KHN0YXJ0LnggLSAxLCBzdGFydC55LCAxLCBzdGFydCwgZW5kKTtcclxuXHJcbiAgICAgICAgICAgIC8v5Y+zIHgrMSB5XHJcbiAgICAgICAgICAgIHNlbGYuRmluZE5lYXJseU5vZGVUb09wZW5Mc3Qoc3RhcnQueCArIDEsIHN0YXJ0LnksIDEsIHN0YXJ0LCBlbmQpO1xyXG5cclxuICAgICAgICAgICAgLy/lt6bkuIsgeC0xIHkrMVxyXG4gICAgICAgICAgICBzZWxmLkZpbmROZWFybHlOb2RlVG9PcGVuTHN0KHN0YXJ0LnggLSAxLCBzdGFydC55ICsgMSwgMS40LCBzdGFydCwgZW5kKTtcclxuXHJcbiAgICAgICAgICAgIC8v5LiLIHggeSsxXHJcbiAgICAgICAgICAgIHNlbGYuRmluZE5lYXJseU5vZGVUb09wZW5Mc3Qoc3RhcnQueCwgc3RhcnQueSArIDEsIDEsIHN0YXJ0LCBlbmQpO1xyXG5cclxuICAgICAgICAgICAgLy/lj7PkuIsgeCsxIHkrMVxyXG4gICAgICAgICAgICBzZWxmLkZpbmROZWFybHlOb2RlVG9PcGVuTHN0KHN0YXJ0LnggKyAxLCBzdGFydC55ICsgMSwgMS40LCBzdGFydCwgZW5kKTtcclxuXHJcbiAgICAgICAgICAgIC8v5q276Lev5Yik5patICDlvIDlkK/liJfooajkuLrnqbog6YO96L+Y5rKh5pyJ5om+5Yiw57uI54K5IOWwseiupOS4uuaYr+atu+i3r1xyXG4gICAgICAgICAgICBpZiAoc2VsZi5vcGVuTHN0Lmxlbmd0aCA9PSAwKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIuatu+i3ry4uLlwiKTtcclxuICAgICAgICAgICAgICAgIHJldHVybiBudWxsO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAvL+mAieWHuuW8gOWQr+WIl+ihqOS4rSDlr7vot6/mtojogJfmnIDlsI/nmoTngrlcclxuICAgICAgICAgICAgc2VsZi5vcGVuTHN0LnNvcnQoc2VsZi5Tb3J0T3BlbkxzdCk7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiKioqKioqKioqKioqKioqKlwiKTtcclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzZWxmLm9wZW5Mc3QubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgICAgIGxldCB0YXJnZXROb2RlID0gc2VsZi5vcGVuTHN0W2ldO1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCLngrk6XCIgKyB0YXJnZXROb2RlLnggKyBcIiAsXCIgKyB0YXJnZXROb2RlLnkgKyBcIiAgOmc9XCIgKyB0YXJnZXROb2RlLmcgKyBcIiAgaD1cIiArIHRhcmdldE5vZGUuaCArIFwiICBmPVwiICsgdGFyZ2V0Tm9kZS5mKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLy/mlL7lhaXlhbPpl63liJfooajkuK0g54S25ZCO5YaN5LuO5byA5ZCv5YiX6KGo5Lit56e76ZmkXHJcbiAgICAgICAgICAgIHNlbGYuY2xvc2VMc3QucHVzaChzZWxmLm9wZW5Mc3RbMF0pO1xyXG4gICAgICAgICAgICAvL+aJvuW+l+i/meS4queCuSDlj4jlj5jmiJDmlrDnmoTotbfngrkg6L+b5YWl5LiL5LiA5qyh5a+76Lev6K6h566X5LqGXHJcbiAgICAgICAgICAgIHN0YXJ0ID0gc2VsZi5vcGVuTHN0WzBdO1xyXG4gICAgICAgICAgICBzZWxmLm9wZW5Mc3Quc2hpZnQoKTtcclxuICAgICAgICAgICAgLy/lpoLmnpzov5nkuKrngrnlt7Lnu4/mmK/nu4jngrkg6YKj5LmI5b6X5Yiw5pyA57uI57uT5p6c6L+U5Zue5Ye65Y67XHJcbiAgICAgICAgICAgIC8v5aaC5p6c6L+Z5Liq54K5IOS4jeaYr+e7iOeCuSDpgqPkuYjnu6fnu63lr7vot69cclxuICAgICAgICAgICAgaWYgKHN0YXJ0ID09IGVuZCkge1xyXG4gICAgICAgICAgICAgICAgLy/mib7lrozkuoYg5om+5Yiw6Lev5b6EXHJcbiAgICAgICAgICAgICAgICAvL+i/lOWbnui3r+W+hFxyXG4gICAgICAgICAgICAgICAgc2VsZi5wYXRoID0gW107XHJcbiAgICAgICAgICAgICAgICBzZWxmLnBhdGgucHVzaChlbmQpO1xyXG4gICAgICAgICAgICAgICAgLy9mYXRoZXLmmK/nqbrml7bmmK/mib7liLBzdGFydOeCue+8jHN0YXJ054K555qEZmF0aGVy5bCx5piv56m6XHJcbiAgICAgICAgICAgICAgICB3aGlsZSAoZW5kLmZhdGhlciAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2VsZi5wYXRoLnB1c2goZW5kLmZhdGhlcik7XHJcbiAgICAgICAgICAgICAgICAgICAgZW5kID0gZW5kLmZhdGhlcjtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAvL+WIl+ihqOe/u+ato+W+l+WIsOato+ehrueahOi3r+W+hFxyXG4gICAgICAgICAgICAgICAgc2VsZi5wYXRoLnJldmVyc2UoKTtcclxuICAgICAgICAgICAgICAgIHJldHVybiBzZWxmLnBhdGg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiDmjpLluo/lh73mlbBcclxuICAgICAqIEBwYXJhbSBhIFxyXG4gICAgICogQHBhcmFtIGIgXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgU29ydE9wZW5Mc3QoYSwgYik6IGFueSB7XHJcbiAgICAgICAgaWYgKGEuZiA+IGIuZilcclxuICAgICAgICAgICAgcmV0dXJuIDE7XHJcbiAgICAgICAgZWxzZSBpZiAoYS5mID09IGIuZilcclxuICAgICAgICAgICAgcmV0dXJuIDE7XHJcbiAgICAgICAgZWxzZVxyXG4gICAgICAgICAgICByZXR1cm4gLTE7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogIOaKiuS4tOi/keeahOeCueaUvuWFpeW8gOWQr+WIl+ihqOS4reeahOWHveaVsFxyXG4gICAgICogQHBhcmFtIHggXHJcbiAgICAgKiBAcGFyYW0geSBcclxuICAgICAqIEBwYXJhbSBnIFxyXG4gICAgICogQHBhcmFtIGZhdGhlciBcclxuICAgICAqIEBwYXJhbSBlbmQgXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgRmluZE5lYXJseU5vZGVUb09wZW5Mc3QoeCwgeSwgZywgZmF0aGVyLCBlbmQpIHtcclxuXHJcbiAgICAgICAgbGV0IHNlbGYgPSB0aGlzO1xyXG5cclxuICAgICAgICAvL+i+ueeVjOWIpOaWrVxyXG4gICAgICAgIGlmICh4IDwgMCB8fCB4ID49IHNlbGYubWFwVyB8fFxyXG4gICAgICAgICAgICB5IDwgMCB8fCB5ID49IHNlbGYubWFwSClcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG5cclxuICAgICAgICAvL+WcqOiMg+WbtOWGhSDlho3ljrvlj5bngrlcclxuICAgICAgICBsZXQgdGVtcE5vZGUgPSBzZWxmLm5vZGVzW3hdW3ldO1xyXG4gICAgICAgIC8v5Yik5pat6L+Z5Lqb54K5IOaYr+WQpuaYr+i+ueeVjCDmmK/lkKbmmK/pmLvmjKEg5piv5ZCm5Zyo5byA5ZCv5oiW6ICF5YWz6Zet5YiX6KGoIOWmguaenOmDveS4jeaYryDmiY3mlL7lhaXlvIDlkK/liJfooahcclxuICAgICAgICBpZiAodGVtcE5vZGUgPT0gbnVsbCB8fFxyXG4gICAgICAgICAgICB0ZW1wTm9kZS50eXBlID09IEVfTm9kZV9UeXBlLlN0b3AgfHxcclxuICAgICAgICAgICAgc2VsZi5Jc0luQXJyYXkoc2VsZi5jbG9zZUxzdCwgdGVtcE5vZGUpIHx8XHJcbiAgICAgICAgICAgIHNlbGYuSXNJbkFycmF5KHNlbGYub3BlbkxzdCwgdGVtcE5vZGUpKVxyXG4gICAgICAgICAgICByZXR1cm47XHJcblxyXG4gICAgICAgIC8v6K6h566XZuWAvFxyXG4gICAgICAgIC8vZj1nK2hcclxuICAgICAgICAvL+iusOW9leeItuWvueixoVxyXG4gICAgICAgIHRlbXBOb2RlLmZhdGhlciA9IGZhdGhlcjtcclxuICAgICAgICAvL+iuoeeul2cgIOaIkeemu+i1t+eCueeahOi3neemuyAg5bCx5piv5oiR54i25Lqy56a76LW354K555qE6Led56a7ICvmiJHnprvmiJHniLbkurLnmoTot53nprtcclxuICAgICAgICB0ZW1wTm9kZS5nID0gZmF0aGVyLmcgKyBnO1xyXG4gICAgICAgIC8v5pu85ZOI6aG/6KGX5Yy6566X5rOVXHJcbiAgICAgICAgdGVtcE5vZGUuaCA9IE1hdGguYWJzKGVuZC54IC0gdGVtcE5vZGUueCkgKyBNYXRoLmFicyhlbmQueSAtIHRlbXBOb2RlLnkpO1xyXG4gICAgICAgIHRlbXBOb2RlLmYgPSB0ZW1wTm9kZS5nICsgdGVtcE5vZGUuaDtcclxuXHJcbiAgICAgICAgLy/lpoLmnpzpgJrov4fkuobkuIrpnaLnmoTlkIjms5Xpqozor4Eg5a2Y5pS+5Yiw5byA5ZCv5YiX6KGo5LitXHJcbiAgICAgICAgc2VsZi5vcGVuTHN0LnB1c2godGVtcE5vZGUpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICog5piv5ZCm5Zyo5pWw57uE6YeMXHJcbiAgICAgKiBAcGFyYW0gYXJyIFxyXG4gICAgICogQHBhcmFtIHRhcmdldFxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIElzSW5BcnJheShhcnI6IEFycmF5PGFueT4sIHRhcmdldCk6IGJvb2xlYW4ge1xyXG5cclxuICAgICAgICBsZXQgaXNFeGl0OiBib29sZWFuID0gZmFsc2U7XHJcblxyXG4gICAgICAgIGFyci5maW5kKGZ1bmN0aW9uICh2YWwpIHtcclxuICAgICAgICAgICAgaWYgKHZhbCA9PSB0YXJnZXQpXHJcbiAgICAgICAgICAgICAgICByZXR1cm4gaXNFeGl0ID0gdHJ1ZTtcclxuICAgICAgICB9KVxyXG5cclxuICAgICAgICByZXR1cm4gaXNFeGl0O1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIOeUn+aIkOmaj+acuuaVsFxyXG4gICAgICogQHBhcmFtIG1pbiDmnIDlsI/lgLxcclxuICAgICAqIEBwYXJhbSBtYXgg5pyA5aSn5YC8XHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgUmFuZG9tTnVtKG1pbjogbnVtYmVyLCBtYXgpOiBudW1iZXIge1xyXG4gICAgICAgIHN3aXRjaCAoYXJndW1lbnRzLmxlbmd0aCkge1xyXG4gICAgICAgICAgICBjYXNlIDE6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gcGFyc2VJbnQoKE1hdGgucmFuZG9tKCkgKiBtaW4gKyAxKS50b1N0cmluZygpLCAxMClcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBjYXNlIDI6XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gcGFyc2VJbnQoKE1hdGgucmFuZG9tKCkgKiAobWF4IC0gbWluICsgMSkgKyBtaW4pLnRvU3RyaW5nKCksIDEwKTtcclxuICAgICAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIDA7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG5cclxufVxyXG4iXX0=