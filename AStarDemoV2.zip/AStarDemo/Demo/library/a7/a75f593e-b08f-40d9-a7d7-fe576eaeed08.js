System.register(["cc", "code-quality:cr", "./AStarNode", "./AStarMgr.js"], function (_export, _context) {
  "use strict";

  var _cclegacy, _reporterNs, _decorator, Component, Node, Material, Vec2, ModelComponent, Vec3, geometry, CameraComponent, systemEvent, SystemEventType, PhysicsSystem, Prefab, instantiate, E_Node_Type, AStarMgr, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _temp, _crd, ccclass, property, TestAStar;

  function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

  function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

  function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

  function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfE_Node_Type(extras) {
    _reporterNs.report("E_Node_Type", "./AStarNode", _context.meta, extras);
  }

  function _reportPossibleCrUseOfAStarMgr(extras) {
    _reporterNs.report("AStarMgr", "./AStarMgr", _context.meta, extras);
  }

  _export({
    _dec: void 0,
    _dec2: void 0,
    _dec3: void 0,
    _dec4: void 0,
    _dec5: void 0,
    _dec6: void 0,
    _dec7: void 0,
    _dec8: void 0,
    _class: void 0,
    _class2: void 0,
    _descriptor: void 0,
    _descriptor2: void 0,
    _descriptor3: void 0,
    _descriptor4: void 0,
    _descriptor5: void 0,
    _descriptor6: void 0,
    _descriptor7: void 0,
    _temp: void 0
  });

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      Material = _cc.Material;
      Vec2 = _cc.Vec2;
      ModelComponent = _cc.ModelComponent;
      Vec3 = _cc.Vec3;
      geometry = _cc.geometry;
      CameraComponent = _cc.CameraComponent;
      systemEvent = _cc.systemEvent;
      SystemEventType = _cc.SystemEventType;
      PhysicsSystem = _cc.PhysicsSystem;
      Prefab = _cc.Prefab;
      instantiate = _cc.instantiate;
    }, function (_codeQualityCr) {
      _reporterNs = _codeQualityCr;
    }, function (_AStarNode) {
      E_Node_Type = _AStarNode.E_Node_Type;
    }, function (_AStarMgrJs) {
      AStarMgr = _AStarMgrJs.AStarMgr;
    }],
    execute: function () {
      _cclegacy._RF.push({}, "a75f5k+sI9A2afX/lduru0I", "TestAStar", _context.meta);

      _crd = true;
      ccclass = _decorator.ccclass;
      property = _decorator.property;

      _export("TestAStar", TestAStar = (_dec = ccclass('TestAStar'), _dec2 = property({
        type: Material
      }), _dec3 = property({
        type: Material
      }), _dec4 = property({
        type: Material
      }), _dec5 = property({
        type: Material
      }), _dec6 = property({
        type: Prefab
      }), _dec7 = property({
        type: CameraComponent
      }), _dec8 = property({
        type: Node
      }), _dec(_class = (_class2 = (_temp = /*#__PURE__*/function (_Component) {
        _inherits(TestAStar, _Component);

        function TestAStar() {
          var _getPrototypeOf2;

          var _this;

          _classCallCheck(this, TestAStar);

          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }

          _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(TestAStar)).call.apply(_getPrototypeOf2, [this].concat(args)));
          _this.beginX = -3;
          _this.beginY = 5;
          _this.offsetX = 2;
          _this.offsetY = -2;
          _this.mapW = 4;
          _this.mapH = 4;

          _initializerDefineProperty(_this, "red", _descriptor, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "yellow", _descriptor2, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "blue", _descriptor3, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "normal", _descriptor4, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "instanObj", _descriptor5, _assertThisInitialized(_this));

          _this.beginPos = new Vec2(-1, 0);
          _this.cubes = new Array();
          _this.lst = new Array();

          _initializerDefineProperty(_this, "mainCamera", _descriptor6, _assertThisInitialized(_this));

          _this.ray = new geometry.ray();

          _initializerDefineProperty(_this, "spawnPos", _descriptor7, _assertThisInitialized(_this));

          _this.strs = [];
          return _this;
        }

        _createClass(TestAStar, [{
          key: "onLoad",
          value: function onLoad() {
            var self = this; //初始化AStarMgr
            //let aStarMgr:AStarMgr=self.node.getComponent('AStarMgr') as AStarMgr;
            //aStarMgr.Init();

            (_crd && AStarMgr === void 0 ? (_reportPossibleCrUseOfAStarMgr({
              error: Error()
            }), AStarMgr) : AStarMgr).Instance().InitMapInfo(self.mapW, self.mapH);

            for (var i = 0; i < self.mapW; ++i) {
              for (var j = 0; j < self.mapH; ++j) {
                //创建一个个立方体
                //let obj =this.node.CreatePrimitive(PrimitiveType.BOX);
                var obj = instantiate(self.instanObj); //设置父对象

                obj.parent = self.spawnPos; //console.log("obj.type is:"+obj);

                obj.position = new Vec3(self.beginX + i * self.offsetX, self.beginY + j * self.offsetY, 0); //console.log("obj.node.position is:"+obj.position);
                //名字

                obj.name = i + "_" + j; //存储立方体到字典容器中

                self.cubes.push(obj); //console.log("self.cubes.length is:"+self.cubes.length);
                //得到格子 判断它是不是阻挡

                var tempNode = (_crd && AStarMgr === void 0 ? (_reportPossibleCrUseOfAStarMgr({
                  error: Error()
                }), AStarMgr) : AStarMgr).Instance().nodes[i][j];

                if (tempNode.type == (_crd && E_Node_Type === void 0 ? (_reportPossibleCrUseOfE_Node_Type({
                  error: Error()
                }), E_Node_Type) : E_Node_Type).Stop) {
                  obj.getComponent(ModelComponent).material = self.red; //console.log("set obj'material:"+obj.getComponent(ModelComponent).material.toString());
                }
              } // console.log("continute for-time is:"+i);

            }
          }
        }, {
          key: "onEnable",
          value: function onEnable() {
            systemEvent.on(SystemEventType.TOUCH_START, this.TestAStar, this); //systemEvent.on(SystemEventType.KEY_DOWN, this.Test, this);
          }
        }, {
          key: "onDisable",
          value: function onDisable() {
            systemEvent.off(SystemEventType.TOUCH_START, this.TestAStar, this); // systemEvent.off(SystemEventType.KEY_UP, this.Test, this);
          }
          /**
           * 测试AStar
           */

        }, {
          key: "TestAStar",
          value: function TestAStar(touch, event) {
            var _this2 = this;

            var self = this; //console.log("Vect.UNIT_X is:"+Vec2.UNIT_X);
            //如果鼠标左键按下
            //进行射线检测

            var info = null; //射线检测完的信息
            //得到屏幕鼠标位置发出去的射线
            //console.log("Click successful!");

            self.mainCamera.screenPointToRay(touch._point.x, touch._point.y, self.ray); //#region  基于物理碰撞器的射线检测

            /* if (PhysicsSystem.instance.raycast(self.ray)) {
                 const r = PhysicsSystem.instance.raycastResults;
                 for (let i = 0; i < r.length; i++) {
                     const item = r[i];
                     console.log("Click obj is:"+item.collider.name);
                 }
             } else {
                  console.log("What are you want to do!");
             }*/
            //#endregion
            //射线检测

            if (PhysicsSystem.instance.raycast(self.ray)) {
              self.ReSetMaterial();
              info = PhysicsSystem.instance.raycastResults;
              console.log("Ray Info is:" + info[0].collider.name.toString()); //清理上一次的路径，把绿色立方体变成白色
              //如果不为空，证明找成功了

              if (self.lst != null) {
                for (var i = 0; i < self.lst.length; ++i) {
                  self.cubes[i].getComponent(ModelComponent).material = self.normal;
                  console.log("Reset self.cubes[i].material...");
                }
              } //console.log("self.beginPos is:"+self.beginPos);
              //console.log("self.beginPos equal new Vec2(-1.00,0.00) is:"+(self.beginPos == new Vec2(-1.00, 0.00)));
              //console.log("self.beginPos.x equal -1 and self.beginPos.y equal 0 is:"+(self.beginPos.x==-1&&self.beginPos.y==0));
              //得到点击到的立方体 才能知道是第几行第几列


              if (self.beginPos.x == -1 && self.beginPos.y == 0) {
                console.log("set beginPos...");
                var strs = info[0].collider.node.name.split('_'); //得到行列位置 就是开始点位置

                self.beginPos = new Vec2(Number(strs[0].toString()), Number(strs[1].toString())); //console.log("set self.beginPos is:" + self.beginPos.toString());
                //把点击到的对象变成黄色

                info[0].collider.node.getComponent(ModelComponent).material = self.yellow;
              } //有起点了 那这就是 来点出终点 进行寻路
              else {
                  console.log("Set endPos..."); //得到终点

                  var _strs = info[0].collider.node.name.split('_');

                  var endPos = new Vec2(Number(_strs[0]), Number(_strs[1]));
                  console.log("endPos is:" + info[0].collider.node.name); //寻路

                  self.lst = (_crd && AStarMgr === void 0 ? (_reportPossibleCrUseOfAStarMgr({
                    error: Error()
                  }), AStarMgr) : AStarMgr).Instance().FindPath(self.beginPos, endPos); //避免死路的时候黄色不变成白色，所以事先清一遍。因为beginPos.x是float类型的所以要转换为int类型
                  //self.cubes[self.beginPos.x][.beginPos.y].getComponent(ModelComponent).material = this.normal;

                  var st = (self.beginPos.x + "_" + self.beginPos.y).toString();
                  self.cubes.forEach(function (element) {
                    if (element.name == st) {
                      //避免死路的时候黄色不变成白色，所以事先清一遍。因为beginPos.x是float类型的所以要转换为int类型
                      element.getComponent(ModelComponent).material = _this2.normal;
                      console.log("self.cubes[beginPos] is:" + element.name);
                    }
                  }); //如果不为空，证明找成功了

                  if (self.lst != null) {
                    var _loop = function _loop(j) {
                      var temp = (self.lst[j].x + "_" + self.lst[j].y).toString();
                      self.cubes.forEach(function (element) {
                        if (element.name == temp) {
                          element.getComponent(ModelComponent).material = self.blue;
                          console.log("打印变色的顺序：" + element.name);
                        }
                      }); // self.cubes[j].getComponent(ModelComponent).material = this.blue;
                      /// console.log("打印路径顺序：" + self.lst[j].x + "_" + self.lst[j].y);
                    };

                    for (var j = 0; j < self.lst.length; ++j) {
                      _loop(j);
                    }
                  } //清除开始点 把它变成初始值


                  self.beginPos = new Vec2(-1, 0);
                }
            }
          }
          /**
           * 重置变成蓝色的对象为Normal
           */

        }, {
          key: "ReSetMaterial",
          value: function ReSetMaterial() {
            var self = this;

            if (self.lst != null) {
              var _loop2 = function _loop2(j) {
                var temp = (self.lst[j].x + "_" + self.lst[j].y).toString();
                self.cubes.forEach(function (element) {
                  if (element.name == temp) {
                    element.getComponent(ModelComponent).material = self.normal;
                    console.log("重置变色的顺序：" + element.name);
                  }
                });
              };

              for (var j = 0; j < self.lst.length; ++j) {
                _loop2(j);
              }
            }
          }
        }]);

        return TestAStar;
      }(Component), _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "red", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "yellow", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "blue", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "normal", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "instanObj", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "mainCamera", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "spawnPos", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      _crd = false;

      _cclegacy._RF.pop();
    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vRDovQ29Db3MzRExzdC9BU3RhckRlbW8vRGVtby9hc3NldHMvc2NyaXB0cy9UZXN0QVN0YXIudHMiXSwibmFtZXMiOlsiX2RlY29yYXRvciIsIkNvbXBvbmVudCIsIk5vZGUiLCJNYXRlcmlhbCIsIlZlYzIiLCJNb2RlbENvbXBvbmVudCIsIlZlYzMiLCJnZW9tZXRyeSIsIkNhbWVyYUNvbXBvbmVudCIsInN5c3RlbUV2ZW50IiwiU3lzdGVtRXZlbnRUeXBlIiwiUGh5c2ljc1N5c3RlbSIsIlByZWZhYiIsImluc3RhbnRpYXRlIiwiRV9Ob2RlX1R5cGUiLCJBU3Rhck1nciIsImNjY2xhc3MiLCJwcm9wZXJ0eSIsIlRlc3RBU3RhciIsInR5cGUiLCJiZWdpblgiLCJiZWdpblkiLCJvZmZzZXRYIiwib2Zmc2V0WSIsIm1hcFciLCJtYXBIIiwiYmVnaW5Qb3MiLCJjdWJlcyIsIkFycmF5IiwibHN0IiwicmF5Iiwic3RycyIsInNlbGYiLCJJbnN0YW5jZSIsIkluaXRNYXBJbmZvIiwiaSIsImoiLCJvYmoiLCJpbnN0YW5PYmoiLCJwYXJlbnQiLCJzcGF3blBvcyIsInBvc2l0aW9uIiwibmFtZSIsInB1c2giLCJ0ZW1wTm9kZSIsIm5vZGVzIiwiU3RvcCIsImdldENvbXBvbmVudCIsIm1hdGVyaWFsIiwicmVkIiwib24iLCJUT1VDSF9TVEFSVCIsIm9mZiIsInRvdWNoIiwiZXZlbnQiLCJpbmZvIiwibWFpbkNhbWVyYSIsInNjcmVlblBvaW50VG9SYXkiLCJfcG9pbnQiLCJ4IiwieSIsImluc3RhbmNlIiwicmF5Y2FzdCIsIlJlU2V0TWF0ZXJpYWwiLCJyYXljYXN0UmVzdWx0cyIsImNvbnNvbGUiLCJsb2ciLCJjb2xsaWRlciIsInRvU3RyaW5nIiwibGVuZ3RoIiwibm9ybWFsIiwibm9kZSIsInNwbGl0IiwiTnVtYmVyIiwieWVsbG93IiwiZW5kUG9zIiwiRmluZFBhdGgiLCJzdCIsImZvckVhY2giLCJlbGVtZW50IiwidGVtcCIsImJsdWUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBU0EsTUFBQUEsVSxPQUFBQSxVO0FBQVlDLE1BQUFBLFMsT0FBQUEsUztBQUFXQyxNQUFBQSxJLE9BQUFBLEk7QUFBTUMsTUFBQUEsUSxPQUFBQSxRO0FBQVVDLE1BQUFBLEksT0FBQUEsSTtBQUFNQyxNQUFBQSxjLE9BQUFBLGM7QUFBZ0JDLE1BQUFBLEksT0FBQUEsSTtBQUFNQyxNQUFBQSxRLE9BQUFBLFE7QUFBVUMsTUFBQUEsZSxPQUFBQSxlO0FBQWlCQyxNQUFBQSxXLE9BQUFBLFc7QUFBYUMsTUFBQUEsZSxPQUFBQSxlO0FBQTZCQyxNQUFBQSxhLE9BQUFBLGE7QUFBaUNDLE1BQUFBLE0sT0FBQUEsTTtBQUFRQyxNQUFBQSxXLE9BQUFBLFc7Ozs7QUFDdEtDLE1BQUFBLFcsY0FBQUEsVzs7QUFDWEMsTUFBQUEsUSxlQUFBQSxROzs7Ozs7QUFDREMsTUFBQUEsTyxHQUFzQmhCLFUsQ0FBdEJnQixPO0FBQVNDLE1BQUFBLFEsR0FBYWpCLFUsQ0FBYmlCLFE7OzJCQUtKQyxTLFdBRFpGLE9BQU8sQ0FBQyxXQUFELEMsVUFpQ0hDLFFBQVEsQ0FBQztBQUFFRSxRQUFBQSxJQUFJLEVBQUVoQjtBQUFSLE9BQUQsQyxVQUdSYyxRQUFRLENBQUM7QUFBRUUsUUFBQUEsSUFBSSxFQUFFaEI7QUFBUixPQUFELEMsVUFHUmMsUUFBUSxDQUFDO0FBQUVFLFFBQUFBLElBQUksRUFBRWhCO0FBQVIsT0FBRCxDLFVBR1JjLFFBQVEsQ0FBQztBQUFFRSxRQUFBQSxJQUFJLEVBQUVoQjtBQUFSLE9BQUQsQyxVQUdSYyxRQUFRLENBQUM7QUFBRUUsUUFBQUEsSUFBSSxFQUFFUDtBQUFSLE9BQUQsQyxVQW1CUkssUUFBUSxDQUFDO0FBQUVFLFFBQUFBLElBQUksRUFBRVg7QUFBUixPQUFELEMsVUFLUlMsUUFBUSxDQUFDO0FBQUVFLFFBQUFBLElBQUksRUFBRWpCO0FBQVIsT0FBRCxDOzs7Ozs7Ozs7Ozs7Ozs7Z0JBL0RGa0IsTSxHQUFTLENBQUMsQztnQkFLVkMsTSxHQUFTLEM7Z0JBS1RDLE8sR0FBVSxDO2dCQUtWQyxPLEdBQVUsQ0FBQyxDO2dCQUtYQyxJLEdBQU8sQztnQkFLUEMsSSxHQUFPLEM7Ozs7Ozs7Ozs7OztnQkFxQk5DLFEsR0FBaUIsSUFBSXRCLElBQUosQ0FBUyxDQUFDLENBQVYsRUFBYSxDQUFiLEM7Z0JBS2pCdUIsSyxHQUFxQixJQUFJQyxLQUFKLEU7Z0JBS3JCQyxHLEdBQXdCLElBQUlELEtBQUosRTs7OztnQkFLeEJFLEcsR0FBb0IsSUFBSXZCLFFBQVEsQ0FBQ3VCLEdBQWIsRTs7OztnQkFRcEJDLEksR0FBaUIsRTs7Ozs7O21DQUdUO0FBQ1osZ0JBQUlDLElBQUksR0FBRyxJQUFYLENBRFksQ0FHWjtBQUNBO0FBQ0E7O0FBR0E7QUFBQTtBQUFBLHNDQUFTQyxRQUFULEdBQW9CQyxXQUFwQixDQUFnQ0YsSUFBSSxDQUFDUixJQUFyQyxFQUEyQ1EsSUFBSSxDQUFDUCxJQUFoRDs7QUFFQSxpQkFBSyxJQUFJVSxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHSCxJQUFJLENBQUNSLElBQXpCLEVBQStCLEVBQUVXLENBQWpDLEVBQW9DO0FBQ2hDLG1CQUFLLElBQUlDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdKLElBQUksQ0FBQ1AsSUFBekIsRUFBK0IsRUFBRVcsQ0FBakMsRUFBb0M7QUFDaEM7QUFDQTtBQUNBLG9CQUFJQyxHQUFHLEdBQUd4QixXQUFXLENBQUNtQixJQUFJLENBQUNNLFNBQU4sQ0FBckIsQ0FIZ0MsQ0FJaEM7O0FBQ0FELGdCQUFBQSxHQUFHLENBQUNFLE1BQUosR0FBYVAsSUFBSSxDQUFDUSxRQUFsQixDQUxnQyxDQU1oQzs7QUFDQUgsZ0JBQUFBLEdBQUcsQ0FBQ0ksUUFBSixHQUFlLElBQUluQyxJQUFKLENBQVMwQixJQUFJLENBQUNaLE1BQUwsR0FBY2UsQ0FBQyxHQUFHSCxJQUFJLENBQUNWLE9BQWhDLEVBQXlDVSxJQUFJLENBQUNYLE1BQUwsR0FBY2UsQ0FBQyxHQUFHSixJQUFJLENBQUNULE9BQWhFLEVBQXlFLENBQXpFLENBQWYsQ0FQZ0MsQ0FRaEM7QUFDQTs7QUFDQWMsZ0JBQUFBLEdBQUcsQ0FBQ0ssSUFBSixHQUFXUCxDQUFDLEdBQUcsR0FBSixHQUFVQyxDQUFyQixDQVZnQyxDQVdoQzs7QUFDQUosZ0JBQUFBLElBQUksQ0FBQ0wsS0FBTCxDQUFXZ0IsSUFBWCxDQUFnQk4sR0FBaEIsRUFaZ0MsQ0FhaEM7QUFFQTs7QUFDQSxvQkFBSU8sUUFBbUIsR0FBRztBQUFBO0FBQUEsMENBQVNYLFFBQVQsR0FBb0JZLEtBQXBCLENBQTBCVixDQUExQixFQUE2QkMsQ0FBN0IsQ0FBMUI7O0FBQ0Esb0JBQUlRLFFBQVEsQ0FBQ3pCLElBQVQsSUFBaUI7QUFBQTtBQUFBLGdEQUFZMkIsSUFBakMsRUFBdUM7QUFDbkNULGtCQUFBQSxHQUFHLENBQUNVLFlBQUosQ0FBaUIxQyxjQUFqQixFQUFpQzJDLFFBQWpDLEdBQTRDaEIsSUFBSSxDQUFDaUIsR0FBakQsQ0FEbUMsQ0FFbkM7QUFDSDtBQUNKLGVBdEIrQixDQXVCaEM7O0FBQ0g7QUFDSjs7O3FDQUdpQjtBQUNkeEMsWUFBQUEsV0FBVyxDQUFDeUMsRUFBWixDQUFleEMsZUFBZSxDQUFDeUMsV0FBL0IsRUFBNEMsS0FBS2pDLFNBQWpELEVBQTRELElBQTVELEVBRGMsQ0FFZDtBQUNIOzs7c0NBR2tCO0FBQ2ZULFlBQUFBLFdBQVcsQ0FBQzJDLEdBQVosQ0FBZ0IxQyxlQUFlLENBQUN5QyxXQUFoQyxFQUE2QyxLQUFLakMsU0FBbEQsRUFBNkQsSUFBN0QsRUFEZSxDQUVmO0FBQ0g7QUFFRDs7Ozs7O29DQUdVbUMsSyxFQUFjQyxLLEVBQW1CO0FBQUE7O0FBRXZDLGdCQUFJdEIsSUFBSSxHQUFHLElBQVgsQ0FGdUMsQ0FJdkM7QUFDQTtBQUVBOztBQUNBLGdCQUFJdUIsSUFBd0IsR0FBRyxJQUEvQixDQVJ1QyxDQVFGO0FBQ3JDO0FBQ0E7O0FBRUF2QixZQUFBQSxJQUFJLENBQUN3QixVQUFMLENBQWdCQyxnQkFBaEIsQ0FBaUNKLEtBQUssQ0FBQ0ssTUFBTixDQUFhQyxDQUE5QyxFQUFpRE4sS0FBSyxDQUFDSyxNQUFOLENBQWFFLENBQTlELEVBQWlFNUIsSUFBSSxDQUFDRixHQUF0RSxFQVp1QyxDQWN2Qzs7QUFFQTs7Ozs7Ozs7O0FBU0E7QUFFQTs7QUFDQSxnQkFBSW5CLGFBQWEsQ0FBQ2tELFFBQWQsQ0FBdUJDLE9BQXZCLENBQStCOUIsSUFBSSxDQUFDRixHQUFwQyxDQUFKLEVBQThDO0FBRzFDRSxjQUFBQSxJQUFJLENBQUMrQixhQUFMO0FBRUFSLGNBQUFBLElBQUksR0FBRzVDLGFBQWEsQ0FBQ2tELFFBQWQsQ0FBdUJHLGNBQTlCO0FBQ0FDLGNBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGlCQUFpQlgsSUFBSSxDQUFDLENBQUQsQ0FBSixDQUFRWSxRQUFSLENBQWlCekIsSUFBakIsQ0FBc0IwQixRQUF0QixFQUE3QixFQU4wQyxDQVExQztBQUNBOztBQUNBLGtCQUFJcEMsSUFBSSxDQUFDSCxHQUFMLElBQVksSUFBaEIsRUFBc0I7QUFDbEIscUJBQUssSUFBSU0sQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR0gsSUFBSSxDQUFDSCxHQUFMLENBQVN3QyxNQUE3QixFQUFxQyxFQUFFbEMsQ0FBdkMsRUFBMEM7QUFDdENILGtCQUFBQSxJQUFJLENBQUNMLEtBQUwsQ0FBV1EsQ0FBWCxFQUFjWSxZQUFkLENBQTJCMUMsY0FBM0IsRUFBMkMyQyxRQUEzQyxHQUFzRGhCLElBQUksQ0FBQ3NDLE1BQTNEO0FBQ0FMLGtCQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxpQ0FBWjtBQUNIO0FBQ0osZUFmeUMsQ0FpQjFDO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSxrQkFBSWxDLElBQUksQ0FBQ04sUUFBTCxDQUFjaUMsQ0FBZCxJQUFtQixDQUFDLENBQXBCLElBQXlCM0IsSUFBSSxDQUFDTixRQUFMLENBQWNrQyxDQUFkLElBQW1CLENBQWhELEVBQW1EO0FBQy9DSyxnQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksaUJBQVo7QUFDQSxvQkFBSW5DLElBQUksR0FBR3dCLElBQUksQ0FBQyxDQUFELENBQUosQ0FBUVksUUFBUixDQUFpQkksSUFBakIsQ0FBc0I3QixJQUF0QixDQUEyQjhCLEtBQTNCLENBQWlDLEdBQWpDLENBQVgsQ0FGK0MsQ0FHL0M7O0FBQ0F4QyxnQkFBQUEsSUFBSSxDQUFDTixRQUFMLEdBQWdCLElBQUl0QixJQUFKLENBQVNxRSxNQUFNLENBQUMxQyxJQUFJLENBQUMsQ0FBRCxDQUFKLENBQVFxQyxRQUFSLEVBQUQsQ0FBZixFQUNWSyxNQUFNLENBQUMxQyxJQUFJLENBQUMsQ0FBRCxDQUFKLENBQVFxQyxRQUFSLEVBQUQsQ0FESSxDQUFoQixDQUorQyxDQU0vQztBQUNBOztBQUNBYixnQkFBQUEsSUFBSSxDQUFDLENBQUQsQ0FBSixDQUFRWSxRQUFSLENBQWlCSSxJQUFqQixDQUFzQnhCLFlBQXRCLENBQW1DMUMsY0FBbkMsRUFBbUQyQyxRQUFuRCxHQUE4RGhCLElBQUksQ0FBQzBDLE1BQW5FO0FBQ0gsZUFURCxDQVVBO0FBVkEsbUJBV0s7QUFDRFQsa0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGVBQVosRUFEQyxDQUVEOztBQUNBLHNCQUFJbkMsS0FBYyxHQUFHd0IsSUFBSSxDQUFDLENBQUQsQ0FBSixDQUFRWSxRQUFSLENBQWlCSSxJQUFqQixDQUFzQjdCLElBQXRCLENBQTJCOEIsS0FBM0IsQ0FBaUMsR0FBakMsQ0FBckI7O0FBQ0Esc0JBQUlHLE1BQVksR0FBRyxJQUFJdkUsSUFBSixDQUFTcUUsTUFBTSxDQUFDMUMsS0FBSSxDQUFDLENBQUQsQ0FBTCxDQUFmLEVBQTBCMEMsTUFBTSxDQUFDMUMsS0FBSSxDQUFDLENBQUQsQ0FBTCxDQUFoQyxDQUFuQjtBQUNBa0Msa0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGVBQWVYLElBQUksQ0FBQyxDQUFELENBQUosQ0FBUVksUUFBUixDQUFpQkksSUFBakIsQ0FBc0I3QixJQUFqRCxFQUxDLENBT0Q7O0FBQ0FWLGtCQUFBQSxJQUFJLENBQUNILEdBQUwsR0FBVztBQUFBO0FBQUEsNENBQVNJLFFBQVQsR0FBb0IyQyxRQUFwQixDQUE2QjVDLElBQUksQ0FBQ04sUUFBbEMsRUFBNENpRCxNQUE1QyxDQUFYLENBUkMsQ0FVRDtBQUNBOztBQUNBLHNCQUFJRSxFQUFVLEdBQUcsQ0FBQzdDLElBQUksQ0FBQ04sUUFBTCxDQUFjaUMsQ0FBZCxHQUFrQixHQUFsQixHQUF3QjNCLElBQUksQ0FBQ04sUUFBTCxDQUFja0MsQ0FBdkMsRUFBMENRLFFBQTFDLEVBQWpCO0FBQ0FwQyxrQkFBQUEsSUFBSSxDQUFDTCxLQUFMLENBQVdtRCxPQUFYLENBQW1CLFVBQUFDLE9BQU8sRUFBSTtBQUMxQix3QkFBSUEsT0FBTyxDQUFDckMsSUFBUixJQUFnQm1DLEVBQXBCLEVBQXdCO0FBQ3BCO0FBQ0FFLHNCQUFBQSxPQUFPLENBQUNoQyxZQUFSLENBQXFCMUMsY0FBckIsRUFBcUMyQyxRQUFyQyxHQUFnRCxNQUFJLENBQUNzQixNQUFyRDtBQUNBTCxzQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksNkJBQTZCYSxPQUFPLENBQUNyQyxJQUFqRDtBQUNIO0FBQ0osbUJBTkQsRUFiQyxDQXFCRDs7QUFDQSxzQkFBSVYsSUFBSSxDQUFDSCxHQUFMLElBQVksSUFBaEIsRUFBc0I7QUFBQSwrQ0FDVE8sQ0FEUztBQUVkLDBCQUFJNEMsSUFBWSxHQUFHLENBQUNoRCxJQUFJLENBQUNILEdBQUwsQ0FBU08sQ0FBVCxFQUFZdUIsQ0FBWixHQUFnQixHQUFoQixHQUFzQjNCLElBQUksQ0FBQ0gsR0FBTCxDQUFTTyxDQUFULEVBQVl3QixDQUFuQyxFQUFzQ1EsUUFBdEMsRUFBbkI7QUFDQXBDLHNCQUFBQSxJQUFJLENBQUNMLEtBQUwsQ0FBV21ELE9BQVgsQ0FBbUIsVUFBQUMsT0FBTyxFQUFJO0FBQzFCLDRCQUFHQSxPQUFPLENBQUNyQyxJQUFSLElBQWNzQyxJQUFqQixFQUFzQjtBQUNsQkQsMEJBQUFBLE9BQU8sQ0FBQ2hDLFlBQVIsQ0FBcUIxQyxjQUFyQixFQUFxQzJDLFFBQXJDLEdBQThDaEIsSUFBSSxDQUFDaUQsSUFBbkQ7QUFDQWhCLDBCQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxhQUFXYSxPQUFPLENBQUNyQyxJQUEvQjtBQUNIO0FBQ0osdUJBTEQsRUFIYyxDQVNmO0FBQ0E7QUFWZTs7QUFDbEIseUJBQUssSUFBSU4sQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR0osSUFBSSxDQUFDSCxHQUFMLENBQVN3QyxNQUE3QixFQUFxQyxFQUFFakMsQ0FBdkMsRUFBMEM7QUFBQSw0QkFBakNBLENBQWlDO0FBVXpDO0FBQ0osbUJBbENBLENBb0NEOzs7QUFDQUosa0JBQUFBLElBQUksQ0FBQ04sUUFBTCxHQUFnQixJQUFJdEIsSUFBSixDQUFTLENBQUMsQ0FBVixFQUFhLENBQWIsQ0FBaEI7QUFDSDtBQUNKO0FBQ0o7QUFHRDs7Ozs7OzBDQUcyQjtBQUV2QixnQkFBSTRCLElBQUksR0FBQyxJQUFUOztBQUVBLGdCQUFJQSxJQUFJLENBQUNILEdBQUwsSUFBWSxJQUFoQixFQUFzQjtBQUFBLDJDQUNUTyxDQURTO0FBRWQsb0JBQUk0QyxJQUFZLEdBQUcsQ0FBQ2hELElBQUksQ0FBQ0gsR0FBTCxDQUFTTyxDQUFULEVBQVl1QixDQUFaLEdBQWdCLEdBQWhCLEdBQXNCM0IsSUFBSSxDQUFDSCxHQUFMLENBQVNPLENBQVQsRUFBWXdCLENBQW5DLEVBQXNDUSxRQUF0QyxFQUFuQjtBQUNBcEMsZ0JBQUFBLElBQUksQ0FBQ0wsS0FBTCxDQUFXbUQsT0FBWCxDQUFtQixVQUFBQyxPQUFPLEVBQUk7QUFDMUIsc0JBQUdBLE9BQU8sQ0FBQ3JDLElBQVIsSUFBY3NDLElBQWpCLEVBQXNCO0FBQ2xCRCxvQkFBQUEsT0FBTyxDQUFDaEMsWUFBUixDQUFxQjFDLGNBQXJCLEVBQXFDMkMsUUFBckMsR0FBOENoQixJQUFJLENBQUNzQyxNQUFuRDtBQUNBTCxvQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksYUFBV2EsT0FBTyxDQUFDckMsSUFBL0I7QUFDSDtBQUNKLGlCQUxEO0FBSGM7O0FBQ2xCLG1CQUFLLElBQUlOLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdKLElBQUksQ0FBQ0gsR0FBTCxDQUFTd0MsTUFBN0IsRUFBcUMsRUFBRWpDLENBQXZDLEVBQTBDO0FBQUEsdUJBQWpDQSxDQUFpQztBQVF6QztBQUNKO0FBQ0o7Ozs7UUExUDBCbkMsUzs7Ozs7aUJBaUNKLEk7Ozs7Ozs7aUJBR0csSTs7Ozs7OztpQkFHRixJOzs7Ozs7O2lCQUdFLEk7Ozs7Ozs7aUJBR0MsSTs7Ozs7OztpQkFtQm9CLEk7Ozs7Ozs7aUJBS3ZCLEkiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBfZGVjb3JhdG9yLCBDb21wb25lbnQsIE5vZGUsIE1hdGVyaWFsLCBWZWMyLCBNb2RlbENvbXBvbmVudCwgVmVjMywgZ2VvbWV0cnksIENhbWVyYUNvbXBvbmVudCwgc3lzdGVtRXZlbnQsIFN5c3RlbUV2ZW50VHlwZSwgRXZlbnRUb3VjaCwgUGh5c2ljc1N5c3RlbSwgUGh5c2ljc1JheVJlc3VsdCwgUHJlZmFiLCBpbnN0YW50aWF0ZSwgSW5zdGFuY2VNYXRlcmlhbFR5cGUsIGRpcmVjdG9yLCBzbGljZWQgfSBmcm9tICdjYyc7XHJcbmltcG9ydCB7IEFTdGFyTm9kZSwgRV9Ob2RlX1R5cGUgfSBmcm9tICcuL0FTdGFyTm9kZSc7XHJcbmltcG9ydCB7IEFTdGFyTWdyIH0gZnJvbSAnLi9BU3Rhck1ncic7XHJcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IF9kZWNvcmF0b3I7XHJcblxyXG5cclxuXHJcbkBjY2NsYXNzKCdUZXN0QVN0YXInKVxyXG5leHBvcnQgY2xhc3MgVGVzdEFTdGFyIGV4dGVuZHMgQ29tcG9uZW50IHtcclxuXHJcbiAgICAvKipcclxuICAgICAqIOW3puS4iuinkuesrOS4gOS4queri+aWueS9k+eahFjlnZDmoIdcclxuICAgICAqL1xyXG4gICAgcHVibGljIGJlZ2luWCA9IC0zO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICog5bem5LiK6KeS56ys5LiA5Liq56uL5pa55L2T55qEWeWdkOagh1xyXG4gICAgICovXHJcbiAgICBwdWJsaWMgYmVnaW5ZID0gNTtcclxuXHJcbiAgICAvKipcclxuICAgICAqIOS5i+WQjuavj+S4queri+aWueS9k+S5i+mXtOeahCDlgY/np7tY5Z2Q5qCHXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBvZmZzZXRYID0gMjtcclxuXHJcbiAgICAvKipcclxuICAgICAqIOS5i+WQjuavj+S4queri+aWueS9k+S5i+mXtOeahOWBj+enu1nlnZDmoIdcclxuICAgICAqL1xyXG4gICAgcHVibGljIG9mZnNldFkgPSAtMjtcclxuXHJcbiAgICAvKipcclxuICAgICAqIOWcsOWbvuagvOWtkOeahOWuvVxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgbWFwVyA9IDQ7XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiDlnLDlm77moLzlrZDnmoTpq5hcclxuICAgICAqL1xyXG4gICAgcHVibGljIG1hcEggPSA0O1xyXG5cclxuICAgIEBwcm9wZXJ0eSh7IHR5cGU6IE1hdGVyaWFsIH0pXHJcbiAgICBwdWJsaWMgcmVkOiBNYXRlcmlhbCA9IG51bGw7XHJcblxyXG4gICAgQHByb3BlcnR5KHsgdHlwZTogTWF0ZXJpYWwgfSlcclxuICAgIHB1YmxpYyB5ZWxsb3c6IE1hdGVyaWFsID0gbnVsbDtcclxuXHJcbiAgICBAcHJvcGVydHkoeyB0eXBlOiBNYXRlcmlhbCB9KVxyXG4gICAgcHVibGljIGJsdWU6IE1hdGVyaWFsID0gbnVsbDtcclxuXHJcbiAgICBAcHJvcGVydHkoeyB0eXBlOiBNYXRlcmlhbCB9KVxyXG4gICAgcHVibGljIG5vcm1hbDogTWF0ZXJpYWwgPSBudWxsO1xyXG5cclxuICAgIEBwcm9wZXJ0eSh7IHR5cGU6IFByZWZhYiB9KVxyXG4gICAgcHVibGljIGluc3Rhbk9iajogUHJlZmFiID0gbnVsbDtcclxuXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiDlvIDlp4vngrkg57uZ5a6D5LiA5LiqIOS4uui0n+eahOWdkOagh1xyXG4gICAgICovXHJcbiAgICBwcml2YXRlIGJlZ2luUG9zOiBWZWMyID0gbmV3IFZlYzIoLTEsIDApO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICog5Yib5bu655qEY3ViZXPliJfooahcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBjdWJlczogQXJyYXk8Tm9kZT4gPSBuZXcgQXJyYXk8Tm9kZT4oKTtcclxuXHJcbiAgICAvKipcclxuICAgICAqIEFTdGFyIOiKgueCueWIl+ihqFxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIGxzdDogQXJyYXk8QVN0YXJOb2RlPiA9IG5ldyBBcnJheTxBU3Rhck5vZGU+KCk7XHJcblxyXG4gICAgQHByb3BlcnR5KHsgdHlwZTogQ2FtZXJhQ29tcG9uZW50IH0pXHJcbiAgICBwcml2YXRlIHJlYWRvbmx5IG1haW5DYW1lcmE6IENhbWVyYUNvbXBvbmVudCA9IG51bGw7XHJcblxyXG4gICAgcHJpdmF0ZSByYXk6IGdlb21ldHJ5LnJheSA9IG5ldyBnZW9tZXRyeS5yYXkoKTtcclxuXHJcbiAgICBAcHJvcGVydHkoeyB0eXBlOiBOb2RlIH0pXHJcbiAgICBwdWJsaWMgc3Bhd25Qb3M6IE5vZGUgPSBudWxsO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICog5a2Y5pS+54K55Ye755qE5a+56LGh5ZCN56ewXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgc3Ryczogc3RyaW5nW10gPSBbXTtcclxuXHJcblxyXG4gICAgcHVibGljIG9uTG9hZCgpIHtcclxuICAgICAgICBsZXQgc2VsZiA9IHRoaXM7XHJcblxyXG4gICAgICAgIC8v5Yid5aeL5YyWQVN0YXJNZ3JcclxuICAgICAgICAvL2xldCBhU3Rhck1ncjpBU3Rhck1ncj1zZWxmLm5vZGUuZ2V0Q29tcG9uZW50KCdBU3Rhck1ncicpIGFzIEFTdGFyTWdyO1xyXG4gICAgICAgIC8vYVN0YXJNZ3IuSW5pdCgpO1xyXG5cclxuXHJcbiAgICAgICAgQVN0YXJNZ3IuSW5zdGFuY2UoKS5Jbml0TWFwSW5mbyhzZWxmLm1hcFcsIHNlbGYubWFwSCk7XHJcblxyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc2VsZi5tYXBXOyArK2kpIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCBzZWxmLm1hcEg7ICsraikge1xyXG4gICAgICAgICAgICAgICAgLy/liJvlu7rkuIDkuKrkuKrnq4vmlrnkvZNcclxuICAgICAgICAgICAgICAgIC8vbGV0IG9iaiA9dGhpcy5ub2RlLkNyZWF0ZVByaW1pdGl2ZShQcmltaXRpdmVUeXBlLkJPWCk7XHJcbiAgICAgICAgICAgICAgICBsZXQgb2JqID0gaW5zdGFudGlhdGUoc2VsZi5pbnN0YW5PYmopIGFzIE5vZGU7XHJcbiAgICAgICAgICAgICAgICAvL+iuvue9rueItuWvueixoVxyXG4gICAgICAgICAgICAgICAgb2JqLnBhcmVudCA9IHNlbGYuc3Bhd25Qb3M7XHJcbiAgICAgICAgICAgICAgICAvL2NvbnNvbGUubG9nKFwib2JqLnR5cGUgaXM6XCIrb2JqKTtcclxuICAgICAgICAgICAgICAgIG9iai5wb3NpdGlvbiA9IG5ldyBWZWMzKHNlbGYuYmVnaW5YICsgaSAqIHNlbGYub2Zmc2V0WCwgc2VsZi5iZWdpblkgKyBqICogc2VsZi5vZmZzZXRZLCAwKTtcclxuICAgICAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJvYmoubm9kZS5wb3NpdGlvbiBpczpcIitvYmoucG9zaXRpb24pO1xyXG4gICAgICAgICAgICAgICAgLy/lkI3lrZdcclxuICAgICAgICAgICAgICAgIG9iai5uYW1lID0gaSArIFwiX1wiICsgajtcclxuICAgICAgICAgICAgICAgIC8v5a2Y5YKo56uL5pa55L2T5Yiw5a2X5YW45a655Zmo5LitXHJcbiAgICAgICAgICAgICAgICBzZWxmLmN1YmVzLnB1c2gob2JqKTtcclxuICAgICAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJzZWxmLmN1YmVzLmxlbmd0aCBpczpcIitzZWxmLmN1YmVzLmxlbmd0aCk7XHJcblxyXG4gICAgICAgICAgICAgICAgLy/lvpfliLDmoLzlrZAg5Yik5pat5a6D5piv5LiN5piv6Zi75oyhXHJcbiAgICAgICAgICAgICAgICBsZXQgdGVtcE5vZGU6IEFTdGFyTm9kZSA9IEFTdGFyTWdyLkluc3RhbmNlKCkubm9kZXNbaV1bal07XHJcbiAgICAgICAgICAgICAgICBpZiAodGVtcE5vZGUudHlwZSA9PSBFX05vZGVfVHlwZS5TdG9wKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgb2JqLmdldENvbXBvbmVudChNb2RlbENvbXBvbmVudCkubWF0ZXJpYWwgPSBzZWxmLnJlZDtcclxuICAgICAgICAgICAgICAgICAgICAvL2NvbnNvbGUubG9nKFwic2V0IG9iaidtYXRlcmlhbDpcIitvYmouZ2V0Q29tcG9uZW50KE1vZGVsQ29tcG9uZW50KS5tYXRlcmlhbC50b1N0cmluZygpKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhcImNvbnRpbnV0ZSBmb3ItdGltZSBpczpcIitpKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG5cclxuICAgIHB1YmxpYyBvbkVuYWJsZSgpIHtcclxuICAgICAgICBzeXN0ZW1FdmVudC5vbihTeXN0ZW1FdmVudFR5cGUuVE9VQ0hfU1RBUlQsIHRoaXMuVGVzdEFTdGFyLCB0aGlzKTtcclxuICAgICAgICAvL3N5c3RlbUV2ZW50Lm9uKFN5c3RlbUV2ZW50VHlwZS5LRVlfRE9XTiwgdGhpcy5UZXN0LCB0aGlzKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgcHVibGljIG9uRGlzYWJsZSgpIHtcclxuICAgICAgICBzeXN0ZW1FdmVudC5vZmYoU3lzdGVtRXZlbnRUeXBlLlRPVUNIX1NUQVJULCB0aGlzLlRlc3RBU3RhciwgdGhpcyk7XHJcbiAgICAgICAgLy8gc3lzdGVtRXZlbnQub2ZmKFN5c3RlbUV2ZW50VHlwZS5LRVlfVVAsIHRoaXMuVGVzdCwgdGhpcyk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiDmtYvor5VBU3RhclxyXG4gICAgICovXHJcbiAgICBUZXN0QVN0YXIodG91Y2g6IFRvdWNoLCBldmVudDogRXZlbnRUb3VjaCkge1xyXG5cclxuICAgICAgICBsZXQgc2VsZiA9IHRoaXM7XHJcblxyXG4gICAgICAgIC8vY29uc29sZS5sb2coXCJWZWN0LlVOSVRfWCBpczpcIitWZWMyLlVOSVRfWCk7XHJcbiAgICAgICAgLy/lpoLmnpzpvKDmoIflt6bplK7mjInkuItcclxuXHJcbiAgICAgICAgLy/ov5vooYzlsITnur/mo4DmtYtcclxuICAgICAgICBsZXQgaW5mbzogUGh5c2ljc1JheVJlc3VsdFtdID0gbnVsbDsgLy/lsITnur/mo4DmtYvlroznmoTkv6Hmga9cclxuICAgICAgICAvL+W+l+WIsOWxj+W5lem8oOagh+S9jee9ruWPkeWHuuWOu+eahOWwhOe6v1xyXG4gICAgICAgIC8vY29uc29sZS5sb2coXCJDbGljayBzdWNjZXNzZnVsIVwiKTtcclxuXHJcbiAgICAgICAgc2VsZi5tYWluQ2FtZXJhLnNjcmVlblBvaW50VG9SYXkodG91Y2guX3BvaW50LngsIHRvdWNoLl9wb2ludC55LCBzZWxmLnJheSk7XHJcblxyXG4gICAgICAgIC8vI3JlZ2lvbiAg5Z+65LqO54mp55CG56Kw5pKe5Zmo55qE5bCE57q/5qOA5rWLXHJcblxyXG4gICAgICAgIC8qIGlmIChQaHlzaWNzU3lzdGVtLmluc3RhbmNlLnJheWNhc3Qoc2VsZi5yYXkpKSB7XHJcbiAgICAgICAgICAgICBjb25zdCByID0gUGh5c2ljc1N5c3RlbS5pbnN0YW5jZS5yYXljYXN0UmVzdWx0cztcclxuICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgci5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAgICAgIGNvbnN0IGl0ZW0gPSByW2ldO1xyXG4gICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQ2xpY2sgb2JqIGlzOlwiK2l0ZW0uY29sbGlkZXIubmFtZSk7XHJcbiAgICAgICAgICAgICB9XHJcbiAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJXaGF0IGFyZSB5b3Ugd2FudCB0byBkbyFcIik7XHJcbiAgICAgICAgIH0qL1xyXG4gICAgICAgIC8vI2VuZHJlZ2lvblxyXG5cclxuICAgICAgICAvL+WwhOe6v+ajgOa1i1xyXG4gICAgICAgIGlmIChQaHlzaWNzU3lzdGVtLmluc3RhbmNlLnJheWNhc3Qoc2VsZi5yYXkpKSB7XHJcblxyXG5cclxuICAgICAgICAgICAgc2VsZi5SZVNldE1hdGVyaWFsKCk7XHJcblxyXG4gICAgICAgICAgICBpbmZvID0gUGh5c2ljc1N5c3RlbS5pbnN0YW5jZS5yYXljYXN0UmVzdWx0cztcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJSYXkgSW5mbyBpczpcIiArIGluZm9bMF0uY29sbGlkZXIubmFtZS50b1N0cmluZygpKTtcclxuXHJcbiAgICAgICAgICAgIC8v5riF55CG5LiK5LiA5qyh55qE6Lev5b6E77yM5oqK57u/6Imy56uL5pa55L2T5Y+Y5oiQ55m96ImyXHJcbiAgICAgICAgICAgIC8v5aaC5p6c5LiN5Li656m677yM6K+B5piO5om+5oiQ5Yqf5LqGXHJcbiAgICAgICAgICAgIGlmIChzZWxmLmxzdCAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHNlbGYubHN0Lmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2VsZi5jdWJlc1tpXS5nZXRDb21wb25lbnQoTW9kZWxDb21wb25lbnQpLm1hdGVyaWFsID0gc2VsZi5ub3JtYWw7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJSZXNldCBzZWxmLmN1YmVzW2ldLm1hdGVyaWFsLi4uXCIpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAvL2NvbnNvbGUubG9nKFwic2VsZi5iZWdpblBvcyBpczpcIitzZWxmLmJlZ2luUG9zKTtcclxuICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhcInNlbGYuYmVnaW5Qb3MgZXF1YWwgbmV3IFZlYzIoLTEuMDAsMC4wMCkgaXM6XCIrKHNlbGYuYmVnaW5Qb3MgPT0gbmV3IFZlYzIoLTEuMDAsIDAuMDApKSk7XHJcbiAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJzZWxmLmJlZ2luUG9zLnggZXF1YWwgLTEgYW5kIHNlbGYuYmVnaW5Qb3MueSBlcXVhbCAwIGlzOlwiKyhzZWxmLmJlZ2luUG9zLng9PS0xJiZzZWxmLmJlZ2luUG9zLnk9PTApKTtcclxuICAgICAgICAgICAgLy/lvpfliLDngrnlh7vliLDnmoTnq4vmlrnkvZMg5omN6IO955+l6YGT5piv56ys5Yeg6KGM56ys5Yeg5YiXXHJcbiAgICAgICAgICAgIGlmIChzZWxmLmJlZ2luUG9zLnggPT0gLTEgJiYgc2VsZi5iZWdpblBvcy55ID09IDApIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwic2V0IGJlZ2luUG9zLi4uXCIpO1xyXG4gICAgICAgICAgICAgICAgbGV0IHN0cnMgPSBpbmZvWzBdLmNvbGxpZGVyLm5vZGUubmFtZS5zcGxpdCgnXycpO1xyXG4gICAgICAgICAgICAgICAgLy/lvpfliLDooYzliJfkvY3nva4g5bCx5piv5byA5aeL54K55L2N572uXHJcbiAgICAgICAgICAgICAgICBzZWxmLmJlZ2luUG9zID0gbmV3IFZlYzIoTnVtYmVyKHN0cnNbMF0udG9TdHJpbmcoKSlcclxuICAgICAgICAgICAgICAgICAgICAsIE51bWJlcihzdHJzWzFdLnRvU3RyaW5nKCkpKTtcclxuICAgICAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJzZXQgc2VsZi5iZWdpblBvcyBpczpcIiArIHNlbGYuYmVnaW5Qb3MudG9TdHJpbmcoKSk7XHJcbiAgICAgICAgICAgICAgICAvL+aKiueCueWHu+WIsOeahOWvueixoeWPmOaIkOm7hOiJslxyXG4gICAgICAgICAgICAgICAgaW5mb1swXS5jb2xsaWRlci5ub2RlLmdldENvbXBvbmVudChNb2RlbENvbXBvbmVudCkubWF0ZXJpYWwgPSBzZWxmLnllbGxvdztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAvL+aciei1t+eCueS6hiDpgqPov5nlsLHmmK8g5p2l54K55Ye657uI54K5IOi/m+ihjOWvu+i3r1xyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiU2V0IGVuZFBvcy4uLlwiKTtcclxuICAgICAgICAgICAgICAgIC8v5b6X5Yiw57uI54K5XHJcbiAgICAgICAgICAgICAgICBsZXQgc3Ryczogc3RyaW5nW10gPSBpbmZvWzBdLmNvbGxpZGVyLm5vZGUubmFtZS5zcGxpdCgnXycpO1xyXG4gICAgICAgICAgICAgICAgbGV0IGVuZFBvczogVmVjMiA9IG5ldyBWZWMyKE51bWJlcihzdHJzWzBdKSwgTnVtYmVyKHN0cnNbMV0pKTtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZW5kUG9zIGlzOlwiICsgaW5mb1swXS5jb2xsaWRlci5ub2RlLm5hbWUpO1xyXG5cclxuICAgICAgICAgICAgICAgIC8v5a+76LevXHJcbiAgICAgICAgICAgICAgICBzZWxmLmxzdCA9IEFTdGFyTWdyLkluc3RhbmNlKCkuRmluZFBhdGgoc2VsZi5iZWdpblBvcywgZW5kUG9zKTtcclxuXHJcbiAgICAgICAgICAgICAgICAvL+mBv+WFjeatu+i3r+eahOaXtuWAmem7hOiJsuS4jeWPmOaIkOeZveiJsu+8jOaJgOS7peS6i+WFiOa4heS4gOmBjeOAguWboOS4umJlZ2luUG9zLnjmmK9mbG9hdOexu+Wei+eahOaJgOS7peimgei9rOaNouS4umludOexu+Wei1xyXG4gICAgICAgICAgICAgICAgLy9zZWxmLmN1YmVzW3NlbGYuYmVnaW5Qb3MueF1bLmJlZ2luUG9zLnldLmdldENvbXBvbmVudChNb2RlbENvbXBvbmVudCkubWF0ZXJpYWwgPSB0aGlzLm5vcm1hbDtcclxuICAgICAgICAgICAgICAgIGxldCBzdDogc3RyaW5nID0gKHNlbGYuYmVnaW5Qb3MueCArIFwiX1wiICsgc2VsZi5iZWdpblBvcy55KS50b1N0cmluZygpO1xyXG4gICAgICAgICAgICAgICAgc2VsZi5jdWJlcy5mb3JFYWNoKGVsZW1lbnQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmIChlbGVtZW50Lm5hbWUgPT0gc3QpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy/pgb/lhY3mrbvot6/nmoTml7blgJnpu4ToibLkuI3lj5jmiJDnmb3oibLvvIzmiYDku6XkuovlhYjmuIXkuIDpgY3jgILlm6DkuLpiZWdpblBvcy545pivZmxvYXTnsbvlnovnmoTmiYDku6XopoHovazmjaLkuLppbnTnsbvlnotcclxuICAgICAgICAgICAgICAgICAgICAgICAgZWxlbWVudC5nZXRDb21wb25lbnQoTW9kZWxDb21wb25lbnQpLm1hdGVyaWFsID0gdGhpcy5ub3JtYWw7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwic2VsZi5jdWJlc1tiZWdpblBvc10gaXM6XCIgKyBlbGVtZW50Lm5hbWUpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICAgICAgLy/lpoLmnpzkuI3kuLrnqbrvvIzor4HmmI7mib7miJDlip/kuoZcclxuICAgICAgICAgICAgICAgIGlmIChzZWxmLmxzdCAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCBzZWxmLmxzdC5sZW5ndGg7ICsraikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZXQgdGVtcDogc3RyaW5nID0gKHNlbGYubHN0W2pdLnggKyBcIl9cIiArIHNlbGYubHN0W2pdLnkpLnRvU3RyaW5nKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbGYuY3ViZXMuZm9yRWFjaChlbGVtZW50ID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmKGVsZW1lbnQubmFtZT09dGVtcCl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxlbWVudC5nZXRDb21wb25lbnQoTW9kZWxDb21wb25lbnQpLm1hdGVyaWFsPXNlbGYuYmx1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIuaJk+WNsOWPmOiJsueahOmhuuW6j++8mlwiK2VsZW1lbnQubmFtZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgIC8vIHNlbGYuY3ViZXNbal0uZ2V0Q29tcG9uZW50KE1vZGVsQ29tcG9uZW50KS5tYXRlcmlhbCA9IHRoaXMuYmx1ZTtcclxuICAgICAgICAgICAgICAgICAgICAgICAvLy8gY29uc29sZS5sb2coXCLmiZPljbDot6/lvoTpobrluo/vvJpcIiArIHNlbGYubHN0W2pdLnggKyBcIl9cIiArIHNlbGYubHN0W2pdLnkpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAvL+a4hemZpOW8gOWni+eCuSDmiorlroPlj5jmiJDliJ3lp4vlgLxcclxuICAgICAgICAgICAgICAgIHNlbGYuYmVnaW5Qb3MgPSBuZXcgVmVjMigtMSwgMCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICog6YeN572u5Y+Y5oiQ6JOd6Imy55qE5a+56LGh5Li6Tm9ybWFsXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBSZVNldE1hdGVyaWFsKCk6dm9pZHtcclxuXHJcbiAgICAgICAgbGV0IHNlbGY9dGhpcztcclxuXHJcbiAgICAgICAgaWYgKHNlbGYubHN0ICE9IG51bGwpIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCBzZWxmLmxzdC5sZW5ndGg7ICsraikge1xyXG4gICAgICAgICAgICAgICAgbGV0IHRlbXA6IHN0cmluZyA9IChzZWxmLmxzdFtqXS54ICsgXCJfXCIgKyBzZWxmLmxzdFtqXS55KS50b1N0cmluZygpO1xyXG4gICAgICAgICAgICAgICAgc2VsZi5jdWJlcy5mb3JFYWNoKGVsZW1lbnQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmKGVsZW1lbnQubmFtZT09dGVtcCl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsZW1lbnQuZ2V0Q29tcG9uZW50KE1vZGVsQ29tcG9uZW50KS5tYXRlcmlhbD1zZWxmLm5vcm1hbDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCLph43nva7lj5joibLnmoTpobrluo/vvJpcIitlbGVtZW50Lm5hbWUpO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pOyAgICAgICAgICAgICBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbn1cclxuIl19