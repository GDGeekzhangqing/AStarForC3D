System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, _dec, _class, _crd, ccclass, property, E_Node_Type, AStarNode;

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  _export({
    _dec: void 0,
    _class: void 0,
    E_Node_Type: void 0
  });

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
    }],
    execute: function () {
      _cclegacy._RF.push({}, "a82a6ey53VHv75+IOMFDTTc", "AStarNode", _context.meta);

      _crd = true;
      ccclass = _decorator.ccclass;
      property = _decorator.property; /// <summary>
      /// 格子的类型
      /// </summary>

      (function (E_Node_Type) {
        E_Node_Type[E_Node_Type["Walk"] = 0] = "Walk";
        E_Node_Type[E_Node_Type["Stop"] = 1] = "Stop";
      })(E_Node_Type || _export("E_Node_Type", E_Node_Type = {}));

      _export("AStarNode", AStarNode = (_dec = ccclass('AStarNode'), _dec(_class =
      /**
       * 格子对象的X坐标
       */

      /**
       * 格子对象的Y坐标
       */

      /**
       * 寻路消耗
       */

      /**
       * 离起点的距离
       */

      /**
       * 离终点的距离
       */

      /**
       * 父节点
       */

      /**
       * 格子的类型
       */

      /**
       * 格子类构造函数，传入坐标和格子类型
       * @param x 
       * @param y 
       * @param type 
       */
      function AStarNode(x, y, type) {
        _classCallCheck(this, AStarNode);

        this.x = x;
        this.y = y;
        this.type = type;
      }) || _class));

      _crd = false;

      _cclegacy._RF.pop();
    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vRDovQ29Db3MzRExzdC9BU3RhckRlbW8vRGVtby9hc3NldHMvc2NyaXB0cy9BU3Rhck5vZGUudHMiXSwibmFtZXMiOlsiX2RlY29yYXRvciIsImNjY2xhc3MiLCJwcm9wZXJ0eSIsIkVfTm9kZV9UeXBlIiwiQVN0YXJOb2RlIiwieCIsInkiLCJ0eXBlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQVNBLE1BQUFBLFUsT0FBQUEsVTs7Ozs7O0FBQ0RDLE1BQUFBLE8sR0FBc0JELFUsQ0FBdEJDLE87QUFBU0MsTUFBQUEsUSxHQUFhRixVLENBQWJFLFEsRUFFakI7QUFDQTtBQUNBOztpQkFDWUMsVztBQUFBQSxRQUFBQSxXLENBQUFBLFc7QUFBQUEsUUFBQUEsVyxDQUFBQSxXO1NBQUFBLFcsMkJBQUFBLFc7OzJCQWFDQyxTLFdBRFpILE9BQU8sQ0FBQyxXQUFELEM7QUFJUDs7OztBQUtBOzs7O0FBS0E7Ozs7QUFLQTs7OztBQUtBOzs7O0FBS0E7Ozs7QUFLQTs7OztBQUtBOzs7Ozs7QUFNQSx5QkFBWUksQ0FBWixFQUFlQyxDQUFmLEVBQWtCQyxJQUFsQixFQUF3QjtBQUFBOztBQUN2QixhQUFLRixDQUFMLEdBQVNBLENBQVQ7QUFDQSxhQUFLQyxDQUFMLEdBQVNBLENBQVQ7QUFDQSxhQUFLQyxJQUFMLEdBQVlBLElBQVo7QUFDQSxPIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgX2RlY29yYXRvciwgQ29tcG9uZW50LCBOb2RlIH0gZnJvbSAnY2MnO1xyXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBfZGVjb3JhdG9yO1xyXG5cclxuLy8vIDxzdW1tYXJ5PlxyXG4vLy8g5qC85a2Q55qE57G75Z6LXHJcbi8vLyA8L3N1bW1hcnk+XHJcbmV4cG9ydCBlbnVtIEVfTm9kZV9UeXBlIHtcclxuXHQvKipcclxuXHQgKiDlj6/ku6XotbDnmoTlnLDmlrlcclxuXHQgKi9cclxuXHRXYWxrLFxyXG5cclxuXHQvKipcclxuXHQgKiDkuI3og73otbDnmoTpmLvmjKFcclxuXHQgKi9cclxuXHRTdG9wXHJcbn1cclxuXHJcbkBjY2NsYXNzKCdBU3Rhck5vZGUnKVxyXG5leHBvcnQgY2xhc3MgQVN0YXJOb2RlIHtcclxuXHJcblxyXG5cdC8qKlxyXG5cdCAqIOagvOWtkOWvueixoeeahFjlnZDmoIdcclxuXHQgKi9cclxuXHRwdWJsaWMgeDogbnVtYmVyO1xyXG5cclxuXHQvKipcclxuXHQgKiDmoLzlrZDlr7nosaHnmoRZ5Z2Q5qCHXHJcblx0ICovXHJcblx0cHVibGljIHk6IG51bWJlcjtcclxuXHJcblx0LyoqXHJcblx0ICog5a+76Lev5raI6ICXXHJcblx0ICovXHJcblx0cHVibGljIGY7XHJcblxyXG5cdC8qKlxyXG5cdCAqIOemu+i1t+eCueeahOi3neemu1xyXG5cdCAqL1xyXG5cdHB1YmxpYyBnO1xyXG5cclxuXHQvKipcclxuXHQgKiDnprvnu4jngrnnmoTot53nprtcclxuXHQgKi9cclxuXHRwdWJsaWMgaDtcclxuXHJcblx0LyoqXHJcblx0ICog54i26IqC54K5XHJcblx0ICovXHJcblx0cHVibGljIGZhdGhlcjogQVN0YXJOb2RlO1xyXG5cclxuXHQvKipcclxuXHQgKiDmoLzlrZDnmoTnsbvlnotcclxuXHQgKi9cclxuXHRwdWJsaWMgdHlwZTogRV9Ob2RlX1R5cGU7XHJcblxyXG5cdC8qKlxyXG5cdCAqIOagvOWtkOexu+aehOmAoOWHveaVsO+8jOS8oOWFpeWdkOagh+WSjOagvOWtkOexu+Wei1xyXG5cdCAqIEBwYXJhbSB4IFxyXG5cdCAqIEBwYXJhbSB5IFxyXG5cdCAqIEBwYXJhbSB0eXBlIFxyXG5cdCAqL1xyXG5cdGNvbnN0cnVjdG9yKHgsIHksIHR5cGUpIHtcclxuXHRcdHRoaXMueCA9IHg7XHJcblx0XHR0aGlzLnkgPSB5O1xyXG5cdFx0dGhpcy50eXBlID0gdHlwZTtcclxuXHR9XHJcblxyXG59XHJcbiJdfQ==