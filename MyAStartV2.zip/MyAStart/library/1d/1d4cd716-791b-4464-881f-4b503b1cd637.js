System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, _dec, _class, _crd, ccclass, property, E_Node_Type, AStarNode;

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  _export({
    _dec: void 0,
    _class: void 0,
    E_Node_Type: void 0
  });

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
    }],
    execute: function () {
      _cclegacy._RF.push({}, "1d4cdcWeRtEZIgfS1A7HNY3", "AStarNode", _context.meta);

      _crd = true;
      ccclass = _decorator.ccclass;
      property = _decorator.property; /// <summary>
      /// 格子的类型
      /// </summary>

      (function (E_Node_Type) {
        E_Node_Type[E_Node_Type["Walk"] = 0] = "Walk";
        E_Node_Type[E_Node_Type["Stop"] = 1] = "Stop";
      })(E_Node_Type || _export("E_Node_Type", E_Node_Type = {}));

      _export("AStarNode", AStarNode = (_dec = ccclass('AStarNode'), _dec(_class =
      /**
       * 格子对象的X坐标
       */

      /**
       * 格子对象的Y坐标
       */

      /**
       * 寻路消耗
       */

      /**
       * 离起点的距离
       */

      /**
       * 离终点的距离
       */

      /**
       * 父节点
       */

      /**
       * 格子的类型
       */

      /**
       * 格子类构造函数，传入坐标和格子类型
       * @param x 
       * @param y 
       * @param type 
       */
      function AStarNode(x, y, type) {
        _classCallCheck(this, AStarNode);

        this.x = x;
        this.y = y;
        this.type = type;
      }) || _class));

      _crd = false;

      _cclegacy._RF.pop();
    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vRDovQ29Db3MzRExzdC9NeUFTdGFydC9hc3NldHMvc2NpcHRzL015L0FTdGFyTm9kZS50cyJdLCJuYW1lcyI6WyJfZGVjb3JhdG9yIiwiY2NjbGFzcyIsInByb3BlcnR5IiwiRV9Ob2RlX1R5cGUiLCJBU3Rhck5vZGUiLCJ4IiwieSIsInR5cGUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBU0EsTUFBQUEsVSxPQUFBQSxVOzs7Ozs7QUFDREMsTUFBQUEsTyxHQUFzQkQsVSxDQUF0QkMsTztBQUFTQyxNQUFBQSxRLEdBQWFGLFUsQ0FBYkUsUSxFQUVqQjtBQUNBO0FBQ0E7O2lCQUNZQyxXO0FBQUFBLFFBQUFBLFcsQ0FBQUEsVztBQUFBQSxRQUFBQSxXLENBQUFBLFc7U0FBQUEsVywyQkFBQUEsVzs7MkJBYUNDLFMsV0FEWkgsT0FBTyxDQUFDLFdBQUQsQztBQUlQOzs7O0FBS0E7Ozs7QUFLQTs7OztBQUtBOzs7O0FBS0E7Ozs7QUFLQTs7OztBQUtBOzs7O0FBS0E7Ozs7OztBQU1BLHlCQUFZSSxDQUFaLEVBQWVDLENBQWYsRUFBa0JDLElBQWxCLEVBQXdCO0FBQUE7O0FBQ3ZCLGFBQUtGLENBQUwsR0FBU0EsQ0FBVDtBQUNBLGFBQUtDLENBQUwsR0FBU0EsQ0FBVDtBQUNBLGFBQUtDLElBQUwsR0FBWUEsSUFBWjtBQUNBLE8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBfZGVjb3JhdG9yLCBDb21wb25lbnQsIE5vZGUgfSBmcm9tICdjYyc7XHJcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IF9kZWNvcmF0b3I7XHJcblxyXG4vLy8gPHN1bW1hcnk+XHJcbi8vLyDmoLzlrZDnmoTnsbvlnotcclxuLy8vIDwvc3VtbWFyeT5cclxuZXhwb3J0IGVudW0gRV9Ob2RlX1R5cGUge1xyXG5cdC8qKlxyXG5cdCAqIOWPr+S7pei1sOeahOWcsOaWuVxyXG5cdCAqL1xyXG5cdFdhbGssXHJcblxyXG5cdC8qKlxyXG5cdCAqIOS4jeiDvei1sOeahOmYu+aMoVxyXG5cdCAqL1xyXG5cdFN0b3BcclxufVxyXG5cclxuQGNjY2xhc3MoJ0FTdGFyTm9kZScpXHJcbmV4cG9ydCBjbGFzcyBBU3Rhck5vZGUge1xyXG5cclxuXHJcblx0LyoqXHJcblx0ICog5qC85a2Q5a+56LGh55qEWOWdkOagh1xyXG5cdCAqL1xyXG5cdHB1YmxpYyB4OiBudW1iZXI7XHJcblxyXG5cdC8qKlxyXG5cdCAqIOagvOWtkOWvueixoeeahFnlnZDmoIdcclxuXHQgKi9cclxuXHRwdWJsaWMgeTogbnVtYmVyO1xyXG5cclxuXHQvKipcclxuXHQgKiDlr7vot6/mtojogJdcclxuXHQgKi9cclxuXHRwdWJsaWMgZjtcclxuXHJcblx0LyoqXHJcblx0ICog56a76LW354K555qE6Led56a7XHJcblx0ICovXHJcblx0cHVibGljIGc7XHJcblxyXG5cdC8qKlxyXG5cdCAqIOemu+e7iOeCueeahOi3neemu1xyXG5cdCAqL1xyXG5cdHB1YmxpYyBoO1xyXG5cclxuXHQvKipcclxuXHQgKiDniLboioLngrlcclxuXHQgKi9cclxuXHRwdWJsaWMgZmF0aGVyOiBBU3Rhck5vZGU7XHJcblxyXG5cdC8qKlxyXG5cdCAqIOagvOWtkOeahOexu+Wei1xyXG5cdCAqL1xyXG5cdHB1YmxpYyB0eXBlOiBFX05vZGVfVHlwZTtcclxuXHJcblx0LyoqXHJcblx0ICog5qC85a2Q57G75p6E6YCg5Ye95pWw77yM5Lyg5YWl5Z2Q5qCH5ZKM5qC85a2Q57G75Z6LXHJcblx0ICogQHBhcmFtIHggXHJcblx0ICogQHBhcmFtIHkgXHJcblx0ICogQHBhcmFtIHR5cGUgXHJcblx0ICovXHJcblx0Y29uc3RydWN0b3IoeCwgeSwgdHlwZSkge1xyXG5cdFx0dGhpcy54ID0geDtcclxuXHRcdHRoaXMueSA9IHk7XHJcblx0XHR0aGlzLnR5cGUgPSB0eXBlO1xyXG5cdH1cclxuXHJcbn1cclxuIl19