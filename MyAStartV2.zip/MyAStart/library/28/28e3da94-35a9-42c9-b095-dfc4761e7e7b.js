System.register(["cc", "code-quality:cr", "./MapCfgData.js"], function (_export, _context) {
  "use strict";

  var _cclegacy, _reporterNs, _decorator, Component, Node, GraphicsComponent, Color, loader, ModelComponent, GFXPrimitiveMode, utils, GFXAttributeName, GFXFormat, Material, JsonAsset, MapCfgData, _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _temp, _crd, ccclass, property, MapMgr;

  function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

  function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

  function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

  function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfMapCfgData(extras) {
    _reporterNs.report("MapCfgData", "./MapCfgData", _context.meta, extras);
  }

  _export({
    _dec: void 0,
    _dec2: void 0,
    _dec3: void 0,
    _class: void 0,
    _class2: void 0,
    _descriptor: void 0,
    _descriptor2: void 0,
    _temp: void 0
  });

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      GraphicsComponent = _cc.GraphicsComponent;
      Color = _cc.Color;
      loader = _cc.loader;
      ModelComponent = _cc.ModelComponent;
      GFXPrimitiveMode = _cc.GFXPrimitiveMode;
      utils = _cc.utils;
      GFXAttributeName = _cc.GFXAttributeName;
      GFXFormat = _cc.GFXFormat;
      Material = _cc.Material;
      JsonAsset = _cc.JsonAsset;
    }, function (_codeQualityCr) {
      _reporterNs = _codeQualityCr;
    }, function (_MapCfgDataJs) {
      MapCfgData = _MapCfgDataJs.MapCfgData;
    }],
    execute: function () {
      _cclegacy._RF.push({}, "28e3dqUNalCybCV38R2Hn57", "MapMgr", _context.meta);

      _crd = true;
      ccclass = _decorator.ccclass;
      property = _decorator.property;

      _export("MapMgr", MapMgr = (_dec = ccclass('MapMgr'), _dec2 = property({
        type: GraphicsComponent
      }), _dec3 = property({
        type: Node
      }), _dec(_class = (_class2 = (_temp = /*#__PURE__*/function (_Component) {
        _inherits(MapMgr, _Component);

        /**
         * 地图配置表路径
         */
        function MapMgr() {
          var _this;

          _classCallCheck(this, MapMgr);

          _this = _possibleConstructorReturn(this, _getPrototypeOf(MapMgr).call(this));

          _initializerDefineProperty(_this, "graph", _descriptor, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "targerNode", _descriptor2, _assertThisInitialized(_this));

          _this.gridW = 6;
          _this.gridH = 6;
          _this.path = "configs/MapCfg.json";
          _this.mapCfgArr = [];
          _this.graph;
          return _this;
        }

        _createClass(MapMgr, [{
          key: "onLoad",
          value: function onLoad() {
            var self = this;
            self.InitMapCfg(self.path); // self.DrawMap(2, 2);
          }
        }, {
          key: "InitMapCfg",

          /**
           * 初始化地图数据
           * @param path 配置表路径
           */
          value: function InitMapCfg(path) {
            var self = this;
            loader.loadRes(path, null, null, null, function (err, obj) {
              if (err) {
                console.log("err while read" + err);
                return;
              } //解析数据


              var mapData = JsonAsset.deserialize(obj);
              var data = mapData.json;

              for (var i = 0; i < data.length; i++) {
                var currId = data[i].id;
                var currMapX = data[i].mapX;
                var currMapY = data[i].mapY;
                var currType = data[i].type;
                var map = new (_crd && MapCfgData === void 0 ? (_reportPossibleCrUseOfMapCfgData({
                  error: Error()
                }), MapCfgData) : MapCfgData)(currId, currMapX, currMapY, currType);
                self.mapCfgArr.push(map);
                console.log("data[0]'s value is:" + data[i].des);
                console.log("now ,I want to know map's value:" + map.id + "  " + "  " + map.mapX + "  " + map.mapY + "  " + map.type);
                console.log("Also,I want to know mapCfgArr's length is: " + self.mapCfgArr.length);
              }

              console.log("MapDataCfg init successfully!!! ");
            });
          }
          /**
           * 获取ID对应的MapData
           * @param id 
           */

        }, {
          key: "GetMapCfgDataByID",
          value: function GetMapCfgDataByID(id) {
            var self = this;
            var mcd = null;
            self.mapCfgArr.forEach(function (element) {
              if (element.id == id) mcd = element;else console.log("Not found it...");
            });
            return mcd;
          }
          /**
           * 绘制网格
           * @param col 列
           * @param row 行
           * @param color 颜色
           */

        }, {
          key: "DrawMap",
          value: function DrawMap(col, row) {
            var color = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : Color.GREEN;
            var self = this;
            console.log("what about graph is:" + self.graph.name);
            color = color != undefined ? color : Color.GRAY;
            console.log("self.graph.fillColor is:" + self.graph.fillColor);
            self.graph.fillColor = color;
            var posX = 2 + col * (self.gridW + 2);
            var posY = 2 + row * (self.gridH + 2);
            self.graph.fillRect(posX, posY, self.gridW, self.gridH);
            console.log("Draw Map ...");
          }
          /**
           * 创建Mesh
           * @param effectName 节点名
           */

        }, {
          key: "CreateGrid",
          value: function CreateGrid(effectName) {
            var self = this;
            var node = new Node(effectName);
            node.parent = self.targerNode;
            node.setWorldPosition(cc.v3(0, 0, 0));
            var model = node.addComponent(ModelComponent);
            var positions = [];
            var colors = [];
            var indices = []; // 直接创建一大块Mesh用的内存，方便后面动态加线

            for (var i = 0; i < self.maxTick * self.maxTick; i++) {
              positions.push(0, 0);
              colors.push(1, 1, 1, 1);
            }

            for (var _i = 0; _i < positions.length; _i += 2) {
              indices.push(_i / 2);
            }

            var primitiveMode = GFXPrimitiveMode.LINE_LIST; // 使用二维顶点来节省顶点数据

            var attributes = [{
              name: GFXAttributeName.ATTR_POSITION,
              format: GFXFormat.RG32F
            }];
            var mesh = utils.createMesh({
              positions: positions,
              indices: indices,
              colors: colors,
              primitiveMode: primitiveMode,
              attributes: attributes
            });
            model.mesh = mesh; // for material

            var mtl = new Material();
            mtl.initialize({
              effectName: effectName,
              states: {
                primitive: primitiveMode
              }
            });
            model.material = mtl;
            return model;
          }
        }]);

        return MapMgr;
      }(Component), _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "graph", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "targerNode", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      _crd = false;

      _cclegacy._RF.pop();
    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vRDovQ29Db3MzRExzdC9NeUFTdGFydC9hc3NldHMvc2NpcHRzL015L01hcE1nci50cyJdLCJuYW1lcyI6WyJfZGVjb3JhdG9yIiwiQ29tcG9uZW50IiwiTm9kZSIsIkdyYXBoaWNzQ29tcG9uZW50IiwiQ29sb3IiLCJsb2FkZXIiLCJNb2RlbENvbXBvbmVudCIsIkdGWFByaW1pdGl2ZU1vZGUiLCJ1dGlscyIsIkdGWEF0dHJpYnV0ZU5hbWUiLCJHRlhGb3JtYXQiLCJNYXRlcmlhbCIsIkpzb25Bc3NldCIsIk1hcENmZ0RhdGEiLCJjY2NsYXNzIiwicHJvcGVydHkiLCJNYXBNZ3IiLCJ0eXBlIiwiZ3JpZFciLCJncmlkSCIsInBhdGgiLCJtYXBDZmdBcnIiLCJncmFwaCIsInNlbGYiLCJJbml0TWFwQ2ZnIiwibG9hZFJlcyIsImVyciIsIm9iaiIsImNvbnNvbGUiLCJsb2ciLCJtYXBEYXRhIiwiZGVzZXJpYWxpemUiLCJkYXRhIiwianNvbiIsImkiLCJsZW5ndGgiLCJjdXJySWQiLCJpZCIsImN1cnJNYXBYIiwibWFwWCIsImN1cnJNYXBZIiwibWFwWSIsImN1cnJUeXBlIiwibWFwIiwicHVzaCIsImRlcyIsIm1jZCIsImZvckVhY2giLCJlbGVtZW50IiwiY29sIiwicm93IiwiY29sb3IiLCJHUkVFTiIsIm5hbWUiLCJ1bmRlZmluZWQiLCJHUkFZIiwiZmlsbENvbG9yIiwicG9zWCIsInBvc1kiLCJmaWxsUmVjdCIsImVmZmVjdE5hbWUiLCJub2RlIiwicGFyZW50IiwidGFyZ2VyTm9kZSIsInNldFdvcmxkUG9zaXRpb24iLCJjYyIsInYzIiwibW9kZWwiLCJhZGRDb21wb25lbnQiLCJwb3NpdGlvbnMiLCJjb2xvcnMiLCJpbmRpY2VzIiwibWF4VGljayIsInByaW1pdGl2ZU1vZGUiLCJMSU5FX0xJU1QiLCJhdHRyaWJ1dGVzIiwiQVRUUl9QT1NJVElPTiIsImZvcm1hdCIsIlJHMzJGIiwibWVzaCIsImNyZWF0ZU1lc2giLCJtdGwiLCJpbml0aWFsaXplIiwic3RhdGVzIiwicHJpbWl0aXZlIiwibWF0ZXJpYWwiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQVNBLE1BQUFBLFUsT0FBQUEsVTtBQUFZQyxNQUFBQSxTLE9BQUFBLFM7QUFBV0MsTUFBQUEsSSxPQUFBQSxJO0FBQU1DLE1BQUFBLGlCLE9BQUFBLGlCO0FBQW1CQyxNQUFBQSxLLE9BQUFBLEs7QUFBaUNDLE1BQUFBLE0sT0FBQUEsTTtBQUFRQyxNQUFBQSxjLE9BQUFBLGM7QUFBc0JDLE1BQUFBLGdCLE9BQUFBLGdCO0FBQWtCQyxNQUFBQSxLLE9BQUFBLEs7QUFBT0MsTUFBQUEsZ0IsT0FBQUEsZ0I7QUFBa0JDLE1BQUFBLFMsT0FBQUEsUztBQUFXQyxNQUFBQSxRLE9BQUFBLFE7QUFBVUMsTUFBQUEsUyxPQUFBQSxTOzs7O0FBQy9LQyxNQUFBQSxVLGlCQUFBQSxVOzs7Ozs7QUFFREMsTUFBQUEsTyxHQUFzQmQsVSxDQUF0QmMsTztBQUFTQyxNQUFBQSxRLEdBQWFmLFUsQ0FBYmUsUTs7d0JBR0pDLE0sV0FEWkYsT0FBTyxDQUFDLFFBQUQsQyxVQUdIQyxRQUFRLENBQUM7QUFBRUUsUUFBQUEsSUFBSSxFQUFFZDtBQUFSLE9BQUQsQyxVQUdSWSxRQUFRLENBQUM7QUFBRUUsUUFBQUEsSUFBSSxFQUFFZjtBQUFSLE9BQUQsQzs7O0FBVVQ7OztBQUtBLDBCQUFjO0FBQUE7O0FBQUE7O0FBQ1Y7O0FBRFU7O0FBQUE7O0FBQUEsZ0JBWlBnQixLQVlPLEdBWkMsQ0FZRDtBQUFBLGdCQVhQQyxLQVdPLEdBWEMsQ0FXRDtBQUFBLGdCQUZHQyxJQUVILEdBRlUscUJBRVY7QUFBQSxnQkFZUEMsU0FaTyxHQVl3QixFQVp4QjtBQUVWLGdCQUFLQyxLQUFMO0FBRlU7QUFHYjs7OzttQ0FFUTtBQUNMLGdCQUFJQyxJQUFJLEdBQUcsSUFBWDtBQUVBQSxZQUFBQSxJQUFJLENBQUNDLFVBQUwsQ0FBZ0JELElBQUksQ0FBQ0gsSUFBckIsRUFISyxDQUlMO0FBQ0g7Ozs7QUFJRDs7OztxQ0FJbUJBLEksRUFBYztBQUM3QixnQkFBSUcsSUFBSSxHQUFHLElBQVg7QUFFQWxCLFlBQUFBLE1BQU0sQ0FBQ29CLE9BQVAsQ0FBcUJMLElBQXJCLEVBQTJCLElBQTNCLEVBQWlDLElBQWpDLEVBQXVDLElBQXZDLEVBQTZDLFVBQVVNLEdBQVYsRUFBZUMsR0FBZixFQUFvQjtBQUM3RCxrQkFBSUQsR0FBSixFQUFTO0FBQ0xFLGdCQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxtQkFBbUJILEdBQS9CO0FBQ0E7QUFDSCxlQUo0RCxDQU03RDs7O0FBQ0Esa0JBQUlJLE9BQU8sR0FBR2xCLFNBQVMsQ0FBQ21CLFdBQVYsQ0FBc0JKLEdBQXRCLENBQWQ7QUFDQSxrQkFBSUssSUFBSSxHQUFHRixPQUFPLENBQUNHLElBQW5COztBQUNBLG1CQUFLLElBQUlDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdGLElBQUksQ0FBQ0csTUFBekIsRUFBaUNELENBQUMsRUFBbEMsRUFBc0M7QUFDbEMsb0JBQUlFLE1BQU0sR0FBR0osSUFBSSxDQUFDRSxDQUFELENBQUosQ0FBUUcsRUFBckI7QUFDQSxvQkFBSUMsUUFBUSxHQUFHTixJQUFJLENBQUNFLENBQUQsQ0FBSixDQUFRSyxJQUF2QjtBQUNBLG9CQUFJQyxRQUFRLEdBQUdSLElBQUksQ0FBQ0UsQ0FBRCxDQUFKLENBQVFPLElBQXZCO0FBQ0Esb0JBQUlDLFFBQVEsR0FBR1YsSUFBSSxDQUFDRSxDQUFELENBQUosQ0FBUWpCLElBQXZCO0FBRUEsb0JBQUkwQixHQUFlLEdBQUc7QUFBQTtBQUFBLDhDQUFlUCxNQUFmLEVBQXVCRSxRQUF2QixFQUFpQ0UsUUFBakMsRUFBMkNFLFFBQTNDLENBQXRCO0FBQ0FuQixnQkFBQUEsSUFBSSxDQUFDRixTQUFMLENBQWV1QixJQUFmLENBQW9CRCxHQUFwQjtBQUNBZixnQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksd0JBQXdCRyxJQUFJLENBQUNFLENBQUQsQ0FBSixDQUFRVyxHQUE1QztBQUNBakIsZ0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLHFDQUFtQ2MsR0FBRyxDQUFDTixFQUF2QyxHQUEwQyxJQUExQyxHQUErQyxJQUEvQyxHQUFvRE0sR0FBRyxDQUFDSixJQUF4RCxHQUE2RCxJQUE3RCxHQUFrRUksR0FBRyxDQUFDRixJQUF0RSxHQUEyRSxJQUEzRSxHQUFnRkUsR0FBRyxDQUFDMUIsSUFBaEc7QUFDQVcsZ0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGdEQUE4Q04sSUFBSSxDQUFDRixTQUFMLENBQWVjLE1BQXpFO0FBQ0g7O0FBRURQLGNBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGtDQUFaO0FBQ0gsYUF2QkQ7QUF3Qkg7QUFFRDs7Ozs7Ozs0Q0FJeUJRLEUsRUFBZ0I7QUFDckMsZ0JBQUlkLElBQUksR0FBRyxJQUFYO0FBQ0EsZ0JBQUl1QixHQUFlLEdBQUcsSUFBdEI7QUFFQXZCLFlBQUFBLElBQUksQ0FBQ0YsU0FBTCxDQUFlMEIsT0FBZixDQUF1QixVQUFBQyxPQUFPLEVBQUk7QUFDOUIsa0JBQUlBLE9BQU8sQ0FBQ1gsRUFBUixJQUFjQSxFQUFsQixFQUNJUyxHQUFHLEdBQUdFLE9BQU4sQ0FESixLQUdJcEIsT0FBTyxDQUFDQyxHQUFSLENBQVksaUJBQVo7QUFDUCxhQUxEO0FBT0EsbUJBQU9pQixHQUFQO0FBQ0g7QUFHRDs7Ozs7Ozs7O2tDQU1lRyxHLEVBQUtDLEcsRUFBMEI7QUFBQSxnQkFBckJDLEtBQXFCLHVFQUFiL0MsS0FBSyxDQUFDZ0QsS0FBTztBQUMxQyxnQkFBSTdCLElBQUksR0FBRyxJQUFYO0FBQ0FLLFlBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLHlCQUF5Qk4sSUFBSSxDQUFDRCxLQUFMLENBQVcrQixJQUFoRDtBQUNBRixZQUFBQSxLQUFLLEdBQUdBLEtBQUssSUFBSUcsU0FBVCxHQUFxQkgsS0FBckIsR0FBNkIvQyxLQUFLLENBQUNtRCxJQUEzQztBQUNBM0IsWUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksNkJBQTZCTixJQUFJLENBQUNELEtBQUwsQ0FBV2tDLFNBQXBEO0FBQ0FqQyxZQUFBQSxJQUFJLENBQUNELEtBQUwsQ0FBV2tDLFNBQVgsR0FBdUJMLEtBQXZCO0FBRUEsZ0JBQUlNLElBQUksR0FBRyxJQUFJUixHQUFHLElBQUkxQixJQUFJLENBQUNMLEtBQUwsR0FBYSxDQUFqQixDQUFsQjtBQUNBLGdCQUFJd0MsSUFBSSxHQUFHLElBQUlSLEdBQUcsSUFBSTNCLElBQUksQ0FBQ0osS0FBTCxHQUFhLENBQWpCLENBQWxCO0FBQ0FJLFlBQUFBLElBQUksQ0FBQ0QsS0FBTCxDQUFXcUMsUUFBWCxDQUFvQkYsSUFBcEIsRUFBMEJDLElBQTFCLEVBQWdDbkMsSUFBSSxDQUFDTCxLQUFyQyxFQUE0Q0ssSUFBSSxDQUFDSixLQUFqRDtBQUNBUyxZQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxjQUFaO0FBQ0g7QUFFRDs7Ozs7OztxQ0FJa0IrQixVLEVBQW9CO0FBRWxDLGdCQUFJckMsSUFBSSxHQUFHLElBQVg7QUFFQSxnQkFBTXNDLElBQUksR0FBRyxJQUFJM0QsSUFBSixDQUFTMEQsVUFBVCxDQUFiO0FBRUFDLFlBQUFBLElBQUksQ0FBQ0MsTUFBTCxHQUFjdkMsSUFBSSxDQUFDd0MsVUFBbkI7QUFDQUYsWUFBQUEsSUFBSSxDQUFDRyxnQkFBTCxDQUFzQkMsRUFBRSxDQUFDQyxFQUFILENBQU0sQ0FBTixFQUFTLENBQVQsRUFBWSxDQUFaLENBQXRCO0FBQ0EsZ0JBQU1DLEtBQUssR0FBR04sSUFBSSxDQUFDTyxZQUFMLENBQWtCOUQsY0FBbEIsQ0FBZDtBQUVBLGdCQUFNK0QsU0FBUyxHQUFHLEVBQWxCO0FBQ0EsZ0JBQU1DLE1BQU0sR0FBRyxFQUFmO0FBQ0EsZ0JBQU1DLE9BQU8sR0FBRyxFQUFoQixDQVprQyxDQWNsQzs7QUFDQSxpQkFBSyxJQUFJckMsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR1gsSUFBSSxDQUFDaUQsT0FBTCxHQUFlakQsSUFBSSxDQUFDaUQsT0FBeEMsRUFBaUR0QyxDQUFDLEVBQWxELEVBQXNEO0FBQ2xEbUMsY0FBQUEsU0FBUyxDQUFDekIsSUFBVixDQUFlLENBQWYsRUFBa0IsQ0FBbEI7QUFDQTBCLGNBQUFBLE1BQU0sQ0FBQzFCLElBQVAsQ0FBWSxDQUFaLEVBQWUsQ0FBZixFQUFrQixDQUFsQixFQUFxQixDQUFyQjtBQUNIOztBQUVELGlCQUFLLElBQUlWLEVBQUMsR0FBRyxDQUFiLEVBQWdCQSxFQUFDLEdBQUdtQyxTQUFTLENBQUNsQyxNQUE5QixFQUFzQ0QsRUFBQyxJQUFJLENBQTNDLEVBQThDO0FBQzFDcUMsY0FBQUEsT0FBTyxDQUFDM0IsSUFBUixDQUFhVixFQUFDLEdBQUcsQ0FBakI7QUFDSDs7QUFFRCxnQkFBTXVDLGFBQWEsR0FBR2xFLGdCQUFnQixDQUFDbUUsU0FBdkMsQ0F4QmtDLENBeUJsQzs7QUFDQSxnQkFBTUMsVUFBVSxHQUFHLENBQUM7QUFDaEJ0QixjQUFBQSxJQUFJLEVBQUU1QyxnQkFBZ0IsQ0FBQ21FLGFBRFA7QUFFaEJDLGNBQUFBLE1BQU0sRUFBRW5FLFNBQVMsQ0FBQ29FO0FBRkYsYUFBRCxDQUFuQjtBQUlBLGdCQUFNQyxJQUFJLEdBQUd2RSxLQUFLLENBQUN3RSxVQUFOLENBQWlCO0FBQUVYLGNBQUFBLFNBQVMsRUFBVEEsU0FBRjtBQUFhRSxjQUFBQSxPQUFPLEVBQVBBLE9BQWI7QUFBc0JELGNBQUFBLE1BQU0sRUFBTkEsTUFBdEI7QUFBOEJHLGNBQUFBLGFBQWEsRUFBYkEsYUFBOUI7QUFBNkNFLGNBQUFBLFVBQVUsRUFBVkE7QUFBN0MsYUFBakIsQ0FBYjtBQUdBUixZQUFBQSxLQUFLLENBQUNZLElBQU4sR0FBYUEsSUFBYixDQWpDa0MsQ0FtQ2xDOztBQUNBLGdCQUFNRSxHQUFHLEdBQUcsSUFBSXRFLFFBQUosRUFBWjtBQUNBc0UsWUFBQUEsR0FBRyxDQUFDQyxVQUFKLENBQWU7QUFBRXRCLGNBQUFBLFVBQVUsRUFBVkEsVUFBRjtBQUFjdUIsY0FBQUEsTUFBTSxFQUFFO0FBQUVDLGdCQUFBQSxTQUFTLEVBQUVYO0FBQWI7QUFBdEIsYUFBZjtBQUNBTixZQUFBQSxLQUFLLENBQUNrQixRQUFOLEdBQWlCSixHQUFqQjtBQUVBLG1CQUFPZCxLQUFQO0FBQ0g7Ozs7UUF0SnVCbEUsUzs7Ozs7aUJBR1UsSTs7Ozs7OztpQkFHUixJIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgX2RlY29yYXRvciwgQ29tcG9uZW50LCBOb2RlLCBHcmFwaGljc0NvbXBvbmVudCwgQ29sb3IsIEdGWF9EUkFXX0lORk9fU0laRSwgcGF0aCwgbG9hZGVyLCBNb2RlbENvbXBvbmVudCwgTWVzaCwgR0ZYUHJpbWl0aXZlTW9kZSwgdXRpbHMsIEdGWEF0dHJpYnV0ZU5hbWUsIEdGWEZvcm1hdCwgTWF0ZXJpYWwsIEpzb25Bc3NldCwgYW5pbWF0aW9uIH0gZnJvbSAnY2MnO1xyXG5pbXBvcnQgeyBNYXBDZmdEYXRhIH0gZnJvbSAnLi9NYXBDZmdEYXRhJztcclxuaW1wb3J0IHsgRV9Ob2RlX1R5cGUgfSBmcm9tICcuL0FTdGFyTm9kZSc7XHJcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IF9kZWNvcmF0b3I7XHJcblxyXG5AY2NjbGFzcygnTWFwTWdyJylcclxuZXhwb3J0IGNsYXNzIE1hcE1nciBleHRlbmRzIENvbXBvbmVudCB7XHJcblxyXG4gICAgQHByb3BlcnR5KHsgdHlwZTogR3JhcGhpY3NDb21wb25lbnQgfSlcclxuICAgIHB1YmxpYyBncmFwaDogR3JhcGhpY3NDb21wb25lbnQgPSBudWxsO1xyXG5cclxuICAgIEBwcm9wZXJ0eSh7IHR5cGU6IE5vZGUgfSlcclxuICAgIHB1YmxpYyB0YXJnZXJOb2RlOiBOb2RlID0gbnVsbDtcclxuXHJcbiAgICBwdWJsaWMgZ3JpZFcgPSA2O1xyXG4gICAgcHVibGljIGdyaWRIID0gNjtcclxuXHJcbiAgICBwdWJsaWMgbWVzaFY6IE1lc2g7XHJcblxyXG4gICAgcHJpdmF0ZSBtYXhUaWNrO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICog5Zyw5Zu+6YWN572u6KGo6Lev5b6EXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgcmVhZG9ubHkgcGF0aCA9IFwiY29uZmlncy9NYXBDZmcuanNvblwiO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgICAgIHN1cGVyKCk7XHJcbiAgICAgICAgdGhpcy5ncmFwaDtcclxuICAgIH1cclxuXHJcbiAgICBvbkxvYWQoKSB7XHJcbiAgICAgICAgbGV0IHNlbGYgPSB0aGlzO1xyXG5cclxuICAgICAgICBzZWxmLkluaXRNYXBDZmcoc2VsZi5wYXRoKTtcclxuICAgICAgICAvLyBzZWxmLkRyYXdNYXAoMiwgMik7XHJcbiAgICB9XHJcblxyXG4gICAgcHVibGljIG1hcENmZ0FycjogQXJyYXk8TWFwQ2ZnRGF0YT4gPSBbXTtcclxuXHJcbiAgICAvKipcclxuICAgICAqIOWIneWni+WMluWcsOWbvuaVsOaNrlxyXG4gICAgICogQHBhcmFtIHBhdGgg6YWN572u6KGo6Lev5b6EXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgSW5pdE1hcENmZyhwYXRoOiBzdHJpbmcpIHtcclxuICAgICAgICBsZXQgc2VsZiA9IHRoaXM7XHJcblxyXG4gICAgICAgIGxvYWRlci5sb2FkUmVzPEpTT04+KHBhdGgsIG51bGwsIG51bGwsIG51bGwsIGZ1bmN0aW9uIChlcnIsIG9iaikge1xyXG4gICAgICAgICAgICBpZiAoZXJyKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImVyciB3aGlsZSByZWFkXCIgKyBlcnIpO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAvL+ino+aekOaVsOaNrlxyXG4gICAgICAgICAgICBsZXQgbWFwRGF0YSA9IEpzb25Bc3NldC5kZXNlcmlhbGl6ZShvYmopOyAgICBcclxuICAgICAgICAgICAgbGV0IGRhdGEgPSBtYXBEYXRhLmpzb247ICAgIFxyXG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRhdGEubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgIGxldCBjdXJySWQgPSBkYXRhW2ldLmlkO1xyXG4gICAgICAgICAgICAgICAgbGV0IGN1cnJNYXBYID0gZGF0YVtpXS5tYXBYO1xyXG4gICAgICAgICAgICAgICAgbGV0IGN1cnJNYXBZID0gZGF0YVtpXS5tYXBZO1xyXG4gICAgICAgICAgICAgICAgbGV0IGN1cnJUeXBlID0gZGF0YVtpXS50eXBlO1xyXG5cclxuICAgICAgICAgICAgICAgIGxldCBtYXA6IE1hcENmZ0RhdGEgPSBuZXcgTWFwQ2ZnRGF0YShjdXJySWQsIGN1cnJNYXBYLCBjdXJyTWFwWSwgY3VyclR5cGUpO1xyXG4gICAgICAgICAgICAgICAgc2VsZi5tYXBDZmdBcnIucHVzaChtYXApO1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJkYXRhWzBdJ3MgdmFsdWUgaXM6XCIgKyBkYXRhW2ldLmRlcyk7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIm5vdyAsSSB3YW50IHRvIGtub3cgbWFwJ3MgdmFsdWU6XCIrbWFwLmlkK1wiICBcIitcIiAgXCIrbWFwLm1hcFgrXCIgIFwiK21hcC5tYXBZK1wiICBcIittYXAudHlwZSk7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkFsc28sSSB3YW50IHRvIGtub3cgbWFwQ2ZnQXJyJ3MgbGVuZ3RoIGlzOiBcIitzZWxmLm1hcENmZ0Fyci5sZW5ndGgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgXHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiTWFwRGF0YUNmZyBpbml0IHN1Y2Nlc3NmdWxseSEhISBcIik7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiDojrflj5ZJROWvueW6lOeahE1hcERhdGFcclxuICAgICAqIEBwYXJhbSBpZCBcclxuICAgICAqL1xyXG4gICAgcHVibGljIEdldE1hcENmZ0RhdGFCeUlEKGlkKTogTWFwQ2ZnRGF0YSB7XHJcbiAgICAgICAgbGV0IHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIGxldCBtY2Q6IE1hcENmZ0RhdGEgPSBudWxsO1xyXG5cclxuICAgICAgICBzZWxmLm1hcENmZ0Fyci5mb3JFYWNoKGVsZW1lbnQgPT4ge1xyXG4gICAgICAgICAgICBpZiAoZWxlbWVudC5pZCA9PSBpZClcclxuICAgICAgICAgICAgICAgIG1jZCA9IGVsZW1lbnQ7XHJcbiAgICAgICAgICAgIGVsc2VcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiTm90IGZvdW5kIGl0Li4uXCIpO1xyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICByZXR1cm4gbWNkO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIOe7mOWItue9keagvFxyXG4gICAgICogQHBhcmFtIGNvbCDliJdcclxuICAgICAqIEBwYXJhbSByb3cg6KGMXHJcbiAgICAgKiBAcGFyYW0gY29sb3Ig6aKc6ImyXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBEcmF3TWFwKGNvbCwgcm93LCBjb2xvciA9IENvbG9yLkdSRUVOKSB7XHJcbiAgICAgICAgbGV0IHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwid2hhdCBhYm91dCBncmFwaCBpczpcIiArIHNlbGYuZ3JhcGgubmFtZSk7XHJcbiAgICAgICAgY29sb3IgPSBjb2xvciAhPSB1bmRlZmluZWQgPyBjb2xvciA6IENvbG9yLkdSQVk7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJzZWxmLmdyYXBoLmZpbGxDb2xvciBpczpcIiArIHNlbGYuZ3JhcGguZmlsbENvbG9yKTtcclxuICAgICAgICBzZWxmLmdyYXBoLmZpbGxDb2xvciA9IGNvbG9yO1xyXG5cclxuICAgICAgICBsZXQgcG9zWCA9IDIgKyBjb2wgKiAoc2VsZi5ncmlkVyArIDIpO1xyXG4gICAgICAgIGxldCBwb3NZID0gMiArIHJvdyAqIChzZWxmLmdyaWRIICsgMik7XHJcbiAgICAgICAgc2VsZi5ncmFwaC5maWxsUmVjdChwb3NYLCBwb3NZLCBzZWxmLmdyaWRXLCBzZWxmLmdyaWRIKTtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIkRyYXcgTWFwIC4uLlwiKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIOWIm+W7uk1lc2hcclxuICAgICAqIEBwYXJhbSBlZmZlY3ROYW1lIOiKgueCueWQjVxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgQ3JlYXRlR3JpZChlZmZlY3ROYW1lOiBzdHJpbmcpIHtcclxuXHJcbiAgICAgICAgbGV0IHNlbGYgPSB0aGlzO1xyXG5cclxuICAgICAgICBjb25zdCBub2RlID0gbmV3IE5vZGUoZWZmZWN0TmFtZSk7XHJcblxyXG4gICAgICAgIG5vZGUucGFyZW50ID0gc2VsZi50YXJnZXJOb2RlO1xyXG4gICAgICAgIG5vZGUuc2V0V29ybGRQb3NpdGlvbihjYy52MygwLCAwLCAwKSk7XHJcbiAgICAgICAgY29uc3QgbW9kZWwgPSBub2RlLmFkZENvbXBvbmVudChNb2RlbENvbXBvbmVudCk7XHJcblxyXG4gICAgICAgIGNvbnN0IHBvc2l0aW9ucyA9IFtdO1xyXG4gICAgICAgIGNvbnN0IGNvbG9ycyA9IFtdO1xyXG4gICAgICAgIGNvbnN0IGluZGljZXMgPSBbXTtcclxuXHJcbiAgICAgICAgLy8g55u05o6l5Yib5bu65LiA5aSn5Z2XTWVzaOeUqOeahOWGheWtmO+8jOaWueS+v+WQjumdouWKqOaAgeWKoOe6v1xyXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc2VsZi5tYXhUaWNrICogc2VsZi5tYXhUaWNrOyBpKyspIHtcclxuICAgICAgICAgICAgcG9zaXRpb25zLnB1c2goMCwgMCk7XHJcbiAgICAgICAgICAgIGNvbG9ycy5wdXNoKDEsIDEsIDEsIDEpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBwb3NpdGlvbnMubGVuZ3RoOyBpICs9IDIpIHtcclxuICAgICAgICAgICAgaW5kaWNlcy5wdXNoKGkgLyAyKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IHByaW1pdGl2ZU1vZGUgPSBHRlhQcmltaXRpdmVNb2RlLkxJTkVfTElTVDtcclxuICAgICAgICAvLyDkvb/nlKjkuoznu7TpobbngrnmnaXoioLnnIHpobbngrnmlbDmja5cclxuICAgICAgICBjb25zdCBhdHRyaWJ1dGVzID0gW3tcclxuICAgICAgICAgICAgbmFtZTogR0ZYQXR0cmlidXRlTmFtZS5BVFRSX1BPU0lUSU9OLFxyXG4gICAgICAgICAgICBmb3JtYXQ6IEdGWEZvcm1hdC5SRzMyRixcclxuICAgICAgICB9XTtcclxuICAgICAgICBjb25zdCBtZXNoID0gdXRpbHMuY3JlYXRlTWVzaCh7IHBvc2l0aW9ucywgaW5kaWNlcywgY29sb3JzLCBwcmltaXRpdmVNb2RlLCBhdHRyaWJ1dGVzIH0pO1xyXG5cclxuXHJcbiAgICAgICAgbW9kZWwubWVzaCA9IG1lc2g7XHJcblxyXG4gICAgICAgIC8vIGZvciBtYXRlcmlhbFxyXG4gICAgICAgIGNvbnN0IG10bCA9IG5ldyBNYXRlcmlhbCgpO1xyXG4gICAgICAgIG10bC5pbml0aWFsaXplKHsgZWZmZWN0TmFtZSwgc3RhdGVzOiB7IHByaW1pdGl2ZTogcHJpbWl0aXZlTW9kZSB9IH0pO1xyXG4gICAgICAgIG1vZGVsLm1hdGVyaWFsID0gbXRsO1xyXG5cclxuICAgICAgICByZXR1cm4gbW9kZWw7XHJcbiAgICB9XHJcblxyXG59XHJcbiJdfQ==