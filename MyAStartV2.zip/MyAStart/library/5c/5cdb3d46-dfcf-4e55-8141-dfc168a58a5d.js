System.register(["cc", "code-quality:cr", "./AStarNode.js", "./AStarMgr.js"], function (_export, _context) {
  "use strict";

  var _cclegacy, _reporterNs, _decorator, Component, Node, Material, Vec2, ModelComponent, Vec3, geometry, CameraComponent, systemEvent, SystemEventType, PhysicsSystem, Prefab, instantiate, E_Node_Type, AStarMgr, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _temp, _crd, ccclass, property, TestAStar;

  function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

  function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

  function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

  function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfE_Node_Type(extras) {
    _reporterNs.report("E_Node_Type", "./AStarNode", _context.meta, extras);
  }

  function _reportPossibleCrUseOfAStarMgr(extras) {
    _reporterNs.report("AStarMgr", "./AStarMgr", _context.meta, extras);
  }

  _export({
    _dec: void 0,
    _dec2: void 0,
    _dec3: void 0,
    _dec4: void 0,
    _dec5: void 0,
    _dec6: void 0,
    _dec7: void 0,
    _dec8: void 0,
    _class: void 0,
    _class2: void 0,
    _descriptor: void 0,
    _descriptor2: void 0,
    _descriptor3: void 0,
    _descriptor4: void 0,
    _descriptor5: void 0,
    _descriptor6: void 0,
    _descriptor7: void 0,
    _temp: void 0
  });

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      Material = _cc.Material;
      Vec2 = _cc.Vec2;
      ModelComponent = _cc.ModelComponent;
      Vec3 = _cc.Vec3;
      geometry = _cc.geometry;
      CameraComponent = _cc.CameraComponent;
      systemEvent = _cc.systemEvent;
      SystemEventType = _cc.SystemEventType;
      PhysicsSystem = _cc.PhysicsSystem;
      Prefab = _cc.Prefab;
      instantiate = _cc.instantiate;
    }, function (_codeQualityCr) {
      _reporterNs = _codeQualityCr;
    }, function (_AStarNodeJs) {
      E_Node_Type = _AStarNodeJs.E_Node_Type;
    }, function (_AStarMgrJs) {
      AStarMgr = _AStarMgrJs.AStarMgr;
    }],
    execute: function () {
      _cclegacy._RF.push({}, "5cdb31G389OVYFB38FopYpd", "TestAStar", _context.meta);

      _crd = true;
      ccclass = _decorator.ccclass;
      property = _decorator.property;

      _export("TestAStar", TestAStar = (_dec = ccclass('TestAStar'), _dec2 = property({
        type: Material
      }), _dec3 = property({
        type: Material
      }), _dec4 = property({
        type: Material
      }), _dec5 = property({
        type: Material
      }), _dec6 = property({
        type: Prefab
      }), _dec7 = property({
        type: CameraComponent
      }), _dec8 = property({
        type: Node
      }), _dec(_class = (_class2 = (_temp = /*#__PURE__*/function (_Component) {
        _inherits(TestAStar, _Component);

        function TestAStar() {
          var _getPrototypeOf2;

          var _this;

          _classCallCheck(this, TestAStar);

          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }

          _this = _possibleConstructorReturn(this, (_getPrototypeOf2 = _getPrototypeOf(TestAStar)).call.apply(_getPrototypeOf2, [this].concat(args)));
          _this.beginX = -3;
          _this.beginY = 5;
          _this.offsetX = 2;
          _this.offsetY = -2;
          _this.mapW = 4;
          _this.mapH = 4;

          _initializerDefineProperty(_this, "red", _descriptor, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "yellow", _descriptor2, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "blue", _descriptor3, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "normal", _descriptor4, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "instanObj", _descriptor5, _assertThisInitialized(_this));

          _this.beginPos = new Vec2(-1, 0);
          _this.cubes = new Array();
          _this.lst = new Array();

          _initializerDefineProperty(_this, "mainCamera", _descriptor6, _assertThisInitialized(_this));

          _this.ray = new geometry.ray();

          _initializerDefineProperty(_this, "spawnPos", _descriptor7, _assertThisInitialized(_this));

          return _this;
        }

        _createClass(TestAStar, [{
          key: "onLoad",
          value: function onLoad() {
            var self = this; //初始化AStarMgr
            //let aStarMgr:AStarMgr=self.node.getComponent('AStarMgr') as AStarMgr;
            //aStarMgr.Init();

            (_crd && AStarMgr === void 0 ? (_reportPossibleCrUseOfAStarMgr({
              error: Error()
            }), AStarMgr) : AStarMgr).Instance().InitMapInfo(self.mapW, self.mapH);

            for (var i = 0; i < self.mapW; ++i) {
              for (var j = 0; j < self.mapH; ++j) {
                //创建一个个立方体
                //let obj =this.node.CreatePrimitive(PrimitiveType.BOX);
                var obj = instantiate(self.instanObj); //设置父对象

                obj.parent = self.spawnPos; //console.log("obj.type is:"+obj);

                obj.position = new Vec3(self.beginX + i * self.offsetX, self.beginY + j * self.offsetY, 0); //console.log("obj.node.position is:"+obj.position);
                //名字

                obj.name = i + "_" + j; //存储立方体到字典容器中

                self.cubes.push(obj); //console.log("self.cubes.length is:"+self.cubes.length);
                //得到格子 判断它是不是阻挡

                var tempNode = (_crd && AStarMgr === void 0 ? (_reportPossibleCrUseOfAStarMgr({
                  error: Error()
                }), AStarMgr) : AStarMgr).Instance().nodes[i][j];

                if (tempNode.type == (_crd && E_Node_Type === void 0 ? (_reportPossibleCrUseOfE_Node_Type({
                  error: Error()
                }), E_Node_Type) : E_Node_Type).Stop) {
                  obj.getComponent(ModelComponent).material = self.red; //console.log("set obj'material:"+obj.getComponent(ModelComponent).material.toString());
                }
              } // console.log("continute for-time is:"+i);

            }
          }
        }, {
          key: "onEnable",
          value: function onEnable() {
            systemEvent.on(SystemEventType.TOUCH_START, this.TestAStar, this); //systemEvent.on(SystemEventType.KEY_DOWN, this.Test, this);
          }
        }, {
          key: "onDisable",
          value: function onDisable() {
            systemEvent.off(SystemEventType.TOUCH_START, this.TestAStar, this); // systemEvent.off(SystemEventType.KEY_UP, this.Test, this);
          }
          /**
           * 测试AStar
           */

        }, {
          key: "TestAStar",
          value: function TestAStar(touch, event) {
            var _this2 = this;

            var self = this; //console.log("Vect.UNIT_X is:"+Vec2.UNIT_X);
            //如果鼠标左键按下
            //进行射线检测

            var info = null; //射线检测完的信息
            //得到屏幕鼠标位置发出去的射线
            //console.log("Click successful!");

            self.mainCamera.screenPointToRay(touch._point.x, touch._point.y, self.ray); //#region  基于物理碰撞器的射线检测

            /* if (PhysicsSystem.instance.raycast(self.ray)) {
                 const r = PhysicsSystem.instance.raycastResults;
                 for (let i = 0; i < r.length; i++) {
                     const item = r[i];
                     console.log("Click obj is:"+item.collider.name);
                 }
             } else {
                  console.log("What are you want to do!");
             }*/
            //#endregion
            //射线检测

            if (PhysicsSystem.instance.raycast(self.ray)) {
              self.ReSetMaterial();
              info = PhysicsSystem.instance.raycastResults;
              console.log("Ray Info is:" + info[0].collider.name.toString()); //清理上一次的路径，把绿色立方体变成白色
              //如果不为空，证明找成功了

              if (self.lst != null) {
                for (var i = 0; i < self.lst.length; ++i) {
                  self.cubes[i].getComponent(ModelComponent).material = self.normal;
                  console.log("Reset self.cubes[i].material...");
                }
              } //console.log("self.beginPos is:"+self.beginPos);
              //console.log("self.beginPos equal new Vec2(-1.00,0.00) is:"+(self.beginPos == new Vec2(-1.00, 0.00)));
              //console.log("self.beginPos.x equal -1 and self.beginPos.y equal 0 is:"+(self.beginPos.x==-1&&self.beginPos.y==0));
              //得到点击到的立方体 才能知道是第几行第几列


              if (self.beginPos.x == -1 && self.beginPos.y == 0) {
                console.log("Set beginPos...");
                var strs = info[0].collider.node.name.split('_'); //得到行列位置 就是开始点位置

                self.beginPos = new Vec2(Number(strs[0].toString()), Number(strs[1].toString())); //console.log("set self.beginPos is:" + self.beginPos.toString());
                //把点击到的对象变成黄色

                info[0].collider.node.getComponent(ModelComponent).material = self.yellow;
              } //有起点了 那这就是 来点出终点 进行寻路
              else {
                  console.log("Set endPos..."); //得到终点

                  var _strs = info[0].collider.node.name.split('_');

                  var endPos = new Vec2(Number(_strs[0]), Number(_strs[1]));
                  console.log("endPos is:" + info[0].collider.node.name); //寻路

                  self.lst = (_crd && AStarMgr === void 0 ? (_reportPossibleCrUseOfAStarMgr({
                    error: Error()
                  }), AStarMgr) : AStarMgr).Instance().FindPath(self.beginPos, endPos); //避免死路的时候黄色不变成白色，所以事先清一遍。因为beginPos.x是float类型的所以要转换为int类型
                  //self.cubes[self.beginPos.x][.beginPos.y].getComponent(ModelComponent).material = this.normal;

                  var st = (self.beginPos.x + "_" + self.beginPos.y).toString();
                  self.cubes.forEach(function (element) {
                    if (element.name == st) {
                      //避免死路的时候黄色不变成白色，所以事先清一遍。因为beginPos.x是float类型的所以要转换为int类型
                      element.getComponent(ModelComponent).material = _this2.normal;
                      console.log("self.cubes[beginPos] is:" + element.name);
                    }
                  }); //如果不为空，证明找成功了

                  if (self.lst != null) {
                    var _loop = function _loop(j) {
                      var temp = (self.lst[j].x + "_" + self.lst[j].y).toString();
                      self.cubes.forEach(function (element) {
                        if (element.name == temp) {
                          element.getComponent(ModelComponent).material = self.blue; //console.log("打印变色的顺序："+element.name);
                        }
                      }); // self.cubes[j].getComponent(ModelComponent).material = this.blue;
                      /// console.log("打印路径顺序：" + self.lst[j].x + "_" + self.lst[j].y);
                    };

                    for (var j = 0; j < self.lst.length; ++j) {
                      _loop(j);
                    }
                  } //清除开始点 把它变成初始值


                  self.beginPos = new Vec2(-1, 0);
                }
            }
          }
          /**
           * 重置变成蓝色的对象为Normal
           */

        }, {
          key: "ReSetMaterial",
          value: function ReSetMaterial() {
            var self = this;

            if (self.lst != null) {
              var _loop2 = function _loop2(j) {
                var temp = (self.lst[j].x + "_" + self.lst[j].y).toString();
                self.cubes.forEach(function (element) {
                  if (element.name == temp) {
                    element.getComponent(ModelComponent).material = self.normal; //console.log("重置变色的顺序："+element.name);
                  }
                });
              };

              for (var j = 0; j < self.lst.length; ++j) {
                _loop2(j);
              }
            }
          }
        }]);

        return TestAStar;
      }(Component), _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "red", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "yellow", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "blue", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "normal", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "instanObj", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "mainCamera", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "spawnPos", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      _crd = false;

      _cclegacy._RF.pop();
    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vRDovQ29Db3MzRExzdC9NeUFTdGFydC9hc3NldHMvc2NpcHRzL015L1Rlc3RBU3Rhci50cyJdLCJuYW1lcyI6WyJfZGVjb3JhdG9yIiwiQ29tcG9uZW50IiwiTm9kZSIsIk1hdGVyaWFsIiwiVmVjMiIsIk1vZGVsQ29tcG9uZW50IiwiVmVjMyIsImdlb21ldHJ5IiwiQ2FtZXJhQ29tcG9uZW50Iiwic3lzdGVtRXZlbnQiLCJTeXN0ZW1FdmVudFR5cGUiLCJQaHlzaWNzU3lzdGVtIiwiUHJlZmFiIiwiaW5zdGFudGlhdGUiLCJFX05vZGVfVHlwZSIsIkFTdGFyTWdyIiwiY2NjbGFzcyIsInByb3BlcnR5IiwiVGVzdEFTdGFyIiwidHlwZSIsImJlZ2luWCIsImJlZ2luWSIsIm9mZnNldFgiLCJvZmZzZXRZIiwibWFwVyIsIm1hcEgiLCJiZWdpblBvcyIsImN1YmVzIiwiQXJyYXkiLCJsc3QiLCJyYXkiLCJzZWxmIiwiSW5zdGFuY2UiLCJJbml0TWFwSW5mbyIsImkiLCJqIiwib2JqIiwiaW5zdGFuT2JqIiwicGFyZW50Iiwic3Bhd25Qb3MiLCJwb3NpdGlvbiIsIm5hbWUiLCJwdXNoIiwidGVtcE5vZGUiLCJub2RlcyIsIlN0b3AiLCJnZXRDb21wb25lbnQiLCJtYXRlcmlhbCIsInJlZCIsIm9uIiwiVE9VQ0hfU1RBUlQiLCJvZmYiLCJ0b3VjaCIsImV2ZW50IiwiaW5mbyIsIm1haW5DYW1lcmEiLCJzY3JlZW5Qb2ludFRvUmF5IiwiX3BvaW50IiwieCIsInkiLCJpbnN0YW5jZSIsInJheWNhc3QiLCJSZVNldE1hdGVyaWFsIiwicmF5Y2FzdFJlc3VsdHMiLCJjb25zb2xlIiwibG9nIiwiY29sbGlkZXIiLCJ0b1N0cmluZyIsImxlbmd0aCIsIm5vcm1hbCIsInN0cnMiLCJub2RlIiwic3BsaXQiLCJOdW1iZXIiLCJ5ZWxsb3ciLCJlbmRQb3MiLCJGaW5kUGF0aCIsInN0IiwiZm9yRWFjaCIsImVsZW1lbnQiLCJ0ZW1wIiwiYmx1ZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFTQSxNQUFBQSxVLE9BQUFBLFU7QUFBWUMsTUFBQUEsUyxPQUFBQSxTO0FBQVdDLE1BQUFBLEksT0FBQUEsSTtBQUFNQyxNQUFBQSxRLE9BQUFBLFE7QUFBVUMsTUFBQUEsSSxPQUFBQSxJO0FBQU1DLE1BQUFBLGMsT0FBQUEsYztBQUFnQkMsTUFBQUEsSSxPQUFBQSxJO0FBQU1DLE1BQUFBLFEsT0FBQUEsUTtBQUFVQyxNQUFBQSxlLE9BQUFBLGU7QUFBaUJDLE1BQUFBLFcsT0FBQUEsVztBQUFhQyxNQUFBQSxlLE9BQUFBLGU7QUFBNkJDLE1BQUFBLGEsT0FBQUEsYTtBQUFpQ0MsTUFBQUEsTSxPQUFBQSxNO0FBQVFDLE1BQUFBLFcsT0FBQUEsVzs7OztBQUN0S0MsTUFBQUEsVyxnQkFBQUEsVzs7QUFDWEMsTUFBQUEsUSxlQUFBQSxROzs7Ozs7QUFDREMsTUFBQUEsTyxHQUFzQmhCLFUsQ0FBdEJnQixPO0FBQVNDLE1BQUFBLFEsR0FBYWpCLFUsQ0FBYmlCLFE7OzJCQUtKQyxTLFdBRFpGLE9BQU8sQ0FBQyxXQUFELEMsVUFpQ0hDLFFBQVEsQ0FBQztBQUFFRSxRQUFBQSxJQUFJLEVBQUVoQjtBQUFSLE9BQUQsQyxVQUdSYyxRQUFRLENBQUM7QUFBRUUsUUFBQUEsSUFBSSxFQUFFaEI7QUFBUixPQUFELEMsVUFHUmMsUUFBUSxDQUFDO0FBQUVFLFFBQUFBLElBQUksRUFBRWhCO0FBQVIsT0FBRCxDLFVBR1JjLFFBQVEsQ0FBQztBQUFFRSxRQUFBQSxJQUFJLEVBQUVoQjtBQUFSLE9BQUQsQyxVQUdSYyxRQUFRLENBQUM7QUFBRUUsUUFBQUEsSUFBSSxFQUFFUDtBQUFSLE9BQUQsQyxVQXNCUkssUUFBUSxDQUFDO0FBQUVFLFFBQUFBLElBQUksRUFBRVg7QUFBUixPQUFELEMsVUFXUlMsUUFBUSxDQUFDO0FBQUVFLFFBQUFBLElBQUksRUFBRWpCO0FBQVIsT0FBRCxDOzs7Ozs7Ozs7Ozs7Ozs7Z0JBeEVGa0IsTSxHQUFTLENBQUMsQztnQkFLVkMsTSxHQUFTLEM7Z0JBS1RDLE8sR0FBVSxDO2dCQUtWQyxPLEdBQVUsQ0FBQyxDO2dCQUtYQyxJLEdBQU8sQztnQkFLUEMsSSxHQUFPLEM7Ozs7Ozs7Ozs7OztnQkFxQk5DLFEsR0FBaUIsSUFBSXRCLElBQUosQ0FBUyxDQUFDLENBQVYsRUFBYSxDQUFiLEM7Z0JBS2pCdUIsSyxHQUFxQixJQUFJQyxLQUFKLEU7Z0JBS3JCQyxHLEdBQXdCLElBQUlELEtBQUosRTs7OztnQkFXeEJFLEcsR0FBb0IsSUFBSXZCLFFBQVEsQ0FBQ3VCLEdBQWIsRTs7Ozs7Ozs7O21DQVFaO0FBQ1osZ0JBQUlDLElBQUksR0FBRyxJQUFYLENBRFksQ0FHWjtBQUNBO0FBQ0E7O0FBRUE7QUFBQTtBQUFBLHNDQUFTQyxRQUFULEdBQW9CQyxXQUFwQixDQUFnQ0YsSUFBSSxDQUFDUCxJQUFyQyxFQUEyQ08sSUFBSSxDQUFDTixJQUFoRDs7QUFFQSxpQkFBSyxJQUFJUyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHSCxJQUFJLENBQUNQLElBQXpCLEVBQStCLEVBQUVVLENBQWpDLEVBQW9DO0FBQ2hDLG1CQUFLLElBQUlDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdKLElBQUksQ0FBQ04sSUFBekIsRUFBK0IsRUFBRVUsQ0FBakMsRUFBb0M7QUFDaEM7QUFDQTtBQUNBLG9CQUFJQyxHQUFHLEdBQUd2QixXQUFXLENBQUNrQixJQUFJLENBQUNNLFNBQU4sQ0FBckIsQ0FIZ0MsQ0FJaEM7O0FBQ0FELGdCQUFBQSxHQUFHLENBQUNFLE1BQUosR0FBYVAsSUFBSSxDQUFDUSxRQUFsQixDQUxnQyxDQU1oQzs7QUFDQUgsZ0JBQUFBLEdBQUcsQ0FBQ0ksUUFBSixHQUFlLElBQUlsQyxJQUFKLENBQVN5QixJQUFJLENBQUNYLE1BQUwsR0FBY2MsQ0FBQyxHQUFHSCxJQUFJLENBQUNULE9BQWhDLEVBQXlDUyxJQUFJLENBQUNWLE1BQUwsR0FBY2MsQ0FBQyxHQUFHSixJQUFJLENBQUNSLE9BQWhFLEVBQXlFLENBQXpFLENBQWYsQ0FQZ0MsQ0FRaEM7QUFDQTs7QUFDQWEsZ0JBQUFBLEdBQUcsQ0FBQ0ssSUFBSixHQUFXUCxDQUFDLEdBQUcsR0FBSixHQUFVQyxDQUFyQixDQVZnQyxDQVdoQzs7QUFDQUosZ0JBQUFBLElBQUksQ0FBQ0osS0FBTCxDQUFXZSxJQUFYLENBQWdCTixHQUFoQixFQVpnQyxDQWFoQztBQUVBOztBQUNBLG9CQUFJTyxRQUFtQixHQUFHO0FBQUE7QUFBQSwwQ0FBU1gsUUFBVCxHQUFvQlksS0FBcEIsQ0FBMEJWLENBQTFCLEVBQTZCQyxDQUE3QixDQUExQjs7QUFDQSxvQkFBSVEsUUFBUSxDQUFDeEIsSUFBVCxJQUFpQjtBQUFBO0FBQUEsZ0RBQVkwQixJQUFqQyxFQUF1QztBQUNuQ1Qsa0JBQUFBLEdBQUcsQ0FBQ1UsWUFBSixDQUFpQnpDLGNBQWpCLEVBQWlDMEMsUUFBakMsR0FBNENoQixJQUFJLENBQUNpQixHQUFqRCxDQURtQyxDQUVuQztBQUNIO0FBQ0osZUF0QitCLENBdUJoQzs7QUFDSDtBQUNKOzs7cUNBR2lCO0FBQ2R2QyxZQUFBQSxXQUFXLENBQUN3QyxFQUFaLENBQWV2QyxlQUFlLENBQUN3QyxXQUEvQixFQUE0QyxLQUFLaEMsU0FBakQsRUFBNEQsSUFBNUQsRUFEYyxDQUVkO0FBQ0g7OztzQ0FFa0I7QUFDZlQsWUFBQUEsV0FBVyxDQUFDMEMsR0FBWixDQUFnQnpDLGVBQWUsQ0FBQ3dDLFdBQWhDLEVBQTZDLEtBQUtoQyxTQUFsRCxFQUE2RCxJQUE3RCxFQURlLENBRWY7QUFDSDtBQUVEOzs7Ozs7b0NBR1VrQyxLLEVBQWNDLEssRUFBbUI7QUFBQTs7QUFFdkMsZ0JBQUl0QixJQUFJLEdBQUcsSUFBWCxDQUZ1QyxDQUl2QztBQUNBO0FBRUE7O0FBQ0EsZ0JBQUl1QixJQUF3QixHQUFHLElBQS9CLENBUnVDLENBUUY7QUFDckM7QUFDQTs7QUFFQXZCLFlBQUFBLElBQUksQ0FBQ3dCLFVBQUwsQ0FBZ0JDLGdCQUFoQixDQUFpQ0osS0FBSyxDQUFDSyxNQUFOLENBQWFDLENBQTlDLEVBQWlETixLQUFLLENBQUNLLE1BQU4sQ0FBYUUsQ0FBOUQsRUFBaUU1QixJQUFJLENBQUNELEdBQXRFLEVBWnVDLENBY3ZDOztBQUVBOzs7Ozs7Ozs7QUFTQTtBQUVBOztBQUNBLGdCQUFJbkIsYUFBYSxDQUFDaUQsUUFBZCxDQUF1QkMsT0FBdkIsQ0FBK0I5QixJQUFJLENBQUNELEdBQXBDLENBQUosRUFBOEM7QUFDMUNDLGNBQUFBLElBQUksQ0FBQytCLGFBQUw7QUFFQVIsY0FBQUEsSUFBSSxHQUFHM0MsYUFBYSxDQUFDaUQsUUFBZCxDQUF1QkcsY0FBOUI7QUFDQUMsY0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksaUJBQWlCWCxJQUFJLENBQUMsQ0FBRCxDQUFKLENBQVFZLFFBQVIsQ0FBaUJ6QixJQUFqQixDQUFzQjBCLFFBQXRCLEVBQTdCLEVBSjBDLENBTTFDO0FBQ0E7O0FBQ0Esa0JBQUlwQyxJQUFJLENBQUNGLEdBQUwsSUFBWSxJQUFoQixFQUFzQjtBQUNsQixxQkFBSyxJQUFJSyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHSCxJQUFJLENBQUNGLEdBQUwsQ0FBU3VDLE1BQTdCLEVBQXFDLEVBQUVsQyxDQUF2QyxFQUEwQztBQUN0Q0gsa0JBQUFBLElBQUksQ0FBQ0osS0FBTCxDQUFXTyxDQUFYLEVBQWNZLFlBQWQsQ0FBMkJ6QyxjQUEzQixFQUEyQzBDLFFBQTNDLEdBQXNEaEIsSUFBSSxDQUFDc0MsTUFBM0Q7QUFDQUwsa0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGlDQUFaO0FBQ0g7QUFDSixlQWJ5QyxDQWUxQztBQUNBO0FBQ0E7QUFDQTs7O0FBQ0Esa0JBQUlsQyxJQUFJLENBQUNMLFFBQUwsQ0FBY2dDLENBQWQsSUFBbUIsQ0FBQyxDQUFwQixJQUF5QjNCLElBQUksQ0FBQ0wsUUFBTCxDQUFjaUMsQ0FBZCxJQUFtQixDQUFoRCxFQUFtRDtBQUMvQ0ssZ0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGlCQUFaO0FBQ0Esb0JBQUlLLElBQUksR0FBR2hCLElBQUksQ0FBQyxDQUFELENBQUosQ0FBUVksUUFBUixDQUFpQkssSUFBakIsQ0FBc0I5QixJQUF0QixDQUEyQitCLEtBQTNCLENBQWlDLEdBQWpDLENBQVgsQ0FGK0MsQ0FHL0M7O0FBQ0F6QyxnQkFBQUEsSUFBSSxDQUFDTCxRQUFMLEdBQWdCLElBQUl0QixJQUFKLENBQVNxRSxNQUFNLENBQUNILElBQUksQ0FBQyxDQUFELENBQUosQ0FBUUgsUUFBUixFQUFELENBQWYsRUFDVk0sTUFBTSxDQUFDSCxJQUFJLENBQUMsQ0FBRCxDQUFKLENBQVFILFFBQVIsRUFBRCxDQURJLENBQWhCLENBSitDLENBTS9DO0FBQ0E7O0FBQ0FiLGdCQUFBQSxJQUFJLENBQUMsQ0FBRCxDQUFKLENBQVFZLFFBQVIsQ0FBaUJLLElBQWpCLENBQXNCekIsWUFBdEIsQ0FBbUN6QyxjQUFuQyxFQUFtRDBDLFFBQW5ELEdBQThEaEIsSUFBSSxDQUFDMkMsTUFBbkU7QUFDSCxlQVRELENBVUE7QUFWQSxtQkFXSztBQUNEVixrQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksZUFBWixFQURDLENBRUQ7O0FBQ0Esc0JBQUlLLEtBQWMsR0FBR2hCLElBQUksQ0FBQyxDQUFELENBQUosQ0FBUVksUUFBUixDQUFpQkssSUFBakIsQ0FBc0I5QixJQUF0QixDQUEyQitCLEtBQTNCLENBQWlDLEdBQWpDLENBQXJCOztBQUNBLHNCQUFJRyxNQUFZLEdBQUcsSUFBSXZFLElBQUosQ0FBU3FFLE1BQU0sQ0FBQ0gsS0FBSSxDQUFDLENBQUQsQ0FBTCxDQUFmLEVBQTBCRyxNQUFNLENBQUNILEtBQUksQ0FBQyxDQUFELENBQUwsQ0FBaEMsQ0FBbkI7QUFDQU4sa0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGVBQWVYLElBQUksQ0FBQyxDQUFELENBQUosQ0FBUVksUUFBUixDQUFpQkssSUFBakIsQ0FBc0I5QixJQUFqRCxFQUxDLENBT0Q7O0FBQ0FWLGtCQUFBQSxJQUFJLENBQUNGLEdBQUwsR0FBVztBQUFBO0FBQUEsNENBQVNHLFFBQVQsR0FBb0I0QyxRQUFwQixDQUE2QjdDLElBQUksQ0FBQ0wsUUFBbEMsRUFBNENpRCxNQUE1QyxDQUFYLENBUkMsQ0FVRDtBQUNBOztBQUNBLHNCQUFJRSxFQUFVLEdBQUcsQ0FBQzlDLElBQUksQ0FBQ0wsUUFBTCxDQUFjZ0MsQ0FBZCxHQUFrQixHQUFsQixHQUF3QjNCLElBQUksQ0FBQ0wsUUFBTCxDQUFjaUMsQ0FBdkMsRUFBMENRLFFBQTFDLEVBQWpCO0FBQ0FwQyxrQkFBQUEsSUFBSSxDQUFDSixLQUFMLENBQVdtRCxPQUFYLENBQW1CLFVBQUFDLE9BQU8sRUFBSTtBQUMxQix3QkFBSUEsT0FBTyxDQUFDdEMsSUFBUixJQUFnQm9DLEVBQXBCLEVBQXdCO0FBQ3BCO0FBQ0FFLHNCQUFBQSxPQUFPLENBQUNqQyxZQUFSLENBQXFCekMsY0FBckIsRUFBcUMwQyxRQUFyQyxHQUFnRCxNQUFJLENBQUNzQixNQUFyRDtBQUNBTCxzQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksNkJBQTZCYyxPQUFPLENBQUN0QyxJQUFqRDtBQUNIO0FBQ0osbUJBTkQsRUFiQyxDQXFCRDs7QUFDQSxzQkFBSVYsSUFBSSxDQUFDRixHQUFMLElBQVksSUFBaEIsRUFBc0I7QUFBQSwrQ0FDVE0sQ0FEUztBQUVkLDBCQUFJNkMsSUFBWSxHQUFHLENBQUNqRCxJQUFJLENBQUNGLEdBQUwsQ0FBU00sQ0FBVCxFQUFZdUIsQ0FBWixHQUFnQixHQUFoQixHQUFzQjNCLElBQUksQ0FBQ0YsR0FBTCxDQUFTTSxDQUFULEVBQVl3QixDQUFuQyxFQUFzQ1EsUUFBdEMsRUFBbkI7QUFDQXBDLHNCQUFBQSxJQUFJLENBQUNKLEtBQUwsQ0FBV21ELE9BQVgsQ0FBbUIsVUFBQUMsT0FBTyxFQUFJO0FBQzFCLDRCQUFHQSxPQUFPLENBQUN0QyxJQUFSLElBQWN1QyxJQUFqQixFQUFzQjtBQUNsQkQsMEJBQUFBLE9BQU8sQ0FBQ2pDLFlBQVIsQ0FBcUJ6QyxjQUFyQixFQUFxQzBDLFFBQXJDLEdBQThDaEIsSUFBSSxDQUFDa0QsSUFBbkQsQ0FEa0IsQ0FFbEI7QUFDSDtBQUNKLHVCQUxELEVBSGMsQ0FTZjtBQUNBO0FBVmU7O0FBQ2xCLHlCQUFLLElBQUk5QyxDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHSixJQUFJLENBQUNGLEdBQUwsQ0FBU3VDLE1BQTdCLEVBQXFDLEVBQUVqQyxDQUF2QyxFQUEwQztBQUFBLDRCQUFqQ0EsQ0FBaUM7QUFVekM7QUFDSixtQkFsQ0EsQ0FvQ0Q7OztBQUNBSixrQkFBQUEsSUFBSSxDQUFDTCxRQUFMLEdBQWdCLElBQUl0QixJQUFKLENBQVMsQ0FBQyxDQUFWLEVBQWEsQ0FBYixDQUFoQjtBQUNIO0FBQ0o7QUFDSjtBQUdEOzs7Ozs7MENBRzJCO0FBQ3ZCLGdCQUFJMkIsSUFBSSxHQUFDLElBQVQ7O0FBRUEsZ0JBQUlBLElBQUksQ0FBQ0YsR0FBTCxJQUFZLElBQWhCLEVBQXNCO0FBQUEsMkNBQ1RNLENBRFM7QUFFZCxvQkFBSTZDLElBQVksR0FBRyxDQUFDakQsSUFBSSxDQUFDRixHQUFMLENBQVNNLENBQVQsRUFBWXVCLENBQVosR0FBZ0IsR0FBaEIsR0FBc0IzQixJQUFJLENBQUNGLEdBQUwsQ0FBU00sQ0FBVCxFQUFZd0IsQ0FBbkMsRUFBc0NRLFFBQXRDLEVBQW5CO0FBQ0FwQyxnQkFBQUEsSUFBSSxDQUFDSixLQUFMLENBQVdtRCxPQUFYLENBQW1CLFVBQUFDLE9BQU8sRUFBSTtBQUMxQixzQkFBR0EsT0FBTyxDQUFDdEMsSUFBUixJQUFjdUMsSUFBakIsRUFBc0I7QUFDbEJELG9CQUFBQSxPQUFPLENBQUNqQyxZQUFSLENBQXFCekMsY0FBckIsRUFBcUMwQyxRQUFyQyxHQUE4Q2hCLElBQUksQ0FBQ3NDLE1BQW5ELENBRGtCLENBRWxCO0FBQ0g7QUFDSixpQkFMRDtBQUhjOztBQUNsQixtQkFBSyxJQUFJbEMsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR0osSUFBSSxDQUFDRixHQUFMLENBQVN1QyxNQUE3QixFQUFxQyxFQUFFakMsQ0FBdkMsRUFBMEM7QUFBQSx1QkFBakNBLENBQWlDO0FBUXpDO0FBQ0o7QUFDSjs7OztRQXhQMEJsQyxTOzs7OztpQkFpQ0osSTs7Ozs7OztpQkFHRyxJOzs7Ozs7O2lCQUdGLEk7Ozs7Ozs7aUJBR0UsSTs7Ozs7OztpQkFHQyxJOzs7Ozs7O2lCQXNCb0IsSTs7Ozs7OztpQkFXdkIsSSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IF9kZWNvcmF0b3IsIENvbXBvbmVudCwgTm9kZSwgTWF0ZXJpYWwsIFZlYzIsIE1vZGVsQ29tcG9uZW50LCBWZWMzLCBnZW9tZXRyeSwgQ2FtZXJhQ29tcG9uZW50LCBzeXN0ZW1FdmVudCwgU3lzdGVtRXZlbnRUeXBlLCBFdmVudFRvdWNoLCBQaHlzaWNzU3lzdGVtLCBQaHlzaWNzUmF5UmVzdWx0LCBQcmVmYWIsIGluc3RhbnRpYXRlLCBJbnN0YW5jZU1hdGVyaWFsVHlwZSwgZGlyZWN0b3IsIHNsaWNlZCB9IGZyb20gJ2NjJztcclxuaW1wb3J0IHsgQVN0YXJOb2RlLCBFX05vZGVfVHlwZSB9IGZyb20gJy4vQVN0YXJOb2RlJztcclxuaW1wb3J0IHsgQVN0YXJNZ3IgfSBmcm9tICcuL0FTdGFyTWdyJztcclxuY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gX2RlY29yYXRvcjtcclxuXHJcblxyXG5cclxuQGNjY2xhc3MoJ1Rlc3RBU3RhcicpXHJcbmV4cG9ydCBjbGFzcyBUZXN0QVN0YXIgZXh0ZW5kcyBDb21wb25lbnQge1xyXG5cclxuICAgIC8qKlxyXG4gICAgICog5bem5LiK6KeS56ys5LiA5Liq56uL5pa55L2T55qEWOWdkOagh1xyXG4gICAgICovXHJcbiAgICBwdWJsaWMgYmVnaW5YID0gLTM7XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiDlt6bkuIrop5LnrKzkuIDkuKrnq4vmlrnkvZPnmoRZ5Z2Q5qCHXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBiZWdpblkgPSA1O1xyXG5cclxuICAgIC8qKlxyXG4gICAgICog5LmL5ZCO5q+P5Liq56uL5pa55L2T5LmL6Ze055qEIOWBj+enu1jlnZDmoIdcclxuICAgICAqL1xyXG4gICAgcHVibGljIG9mZnNldFggPSAyO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICog5LmL5ZCO5q+P5Liq56uL5pa55L2T5LmL6Ze055qE5YGP56e7WeWdkOagh1xyXG4gICAgICovXHJcbiAgICBwdWJsaWMgb2Zmc2V0WSA9IC0yO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICog5Zyw5Zu+5qC85a2Q55qE5a69XHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBtYXBXID0gNDtcclxuXHJcbiAgICAvKipcclxuICAgICAqIOWcsOWbvuagvOWtkOeahOmrmFxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgbWFwSCA9IDQ7XHJcblxyXG4gICAgQHByb3BlcnR5KHsgdHlwZTogTWF0ZXJpYWwgfSlcclxuICAgIHB1YmxpYyByZWQ6IE1hdGVyaWFsID0gbnVsbDtcclxuXHJcbiAgICBAcHJvcGVydHkoeyB0eXBlOiBNYXRlcmlhbCB9KVxyXG4gICAgcHVibGljIHllbGxvdzogTWF0ZXJpYWwgPSBudWxsO1xyXG5cclxuICAgIEBwcm9wZXJ0eSh7IHR5cGU6IE1hdGVyaWFsIH0pXHJcbiAgICBwdWJsaWMgYmx1ZTogTWF0ZXJpYWwgPSBudWxsO1xyXG5cclxuICAgIEBwcm9wZXJ0eSh7IHR5cGU6IE1hdGVyaWFsIH0pXHJcbiAgICBwdWJsaWMgbm9ybWFsOiBNYXRlcmlhbCA9IG51bGw7XHJcblxyXG4gICAgQHByb3BlcnR5KHsgdHlwZTogUHJlZmFiIH0pXHJcbiAgICBwdWJsaWMgaW5zdGFuT2JqOiBQcmVmYWIgPSBudWxsO1xyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIOW8gOWni+eCuSDnu5nlroPkuIDkuKog5Li66LSf55qE5Z2Q5qCHXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgYmVnaW5Qb3M6IFZlYzIgPSBuZXcgVmVjMigtMSwgMCk7XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiDliJvlu7rnmoRjdWJlc+WIl+ihqFxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIGN1YmVzOiBBcnJheTxOb2RlPiA9IG5ldyBBcnJheTxOb2RlPigpO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICogQVN0YXIg6IqC54K55YiX6KGoXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgbHN0OiBBcnJheTxBU3Rhck5vZGU+ID0gbmV3IEFycmF5PEFTdGFyTm9kZT4oKTtcclxuXHJcbiAgICAvKipcclxuICAgICAqIOaRhOWDj+acuuWunuS+i1xyXG4gICAgICovXHJcbiAgICBAcHJvcGVydHkoeyB0eXBlOiBDYW1lcmFDb21wb25lbnQgfSlcclxuICAgIHByaXZhdGUgcmVhZG9ubHkgbWFpbkNhbWVyYTogQ2FtZXJhQ29tcG9uZW50ID0gbnVsbDtcclxuXHJcbiAgICAvKipcclxuICAgICAqIOWwhOe6v+WunuS+i1xyXG4gICAgICovXHJcbiAgICBwcml2YXRlIHJheTogZ2VvbWV0cnkucmF5ID0gbmV3IGdlb21ldHJ5LnJheSgpO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICog5qC85a2Q55Sf5oiQ54K5XHJcbiAgICAgKi9cclxuICAgIEBwcm9wZXJ0eSh7IHR5cGU6IE5vZGUgfSlcclxuICAgIHB1YmxpYyBzcGF3blBvczogTm9kZSA9IG51bGw7XHJcblxyXG4gICAgcHVibGljIG9uTG9hZCgpIHtcclxuICAgICAgICBsZXQgc2VsZiA9IHRoaXM7XHJcblxyXG4gICAgICAgIC8v5Yid5aeL5YyWQVN0YXJNZ3JcclxuICAgICAgICAvL2xldCBhU3Rhck1ncjpBU3Rhck1ncj1zZWxmLm5vZGUuZ2V0Q29tcG9uZW50KCdBU3Rhck1ncicpIGFzIEFTdGFyTWdyO1xyXG4gICAgICAgIC8vYVN0YXJNZ3IuSW5pdCgpO1xyXG5cclxuICAgICAgICBBU3Rhck1nci5JbnN0YW5jZSgpLkluaXRNYXBJbmZvKHNlbGYubWFwVywgc2VsZi5tYXBIKTtcclxuXHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzZWxmLm1hcFc7ICsraSkge1xyXG4gICAgICAgICAgICBmb3IgKGxldCBqID0gMDsgaiA8IHNlbGYubWFwSDsgKytqKSB7XHJcbiAgICAgICAgICAgICAgICAvL+WIm+W7uuS4gOS4quS4queri+aWueS9k1xyXG4gICAgICAgICAgICAgICAgLy9sZXQgb2JqID10aGlzLm5vZGUuQ3JlYXRlUHJpbWl0aXZlKFByaW1pdGl2ZVR5cGUuQk9YKTtcclxuICAgICAgICAgICAgICAgIGxldCBvYmogPSBpbnN0YW50aWF0ZShzZWxmLmluc3Rhbk9iaikgYXMgTm9kZTtcclxuICAgICAgICAgICAgICAgIC8v6K6+572u54i25a+56LGhXHJcbiAgICAgICAgICAgICAgICBvYmoucGFyZW50ID0gc2VsZi5zcGF3blBvcztcclxuICAgICAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJvYmoudHlwZSBpczpcIitvYmopO1xyXG4gICAgICAgICAgICAgICAgb2JqLnBvc2l0aW9uID0gbmV3IFZlYzMoc2VsZi5iZWdpblggKyBpICogc2VsZi5vZmZzZXRYLCBzZWxmLmJlZ2luWSArIGogKiBzZWxmLm9mZnNldFksIDApO1xyXG4gICAgICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhcIm9iai5ub2RlLnBvc2l0aW9uIGlzOlwiK29iai5wb3NpdGlvbik7XHJcbiAgICAgICAgICAgICAgICAvL+WQjeWtl1xyXG4gICAgICAgICAgICAgICAgb2JqLm5hbWUgPSBpICsgXCJfXCIgKyBqO1xyXG4gICAgICAgICAgICAgICAgLy/lrZjlgqjnq4vmlrnkvZPliLDlrZflhbjlrrnlmajkuK1cclxuICAgICAgICAgICAgICAgIHNlbGYuY3ViZXMucHVzaChvYmopO1xyXG4gICAgICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhcInNlbGYuY3ViZXMubGVuZ3RoIGlzOlwiK3NlbGYuY3ViZXMubGVuZ3RoKTtcclxuXHJcbiAgICAgICAgICAgICAgICAvL+W+l+WIsOagvOWtkCDliKTmlq3lroPmmK/kuI3mmK/pmLvmjKFcclxuICAgICAgICAgICAgICAgIGxldCB0ZW1wTm9kZTogQVN0YXJOb2RlID0gQVN0YXJNZ3IuSW5zdGFuY2UoKS5ub2Rlc1tpXVtqXTtcclxuICAgICAgICAgICAgICAgIGlmICh0ZW1wTm9kZS50eXBlID09IEVfTm9kZV9UeXBlLlN0b3ApIHtcclxuICAgICAgICAgICAgICAgICAgICBvYmouZ2V0Q29tcG9uZW50KE1vZGVsQ29tcG9uZW50KS5tYXRlcmlhbCA9IHNlbGYucmVkO1xyXG4gICAgICAgICAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJzZXQgb2JqJ21hdGVyaWFsOlwiK29iai5nZXRDb21wb25lbnQoTW9kZWxDb21wb25lbnQpLm1hdGVyaWFsLnRvU3RyaW5nKCkpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKFwiY29udGludXRlIGZvci10aW1lIGlzOlwiK2kpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcblxyXG4gICAgcHVibGljIG9uRW5hYmxlKCkge1xyXG4gICAgICAgIHN5c3RlbUV2ZW50Lm9uKFN5c3RlbUV2ZW50VHlwZS5UT1VDSF9TVEFSVCwgdGhpcy5UZXN0QVN0YXIsIHRoaXMpO1xyXG4gICAgICAgIC8vc3lzdGVtRXZlbnQub24oU3lzdGVtRXZlbnRUeXBlLktFWV9ET1dOLCB0aGlzLlRlc3QsIHRoaXMpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBvbkRpc2FibGUoKSB7XHJcbiAgICAgICAgc3lzdGVtRXZlbnQub2ZmKFN5c3RlbUV2ZW50VHlwZS5UT1VDSF9TVEFSVCwgdGhpcy5UZXN0QVN0YXIsIHRoaXMpO1xyXG4gICAgICAgIC8vIHN5c3RlbUV2ZW50Lm9mZihTeXN0ZW1FdmVudFR5cGUuS0VZX1VQLCB0aGlzLlRlc3QsIHRoaXMpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICog5rWL6K+VQVN0YXJcclxuICAgICAqL1xyXG4gICAgVGVzdEFTdGFyKHRvdWNoOiBUb3VjaCwgZXZlbnQ6IEV2ZW50VG91Y2gpIHtcclxuXHJcbiAgICAgICAgbGV0IHNlbGYgPSB0aGlzO1xyXG5cclxuICAgICAgICAvL2NvbnNvbGUubG9nKFwiVmVjdC5VTklUX1ggaXM6XCIrVmVjMi5VTklUX1gpO1xyXG4gICAgICAgIC8v5aaC5p6c6byg5qCH5bem6ZSu5oyJ5LiLXHJcblxyXG4gICAgICAgIC8v6L+b6KGM5bCE57q/5qOA5rWLXHJcbiAgICAgICAgbGV0IGluZm86IFBoeXNpY3NSYXlSZXN1bHRbXSA9IG51bGw7IC8v5bCE57q/5qOA5rWL5a6M55qE5L+h5oGvXHJcbiAgICAgICAgLy/lvpfliLDlsY/luZXpvKDmoIfkvY3nva7lj5Hlh7rljrvnmoTlsITnur9cclxuICAgICAgICAvL2NvbnNvbGUubG9nKFwiQ2xpY2sgc3VjY2Vzc2Z1bCFcIik7XHJcblxyXG4gICAgICAgIHNlbGYubWFpbkNhbWVyYS5zY3JlZW5Qb2ludFRvUmF5KHRvdWNoLl9wb2ludC54LCB0b3VjaC5fcG9pbnQueSwgc2VsZi5yYXkpO1xyXG5cclxuICAgICAgICAvLyNyZWdpb24gIOWfuuS6jueJqeeQhueisOaSnuWZqOeahOWwhOe6v+ajgOa1i1xyXG5cclxuICAgICAgICAvKiBpZiAoUGh5c2ljc1N5c3RlbS5pbnN0YW5jZS5yYXljYXN0KHNlbGYucmF5KSkge1xyXG4gICAgICAgICAgICAgY29uc3QgciA9IFBoeXNpY3NTeXN0ZW0uaW5zdGFuY2UucmF5Y2FzdFJlc3VsdHM7XHJcbiAgICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHIubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgICAgICBjb25zdCBpdGVtID0gcltpXTtcclxuICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkNsaWNrIG9iaiBpczpcIitpdGVtLmNvbGxpZGVyLm5hbWUpO1xyXG4gICAgICAgICAgICAgfVxyXG4gICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiV2hhdCBhcmUgeW91IHdhbnQgdG8gZG8hXCIpO1xyXG4gICAgICAgICB9Ki9cclxuICAgICAgICAvLyNlbmRyZWdpb25cclxuXHJcbiAgICAgICAgLy/lsITnur/mo4DmtYtcclxuICAgICAgICBpZiAoUGh5c2ljc1N5c3RlbS5pbnN0YW5jZS5yYXljYXN0KHNlbGYucmF5KSkge1xyXG4gICAgICAgICAgICBzZWxmLlJlU2V0TWF0ZXJpYWwoKTtcclxuXHJcbiAgICAgICAgICAgIGluZm8gPSBQaHlzaWNzU3lzdGVtLmluc3RhbmNlLnJheWNhc3RSZXN1bHRzO1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIlJheSBJbmZvIGlzOlwiICsgaW5mb1swXS5jb2xsaWRlci5uYW1lLnRvU3RyaW5nKCkpO1xyXG5cclxuICAgICAgICAgICAgLy/muIXnkIbkuIrkuIDmrKHnmoTot6/lvoTvvIzmiornu7/oibLnq4vmlrnkvZPlj5jmiJDnmb3oibJcclxuICAgICAgICAgICAgLy/lpoLmnpzkuI3kuLrnqbrvvIzor4HmmI7mib7miJDlip/kuoZcclxuICAgICAgICAgICAgaWYgKHNlbGYubHN0ICE9IG51bGwpIHtcclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc2VsZi5sc3QubGVuZ3RoOyArK2kpIHtcclxuICAgICAgICAgICAgICAgICAgICBzZWxmLmN1YmVzW2ldLmdldENvbXBvbmVudChNb2RlbENvbXBvbmVudCkubWF0ZXJpYWwgPSBzZWxmLm5vcm1hbDtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIlJlc2V0IHNlbGYuY3ViZXNbaV0ubWF0ZXJpYWwuLi5cIik7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJzZWxmLmJlZ2luUG9zIGlzOlwiK3NlbGYuYmVnaW5Qb3MpO1xyXG4gICAgICAgICAgICAvL2NvbnNvbGUubG9nKFwic2VsZi5iZWdpblBvcyBlcXVhbCBuZXcgVmVjMigtMS4wMCwwLjAwKSBpczpcIisoc2VsZi5iZWdpblBvcyA9PSBuZXcgVmVjMigtMS4wMCwgMC4wMCkpKTtcclxuICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhcInNlbGYuYmVnaW5Qb3MueCBlcXVhbCAtMSBhbmQgc2VsZi5iZWdpblBvcy55IGVxdWFsIDAgaXM6XCIrKHNlbGYuYmVnaW5Qb3MueD09LTEmJnNlbGYuYmVnaW5Qb3MueT09MCkpO1xyXG4gICAgICAgICAgICAvL+W+l+WIsOeCueWHu+WIsOeahOeri+aWueS9kyDmiY3og73nn6XpgZPmmK/nrKzlh6DooYznrKzlh6DliJdcclxuICAgICAgICAgICAgaWYgKHNlbGYuYmVnaW5Qb3MueCA9PSAtMSAmJiBzZWxmLmJlZ2luUG9zLnkgPT0gMCkge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJTZXQgYmVnaW5Qb3MuLi5cIik7XHJcbiAgICAgICAgICAgICAgICBsZXQgc3RycyA9IGluZm9bMF0uY29sbGlkZXIubm9kZS5uYW1lLnNwbGl0KCdfJyk7XHJcbiAgICAgICAgICAgICAgICAvL+W+l+WIsOihjOWIl+S9jee9riDlsLHmmK/lvIDlp4vngrnkvY3nva5cclxuICAgICAgICAgICAgICAgIHNlbGYuYmVnaW5Qb3MgPSBuZXcgVmVjMihOdW1iZXIoc3Ryc1swXS50b1N0cmluZygpKVxyXG4gICAgICAgICAgICAgICAgICAgICwgTnVtYmVyKHN0cnNbMV0udG9TdHJpbmcoKSkpO1xyXG4gICAgICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhcInNldCBzZWxmLmJlZ2luUG9zIGlzOlwiICsgc2VsZi5iZWdpblBvcy50b1N0cmluZygpKTtcclxuICAgICAgICAgICAgICAgIC8v5oqK54K55Ye75Yiw55qE5a+56LGh5Y+Y5oiQ6buE6ImyXHJcbiAgICAgICAgICAgICAgICBpbmZvWzBdLmNvbGxpZGVyLm5vZGUuZ2V0Q29tcG9uZW50KE1vZGVsQ29tcG9uZW50KS5tYXRlcmlhbCA9IHNlbGYueWVsbG93O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8v5pyJ6LW354K55LqGIOmCo+i/meWwseaYryDmnaXngrnlh7rnu4jngrkg6L+b6KGM5a+76LevXHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJTZXQgZW5kUG9zLi4uXCIpO1xyXG4gICAgICAgICAgICAgICAgLy/lvpfliLDnu4jngrlcclxuICAgICAgICAgICAgICAgIGxldCBzdHJzOiBzdHJpbmdbXSA9IGluZm9bMF0uY29sbGlkZXIubm9kZS5uYW1lLnNwbGl0KCdfJyk7XHJcbiAgICAgICAgICAgICAgICBsZXQgZW5kUG9zOiBWZWMyID0gbmV3IFZlYzIoTnVtYmVyKHN0cnNbMF0pLCBOdW1iZXIoc3Ryc1sxXSkpO1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJlbmRQb3MgaXM6XCIgKyBpbmZvWzBdLmNvbGxpZGVyLm5vZGUubmFtZSk7XHJcblxyXG4gICAgICAgICAgICAgICAgLy/lr7vot69cclxuICAgICAgICAgICAgICAgIHNlbGYubHN0ID0gQVN0YXJNZ3IuSW5zdGFuY2UoKS5GaW5kUGF0aChzZWxmLmJlZ2luUG9zLCBlbmRQb3MpO1xyXG5cclxuICAgICAgICAgICAgICAgIC8v6YG/5YWN5q276Lev55qE5pe25YCZ6buE6Imy5LiN5Y+Y5oiQ55m96Imy77yM5omA5Lul5LqL5YWI5riF5LiA6YGN44CC5Zug5Li6YmVnaW5Qb3MueOaYr2Zsb2F057G75Z6L55qE5omA5Lul6KaB6L2s5o2i5Li6aW5057G75Z6LXHJcbiAgICAgICAgICAgICAgICAvL3NlbGYuY3ViZXNbc2VsZi5iZWdpblBvcy54XVsuYmVnaW5Qb3MueV0uZ2V0Q29tcG9uZW50KE1vZGVsQ29tcG9uZW50KS5tYXRlcmlhbCA9IHRoaXMubm9ybWFsO1xyXG4gICAgICAgICAgICAgICAgbGV0IHN0OiBzdHJpbmcgPSAoc2VsZi5iZWdpblBvcy54ICsgXCJfXCIgKyBzZWxmLmJlZ2luUG9zLnkpLnRvU3RyaW5nKCk7XHJcbiAgICAgICAgICAgICAgICBzZWxmLmN1YmVzLmZvckVhY2goZWxlbWVudCA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKGVsZW1lbnQubmFtZSA9PSBzdCkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAvL+mBv+WFjeatu+i3r+eahOaXtuWAmem7hOiJsuS4jeWPmOaIkOeZveiJsu+8jOaJgOS7peS6i+WFiOa4heS4gOmBjeOAguWboOS4umJlZ2luUG9zLnjmmK9mbG9hdOexu+Wei+eahOaJgOS7peimgei9rOaNouS4umludOexu+Wei1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50LmdldENvbXBvbmVudChNb2RlbENvbXBvbmVudCkubWF0ZXJpYWwgPSB0aGlzLm5vcm1hbDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJzZWxmLmN1YmVzW2JlZ2luUG9zXSBpczpcIiArIGVsZW1lbnQubmFtZSlcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgICAgICAvL+WmguaenOS4jeS4uuepuu+8jOivgeaYjuaJvuaIkOWKn+S6hlxyXG4gICAgICAgICAgICAgICAgaWYgKHNlbGYubHN0ICE9IG51bGwpIHtcclxuICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBqID0gMDsgaiA8IHNlbGYubHN0Lmxlbmd0aDsgKytqKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxldCB0ZW1wOiBzdHJpbmcgPSAoc2VsZi5sc3Rbal0ueCArIFwiX1wiICsgc2VsZi5sc3Rbal0ueSkudG9TdHJpbmcoKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZi5jdWJlcy5mb3JFYWNoKGVsZW1lbnQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYoZWxlbWVudC5uYW1lPT10ZW1wKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50LmdldENvbXBvbmVudChNb2RlbENvbXBvbmVudCkubWF0ZXJpYWw9c2VsZi5ibHVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCLmiZPljbDlj5joibLnmoTpobrluo/vvJpcIitlbGVtZW50Lm5hbWUpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAvLyBzZWxmLmN1YmVzW2pdLmdldENvbXBvbmVudChNb2RlbENvbXBvbmVudCkubWF0ZXJpYWwgPSB0aGlzLmJsdWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgLy8vIGNvbnNvbGUubG9nKFwi5omT5Y2w6Lev5b6E6aG65bqP77yaXCIgKyBzZWxmLmxzdFtqXS54ICsgXCJfXCIgKyBzZWxmLmxzdFtqXS55KTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgLy/muIXpmaTlvIDlp4vngrkg5oqK5a6D5Y+Y5oiQ5Yid5aeL5YC8XHJcbiAgICAgICAgICAgICAgICBzZWxmLmJlZ2luUG9zID0gbmV3IFZlYzIoLTEsIDApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIOmHjee9ruWPmOaIkOiTneiJsueahOWvueixoeS4uk5vcm1hbFxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgUmVTZXRNYXRlcmlhbCgpOnZvaWR7XHJcbiAgICAgICAgbGV0IHNlbGY9dGhpcztcclxuXHJcbiAgICAgICAgaWYgKHNlbGYubHN0ICE9IG51bGwpIHtcclxuICAgICAgICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCBzZWxmLmxzdC5sZW5ndGg7ICsraikge1xyXG4gICAgICAgICAgICAgICAgbGV0IHRlbXA6IHN0cmluZyA9IChzZWxmLmxzdFtqXS54ICsgXCJfXCIgKyBzZWxmLmxzdFtqXS55KS50b1N0cmluZygpO1xyXG4gICAgICAgICAgICAgICAgc2VsZi5jdWJlcy5mb3JFYWNoKGVsZW1lbnQgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGlmKGVsZW1lbnQubmFtZT09dGVtcCl7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsZW1lbnQuZ2V0Q29tcG9uZW50KE1vZGVsQ29tcG9uZW50KS5tYXRlcmlhbD1zZWxmLm5vcm1hbDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9jb25zb2xlLmxvZyhcIumHjee9ruWPmOiJsueahOmhuuW6j++8mlwiK2VsZW1lbnQubmFtZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7ICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxufVxyXG4iXX0=