System.register(["cc", "code-quality:cr", "./AStarNode.js"], function (_export, _context) {
  "use strict";

  var _cclegacy, _reporterNs, _decorator, Component, Vec2, Color, GraphicsComponent, AStarNode, E_Node_Type, _dec, _dec2, _class, _class2, _descriptor, _class3, _temp, _crd, ccclass, property, AStarMgr;

  function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

  function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

  function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

  function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfAStarNode(extras) {
    _reporterNs.report("AStarNode", "./AStarNode", _context.meta, extras);
  }

  function _reportPossibleCrUseOfE_Node_Type(extras) {
    _reporterNs.report("E_Node_Type", "./AStarNode", _context.meta, extras);
  }

  _export({
    _dec: void 0,
    _dec2: void 0,
    _class: void 0,
    _class2: void 0,
    _descriptor: void 0,
    _class3: void 0,
    _temp: void 0
  });

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Vec2 = _cc.Vec2;
      Color = _cc.Color;
      GraphicsComponent = _cc.GraphicsComponent;
    }, function (_codeQualityCr) {
      _reporterNs = _codeQualityCr;
    }, function (_AStarNodeJs) {
      AStarNode = _AStarNodeJs.AStarNode;
      E_Node_Type = _AStarNodeJs.E_Node_Type;
    }],
    execute: function () {
      _cclegacy._RF.push({}, "7823cv6QmlMkb4FfyafPntl", "AStarMgr", _context.meta);

      _crd = true;
      ccclass = _decorator.ccclass;
      property = _decorator.property; /// <summary>
      /// AStar寻路算法的基本原理就是不停的找自己周围的点，选出一个新的点作为起点再循环的找
      /// 1.寻路消耗公式：
      ///           f(寻路消耗)=g(离起点的距离)+h(离终点的距离)
      /// 2.开启列表：
      /// 每次从新的点找周围的点时，如果周围的点已经在开启列表或者关闭列表中了，我们就不去管它了
      /// 3.关闭列表：
      /// 每次往关闭列表中放点时，我们都应该判断这个点是不是和终点一样，如果是一样证明路径找完了，如果不一样，继续找。
      /// 4.格子对象的父对象   
      /// </summary>

      _export("AStarMgr", AStarMgr = (_dec = ccclass('AStartMgr'), _dec2 = property({
        type: GraphicsComponent
      }), _dec(_class = (_class2 = (_temp = _class3 = /*#__PURE__*/function (_Component) {
        _inherits(AStarMgr, _Component);

        _createClass(AStarMgr, null, [{
          key: "Instance",
          value: function Instance() {
            return this.instance;
          }
          /**
           * 地图的宽
           */

        }]);

        function AStarMgr() {
          var _this;

          _classCallCheck(this, AStarMgr);

          _this = _possibleConstructorReturn(this, _getPrototypeOf(AStarMgr).call(this));
          _this.nodes = new Array();
          _this.openLst = new Array();
          _this.closeLst = new Array();
          _this.path = new Array();

          _initializerDefineProperty(_this, "map", _descriptor, _assertThisInitialized(_this));

          AStarMgr.instance = _assertThisInitialized(_this);
          return _this;
        }

        _createClass(AStarMgr, [{
          key: "Init",
          value: function Init() {
            //AStarMgr.instance=this;
            console.log("AStarMgr Init...");
          }
          /**
           * 初始化地图
           * @param w 地图的宽
           * @param h 地图的高
           */

        }, {
          key: "InitMapInfo",
          value: function InitMapInfo(w, h) {
            //根据宽高 创建格子 阻挡的问题 我们可以随机阻挡
            //因为我们现在没有地图相关的数据
            var self = this; //记录宽高

            self.mapW = w;
            self.mapH = h; //声明容器可以装多少个格子
            //self.nodes= new AStarNode[w][h];
            //生成格子

            for (var i = 0; i < w; ++i) {
              //console.log("self.nodes.length:" + self.nodes.length);
              self.nodes[i] = [];

              for (var j = 0; j < h; ++j) {
                //用三目运算符随机生成阻挡格子
                //应该从地图配置表读取生成的
                var nodeObj = new (_crd && AStarNode === void 0 ? (_reportPossibleCrUseOfAStarNode({
                  error: Error()
                }), AStarNode) : AStarNode)(i, j, self.RandomNum(0, 100) < 20 ? (_crd && E_Node_Type === void 0 ? (_reportPossibleCrUseOfE_Node_Type({
                  error: Error()
                }), E_Node_Type) : E_Node_Type).Stop : (_crd && E_Node_Type === void 0 ? (_reportPossibleCrUseOfE_Node_Type({
                  error: Error()
                }), E_Node_Type) : E_Node_Type).Walk);
                self.nodes[i][j] = nodeObj;
              }
            }
          }
          /**
           * 寻路方法
           * @param startPos 开始点
           * @param endPos 结束点
           */

        }, {
          key: "FindPath",
          value: function FindPath(startPos, endPos) {
            var self = this; //实际项目中 传入的点往往是 坐标系中的点
            //我们这里省略换算的步骤 直接认为它是传进来的格子坐标
            //首先判断 传入的两个点 是否合法
            //1.首先 要在地图范围内
            //如果不合法 应该直接 返回null 意味着不能寻路

            if (startPos.x < 0 || startPos.x >= this.mapW || startPos.y < 0 || startPos.y >= this.mapH || endPos.x < 0 || endPos.x >= this.mapW || endPos.y < 0 || endPos.y >= this.mapH) {
              console.log("Start or end points are outside the map grid");
              return null;
            } //2.要不是阻挡
            //得到起点和终点  对应的格子


            var start = self.nodes[startPos.x][startPos.y];
            var end = self.nodes[endPos.x][endPos.y];

            if (start.type == (_crd && E_Node_Type === void 0 ? (_reportPossibleCrUseOfE_Node_Type({
              error: Error()
            }), E_Node_Type) : E_Node_Type).Stop || end.type == (_crd && E_Node_Type === void 0 ? (_reportPossibleCrUseOfE_Node_Type({
              error: Error()
            }), E_Node_Type) : E_Node_Type).Stop) {
              console.log("The start or end point is the block");
              return null;
            } //清空上一次相关的数据 避免他们影响  这一次的寻路计算
            //清空关闭和开启列表


            self.closeLst = [];
            self.openLst = []; //把开始点放入关闭列表中

            start.father = null;
            start.f = 0;
            start.g = 0;
            start.h = 0;
            self.closeLst.push(start);

            while (true) {
              //从起点开始 找周围的点 并放入开启列表中
              //左上  x-1 y-1
              self.FindNearlyNodeToOpenLst(start.x - 1, start.y - 1, 1.4, start, end); //上 x  y-1

              self.FindNearlyNodeToOpenLst(start.x, start.y - 1, 1, start, end); //右上  x+1 y-1

              self.FindNearlyNodeToOpenLst(start.x + 1, start.y - 1, 1.4, start, end); //左 x-1 y

              self.FindNearlyNodeToOpenLst(start.x - 1, start.y, 1, start, end); //右 x+1 y

              self.FindNearlyNodeToOpenLst(start.x + 1, start.y, 1, start, end); //左下 x-1 y+1

              self.FindNearlyNodeToOpenLst(start.x - 1, start.y + 1, 1.4, start, end); //下 x y+1

              self.FindNearlyNodeToOpenLst(start.x, start.y + 1, 1, start, end); //右下 x+1 y+1

              self.FindNearlyNodeToOpenLst(start.x + 1, start.y + 1, 1.4, start, end); //死路判断  开启列表为空 都还没有找到终点 就认为是死路

              if (self.openLst.length == 0) {
                console.log("Blind alley...");
                return null;
              } //选出开启列表中 寻路消耗最小的点


              self.openLst.sort(self.SortOpenLst);
              console.log("****************");

              for (var i = 0; i < self.openLst.length; ++i) {
                var targetNode = self.openLst[i];
                console.log("Point:" + targetNode.x + " ," + targetNode.y + "  :g=" + targetNode.g + "  h=" + targetNode.h + "  f=" + targetNode.f);
              } //放入关闭列表中 然后再从开启列表中移除


              self.closeLst.push(self.openLst[0]); //找得这个点 又变成新的起点 进入下一次寻路计算了

              start = self.openLst[0];
              self.openLst.shift(); //如果这个点已经是终点 那么得到最终结果返回出去
              //如果这个点 不是终点 那么继续寻路

              if (start == end) {
                //找完了 找到路径
                //返回路径
                self.path = [];
                self.path.push(end); //father是空时是找到start点，start点的father就是空

                while (end.father != null) {
                  self.path.push(end.father);
                  end = end.father;
                } //列表翻正得到正确的路径


                self.path.reverse();
                return self.path;
              }
            }
          }
          /**
           * 排序函数
           * @param a 
           * @param b 
           */

        }, {
          key: "SortOpenLst",
          value: function SortOpenLst(a, b) {
            if (a.f > b.f) return 1;else if (a.f == b.f) return 1;else return -1;
          }
          /**
           *  把临近的点放入开启列表中的函数
           * @param x 
           * @param y 
           * @param g 
           * @param father 
           * @param end 
           */

        }, {
          key: "FindNearlyNodeToOpenLst",
          value: function FindNearlyNodeToOpenLst(x, y, g, father, end) {
            var self = this; //边界判断

            if (x < 0 || x >= self.mapW || y < 0 || y >= self.mapH) return; //在范围内 再去取点

            var tempNode = self.nodes[x][y]; //判断这些点 是否是边界 是否是阻挡 是否在开启或者关闭列表 如果都不是 才放入开启列表

            if (tempNode == null || tempNode.type == (_crd && E_Node_Type === void 0 ? (_reportPossibleCrUseOfE_Node_Type({
              error: Error()
            }), E_Node_Type) : E_Node_Type).Stop || self.IsInArray(self.closeLst, tempNode) || self.IsInArray(self.openLst, tempNode)) return; //计算f值
            //f=g+h
            //记录父对象

            tempNode.father = father; //计算g  我离起点的距离  就是我父节点离起点的距离 +我离我父节点的距离

            tempNode.g = father.g + g; //曼哈顿街区算法

            tempNode.h = Math.abs(end.x - tempNode.x) + Math.abs(end.y - tempNode.y);
            tempNode.f = tempNode.g + tempNode.h; //如果通过了上面的合法验证 存放到开启列表中

            self.openLst.push(tempNode);
          }
          /**
           * 是否在数组里
           * @param arr 
           * @param target
           */

        }, {
          key: "IsInArray",
          value: function IsInArray(arr, target) {
            var isExit = false;
            arr.find(function (val) {
              if (val == target) return isExit = true;
            });
            return isExit;
          }
          /**
           * 生成随机数
           * @param min 最小值
           * @param max 最大值
           */

        }, {
          key: "RandomNum",
          value: function RandomNum(min, max) {
            switch (arguments.length) {
              case 1:
                return parseInt((Math.random() * min + 1).toString(), 10);
                break;

              case 2:
                return parseInt((Math.random() * (max - min + 1) + min).toString(), 10);
                break;

              default:
                return 0;
                break;
            }
          }
          /**
           * 工具类，生成网格
           */

        }, {
          key: "DrawMap",
          value: function DrawMap(col, row, color) {
            var self = this;
            color = color != undefined ? color : Color.GRAY;
            self.map.fillColor = color;
            var posX = 2 + col * (self.mapW + 2);
            var posY = 2 + row * (self.mapH + 2);
            self.map.fillRect(posX, posY, self.mapW, self.mapH);
            console.log("Draw Map...");
          }
          /**
           * 获取玩家所在的格子
           * @param pos1 玩家二维坐标
           * @param pos2 追寻者二维坐标
           */

        }, {
          key: "GetPlayerGrid",
          value: function GetPlayerGrid(pos1, pos2) {
            var self = this; //通过pos去查找Grid
            //首先Grid不一定与玩家坐标对应
            //但与玩家周围的格子相邻
            //传进的坐标是Vec2，这意味着玩家Vec3坐标剔除Y坐标

            console.log("What about pos is:" + pos1); //可以采用碰撞检测，但那太耗性能

            var minDis = 0;
            var isCalDisFrist = true;
            var targetPosArr = [];
            var targetPos = Vec2.ZERO; //以玩家为中心，获取周围8个点或者any

            var nearGridLst = self.CetGridLstByPlayerPos(pos1);
            nearGridLst.forEach(function (element) {
              var tempGrid = element; //计算两点距离

              var v2 = new Vec2(tempGrid.x, tempGrid.y);
              console.log("What about v2 is:" + v2.toString());
              var curDis = self.CalDistance(pos1, v2);
              console.log("curDis is:" + curDis); //循环检测获得最短的那个点

              if (isCalDisFrist == false) {
                if (curDis < minDis) {
                  minDis = curDis; //距离最短的点可能有多个

                  targetPosArr.push(v2);
                  console.log("push element to targetPosArr...");
                } //会出现两种情况：
                //1.在格子里
                //2.在两个格子边界中

              } else {
                //一般来讲，两点不重合的话，距离是大于零的
                //这里用于第一次赋值minDis
                minDis = curDis; //第一次赋值时，也应该push

                targetPosArr.push(v2);
                console.log("push element to targetPosArr in frist...");
              }
            }); //距离最短可能有多个点，我们只取与追捕者视线一致的点
            //这个想法可能也是错的
            //因为有阻挡区域

            var isCalAngleFrist = true;
            var minAngle = 0; //计算角度

            targetPosArr.forEach(function (element) {
              var tempVec2 = element; //拿到最小角度
              //会不会有问题？正负弧度应该不会出现

              var curAngle = self.CalAngle(tempVec2, pos2);
              console.log("what about curAngle is:" + curAngle);

              if (isCalAngleFrist == false) {
                if (curAngle < minAngle) {
                  minAngle = curAngle;
                  targetPos = tempVec2;
                  console.log("what about minAngle is:" + minAngle);
                }
              } else {
                minAngle = curAngle;
                targetPos = tempVec2;
              }
            }); //最后根据点拿到对应的AStarNode

            var targetPlayerNode = self.nodes[targetPos.x][targetPos.y];
            return targetPlayerNode;
          }
          /**
           *  计算两点之间的角度
           * @param v1 
           * @param v2 
           */

        }, {
          key: "CalAngle",
          value: function CalAngle(v1, v2) {
            return Vec2.angle(v1, v2);
          }
          /**
           * 获取以玩家为中心，周围8个点或三个点或两个点或一个点????
           * @param p1 玩家节点
           */

        }, {
          key: "CetGridLstByPlayerPos",
          value: function CetGridLstByPlayerPos(p1) {
            var self = this; //首先划分格子大小一定要有序并且适当、无小数
            //例如：10*10的地图，长度为10宽度也为10，（0，0）（0，1）（0，2）...
            //这样做的好处就是能使问题简单化
            //其次，玩家不可能身处阻挡区域
            //对p1的X,Y分别四舍五入
            //规整化

            var targerX = Math.round(p1.x);
            var targerY = Math.round(p1.y);
            var pos = new Vec2(targerX, targerY); //获取玩家为中心8个点或一个点

            var targetNodeLst = new Array();
            var tempGrid = null; //#region 如果玩家位于边界
            //如果玩家位于边界
            //只需取一点
            //可能位于两点之间
            //最终是哪一点取决于四舍五入的结果

            if (self.IsAtBound(pos) == true) {
              targetNodeLst.push(pos);
              console.log("Pos is at bound");
            } //#endregion
            //#region  如果玩家不位于边界
            else {
                //左上  x-1 y-1
                tempGrid = self.nodes[targerX - 1][targerY - 1];
                targetNodeLst.push(tempGrid); //上 x  y-1

                tempGrid = self.nodes[targerX][targerY - 1];
                targetNodeLst.push(tempGrid); //右上  x+1 y-1

                tempGrid = self.nodes[targerX + 1][targerY - 1];
                targetNodeLst.push(tempGrid); //左 x-1 y

                tempGrid = self.nodes[targerX - 1][targerY];
                targetNodeLst.push(tempGrid); //右 x+1 y

                tempGrid = self.nodes[targerX + 1][targerY];
                targetNodeLst.push(tempGrid); //左下 x-1 y+1

                tempGrid = self.nodes[targerX - 1][targerY + 1];
                targetNodeLst.push(tempGrid); //下 x y+1

                tempGrid = self.nodes[targerX][targerY + 1];
                targetNodeLst.push(tempGrid); //右下 x+1 y+1

                tempGrid = self.nodes[targerX + 1][targerY + 1];
                targetNodeLst.push(tempGrid);
                console.log("GetGridLstByPlayerPos return lst:" + targetNodeLst[0]);
              }

            return targetNodeLst; //#endregion
          }
          /**
           * 是否在边界/是否接近边界
           * @param pos 传入规整化的坐标
           */

        }, {
          key: "IsAtBound",
          value: function IsAtBound(pos) {
            var isAtBound = false; //边界判断

            if (pos.x < 0 || pos.y >= self.mapW || pos.x < 0 || pos.y >= self.mapH) isAtBound = true;
            return isAtBound;
          }
          /**
           * 计算两点之间的距离
           * @param v1 起点 (玩家二维坐标)
           * @param v2 终点 (nodes里的点)
           */

        }, {
          key: "CalDistance",
          value: function CalDistance(v1, v2) {
            var disVal = Vec2.distance(v1, v2);
            console.log("CalDistance's value is:" + disVal);
            return disVal;
          }
        }]);

        return AStarMgr;
      }(Component), _class3.instance = null, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "map", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      _crd = false;

      _cclegacy._RF.pop();
    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vRDovQ29Db3MzRExzdC9NeUFTdGFydC9hc3NldHMvc2NpcHRzL015L0FTdGFyTWdyLnRzIl0sIm5hbWVzIjpbIl9kZWNvcmF0b3IiLCJDb21wb25lbnQiLCJWZWMyIiwiQ29sb3IiLCJHcmFwaGljc0NvbXBvbmVudCIsIkFTdGFyTm9kZSIsIkVfTm9kZV9UeXBlIiwiY2NjbGFzcyIsInByb3BlcnR5IiwiQVN0YXJNZ3IiLCJ0eXBlIiwiaW5zdGFuY2UiLCJub2RlcyIsIkFycmF5Iiwib3BlbkxzdCIsImNsb3NlTHN0IiwicGF0aCIsImNvbnNvbGUiLCJsb2ciLCJ3IiwiaCIsInNlbGYiLCJtYXBXIiwibWFwSCIsImkiLCJqIiwibm9kZU9iaiIsIlJhbmRvbU51bSIsIlN0b3AiLCJXYWxrIiwic3RhcnRQb3MiLCJlbmRQb3MiLCJ4IiwieSIsInN0YXJ0IiwiZW5kIiwiZmF0aGVyIiwiZiIsImciLCJwdXNoIiwiRmluZE5lYXJseU5vZGVUb09wZW5Mc3QiLCJsZW5ndGgiLCJzb3J0IiwiU29ydE9wZW5Mc3QiLCJ0YXJnZXROb2RlIiwic2hpZnQiLCJyZXZlcnNlIiwiYSIsImIiLCJ0ZW1wTm9kZSIsIklzSW5BcnJheSIsIk1hdGgiLCJhYnMiLCJhcnIiLCJ0YXJnZXQiLCJpc0V4aXQiLCJmaW5kIiwidmFsIiwibWluIiwibWF4IiwiYXJndW1lbnRzIiwicGFyc2VJbnQiLCJyYW5kb20iLCJ0b1N0cmluZyIsImNvbCIsInJvdyIsImNvbG9yIiwidW5kZWZpbmVkIiwiR1JBWSIsIm1hcCIsImZpbGxDb2xvciIsInBvc1giLCJwb3NZIiwiZmlsbFJlY3QiLCJwb3MxIiwicG9zMiIsIm1pbkRpcyIsImlzQ2FsRGlzRnJpc3QiLCJ0YXJnZXRQb3NBcnIiLCJ0YXJnZXRQb3MiLCJaRVJPIiwibmVhckdyaWRMc3QiLCJDZXRHcmlkTHN0QnlQbGF5ZXJQb3MiLCJmb3JFYWNoIiwiZWxlbWVudCIsInRlbXBHcmlkIiwidjIiLCJjdXJEaXMiLCJDYWxEaXN0YW5jZSIsImlzQ2FsQW5nbGVGcmlzdCIsIm1pbkFuZ2xlIiwidGVtcFZlYzIiLCJjdXJBbmdsZSIsIkNhbEFuZ2xlIiwidGFyZ2V0UGxheWVyTm9kZSIsInYxIiwiYW5nbGUiLCJwMSIsInRhcmdlclgiLCJyb3VuZCIsInRhcmdlclkiLCJwb3MiLCJ0YXJnZXROb2RlTHN0IiwiSXNBdEJvdW5kIiwiaXNBdEJvdW5kIiwiZGlzVmFsIiwiZGlzdGFuY2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQVNBLE1BQUFBLFUsT0FBQUEsVTtBQUFZQyxNQUFBQSxTLE9BQUFBLFM7QUFBdUJDLE1BQUFBLEksT0FBQUEsSTtBQUFpQkMsTUFBQUEsSyxPQUFBQSxLO0FBQU9DLE1BQUFBLGlCLE9BQUFBLGlCOzs7O0FBQzNEQyxNQUFBQSxTLGdCQUFBQSxTO0FBQVdDLE1BQUFBLFcsZ0JBQUFBLFc7Ozs7OztBQUNaQyxNQUFBQSxPLEdBQXNCUCxVLENBQXRCTyxPO0FBQVNDLE1BQUFBLFEsR0FBYVIsVSxDQUFiUSxRLEVBRWpCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzswQkFFYUMsUSxXQURaRixPQUFPLENBQUMsV0FBRCxDLFVBdUNIQyxRQUFRLENBQUM7QUFBRUUsUUFBQUEsSUFBSSxFQUFFTjtBQUFSLE9BQUQsQzs7Ozs7cUNBbEMwQjtBQUMvQixtQkFBTyxLQUFLTyxRQUFaO0FBQ0g7QUFFRDs7Ozs7O0FBaUNBLDRCQUFjO0FBQUE7O0FBQUE7O0FBQ1Y7QUFEVSxnQkFwQlBDLEtBb0JPLEdBcEJhLElBQUlDLEtBQUosRUFvQmI7QUFBQSxnQkFmTkMsT0FlTSxHQWZnQixJQUFJRCxLQUFKLEVBZWhCO0FBQUEsZ0JBVk5FLFFBVU0sR0FWaUIsSUFBSUYsS0FBSixFQVVqQjtBQUFBLGdCQUxORyxJQUtNLEdBTGEsSUFBSUgsS0FBSixFQUtiOztBQUFBOztBQUVWSixVQUFBQSxRQUFRLENBQUNFLFFBQVQ7QUFGVTtBQUdiOzs7O2lDQUdhO0FBQ1Y7QUFDQU0sWUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksa0JBQVo7QUFDSDtBQUVEOzs7Ozs7OztzQ0FLbUJDLEMsRUFBR0MsQyxFQUFHO0FBQ3JCO0FBQ0E7QUFFQSxnQkFBSUMsSUFBSSxHQUFHLElBQVgsQ0FKcUIsQ0FNckI7O0FBQ0FBLFlBQUFBLElBQUksQ0FBQ0MsSUFBTCxHQUFZSCxDQUFaO0FBQ0FFLFlBQUFBLElBQUksQ0FBQ0UsSUFBTCxHQUFZSCxDQUFaLENBUnFCLENBVXJCO0FBQ0E7QUFFQTs7QUFDQSxpQkFBSyxJQUFJSSxDQUFTLEdBQUcsQ0FBckIsRUFBd0JBLENBQUMsR0FBR0wsQ0FBNUIsRUFBK0IsRUFBRUssQ0FBakMsRUFBb0M7QUFDaEM7QUFDQUgsY0FBQUEsSUFBSSxDQUFDVCxLQUFMLENBQVdZLENBQVgsSUFBZ0IsRUFBaEI7O0FBQ0EsbUJBQUssSUFBSUMsQ0FBUyxHQUFHLENBQXJCLEVBQXdCQSxDQUFDLEdBQUdMLENBQTVCLEVBQStCLEVBQUVLLENBQWpDLEVBQW9DO0FBQ2hDO0FBQ0E7QUFDQSxvQkFBSUMsT0FBa0IsR0FBRztBQUFBO0FBQUEsNENBQWNGLENBQWQsRUFBaUJDLENBQWpCLEVBQXFCSixJQUFJLENBQUNNLFNBQUwsQ0FBZSxDQUFmLEVBQWtCLEdBQWxCLElBQXlCLEVBQXpCLEdBQThCO0FBQUE7QUFBQSxnREFBWUMsSUFBMUMsR0FBaUQ7QUFBQTtBQUFBLGdEQUFZQyxJQUFsRixDQUF6QjtBQUNBUixnQkFBQUEsSUFBSSxDQUFDVCxLQUFMLENBQVdZLENBQVgsRUFBY0MsQ0FBZCxJQUFtQkMsT0FBbkI7QUFDSDtBQUNKO0FBQ0o7QUFFRDs7Ozs7Ozs7bUNBS2dCSSxRLEVBQWdCQyxNLEVBQWM7QUFDMUMsZ0JBQUlWLElBQUksR0FBRyxJQUFYLENBRDBDLENBRTFDO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7O0FBQ0EsZ0JBQUlTLFFBQVEsQ0FBQ0UsQ0FBVCxHQUFhLENBQWIsSUFBa0JGLFFBQVEsQ0FBQ0UsQ0FBVCxJQUFjLEtBQUtWLElBQXJDLElBQ0FRLFFBQVEsQ0FBQ0csQ0FBVCxHQUFhLENBRGIsSUFDa0JILFFBQVEsQ0FBQ0csQ0FBVCxJQUFjLEtBQUtWLElBRHJDLElBRUFRLE1BQU0sQ0FBQ0MsQ0FBUCxHQUFXLENBRlgsSUFFZ0JELE1BQU0sQ0FBQ0MsQ0FBUCxJQUFZLEtBQUtWLElBRmpDLElBR0FTLE1BQU0sQ0FBQ0UsQ0FBUCxHQUFXLENBSFgsSUFHZ0JGLE1BQU0sQ0FBQ0UsQ0FBUCxJQUFZLEtBQUtWLElBSHJDLEVBRzJDO0FBQ3ZDTixjQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSw4Q0FBWjtBQUNBLHFCQUFPLElBQVA7QUFDSCxhQWR5QyxDQWUxQztBQUNBOzs7QUFDQSxnQkFBSWdCLEtBQWdCLEdBQUdiLElBQUksQ0FBQ1QsS0FBTCxDQUFXa0IsUUFBUSxDQUFDRSxDQUFwQixFQUF1QkYsUUFBUSxDQUFDRyxDQUFoQyxDQUF2QjtBQUNBLGdCQUFJRSxHQUFjLEdBQUdkLElBQUksQ0FBQ1QsS0FBTCxDQUFXbUIsTUFBTSxDQUFDQyxDQUFsQixFQUFxQkQsTUFBTSxDQUFDRSxDQUE1QixDQUFyQjs7QUFFQSxnQkFBSUMsS0FBSyxDQUFDeEIsSUFBTixJQUFjO0FBQUE7QUFBQSw0Q0FBWWtCLElBQTFCLElBQWtDTyxHQUFHLENBQUN6QixJQUFKLElBQVk7QUFBQTtBQUFBLDRDQUFZa0IsSUFBOUQsRUFBb0U7QUFDaEVYLGNBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLHFDQUFaO0FBQ0EscUJBQU8sSUFBUDtBQUNILGFBdkJ5QyxDQXlCMUM7QUFFQTs7O0FBQ0FHLFlBQUFBLElBQUksQ0FBQ04sUUFBTCxHQUFnQixFQUFoQjtBQUNBTSxZQUFBQSxJQUFJLENBQUNQLE9BQUwsR0FBZSxFQUFmLENBN0IwQyxDQStCMUM7O0FBQ0FvQixZQUFBQSxLQUFLLENBQUNFLE1BQU4sR0FBZSxJQUFmO0FBQ0FGLFlBQUFBLEtBQUssQ0FBQ0csQ0FBTixHQUFVLENBQVY7QUFDQUgsWUFBQUEsS0FBSyxDQUFDSSxDQUFOLEdBQVUsQ0FBVjtBQUNBSixZQUFBQSxLQUFLLENBQUNkLENBQU4sR0FBVSxDQUFWO0FBQ0FDLFlBQUFBLElBQUksQ0FBQ04sUUFBTCxDQUFjd0IsSUFBZCxDQUFtQkwsS0FBbkI7O0FBRUEsbUJBQU8sSUFBUCxFQUFhO0FBQ1Q7QUFDQTtBQUNBYixjQUFBQSxJQUFJLENBQUNtQix1QkFBTCxDQUE2Qk4sS0FBSyxDQUFDRixDQUFOLEdBQVUsQ0FBdkMsRUFBMENFLEtBQUssQ0FBQ0QsQ0FBTixHQUFVLENBQXBELEVBQXVELEdBQXZELEVBQTREQyxLQUE1RCxFQUFtRUMsR0FBbkUsRUFIUyxDQUtUOztBQUNBZCxjQUFBQSxJQUFJLENBQUNtQix1QkFBTCxDQUE2Qk4sS0FBSyxDQUFDRixDQUFuQyxFQUFzQ0UsS0FBSyxDQUFDRCxDQUFOLEdBQVUsQ0FBaEQsRUFBbUQsQ0FBbkQsRUFBc0RDLEtBQXRELEVBQTZEQyxHQUE3RCxFQU5TLENBUVQ7O0FBQ0FkLGNBQUFBLElBQUksQ0FBQ21CLHVCQUFMLENBQTZCTixLQUFLLENBQUNGLENBQU4sR0FBVSxDQUF2QyxFQUEwQ0UsS0FBSyxDQUFDRCxDQUFOLEdBQVUsQ0FBcEQsRUFBdUQsR0FBdkQsRUFBNERDLEtBQTVELEVBQW1FQyxHQUFuRSxFQVRTLENBV1Q7O0FBQ0FkLGNBQUFBLElBQUksQ0FBQ21CLHVCQUFMLENBQTZCTixLQUFLLENBQUNGLENBQU4sR0FBVSxDQUF2QyxFQUEwQ0UsS0FBSyxDQUFDRCxDQUFoRCxFQUFtRCxDQUFuRCxFQUFzREMsS0FBdEQsRUFBNkRDLEdBQTdELEVBWlMsQ0FjVDs7QUFDQWQsY0FBQUEsSUFBSSxDQUFDbUIsdUJBQUwsQ0FBNkJOLEtBQUssQ0FBQ0YsQ0FBTixHQUFVLENBQXZDLEVBQTBDRSxLQUFLLENBQUNELENBQWhELEVBQW1ELENBQW5ELEVBQXNEQyxLQUF0RCxFQUE2REMsR0FBN0QsRUFmUyxDQWlCVDs7QUFDQWQsY0FBQUEsSUFBSSxDQUFDbUIsdUJBQUwsQ0FBNkJOLEtBQUssQ0FBQ0YsQ0FBTixHQUFVLENBQXZDLEVBQTBDRSxLQUFLLENBQUNELENBQU4sR0FBVSxDQUFwRCxFQUF1RCxHQUF2RCxFQUE0REMsS0FBNUQsRUFBbUVDLEdBQW5FLEVBbEJTLENBb0JUOztBQUNBZCxjQUFBQSxJQUFJLENBQUNtQix1QkFBTCxDQUE2Qk4sS0FBSyxDQUFDRixDQUFuQyxFQUFzQ0UsS0FBSyxDQUFDRCxDQUFOLEdBQVUsQ0FBaEQsRUFBbUQsQ0FBbkQsRUFBc0RDLEtBQXRELEVBQTZEQyxHQUE3RCxFQXJCUyxDQXVCVDs7QUFDQWQsY0FBQUEsSUFBSSxDQUFDbUIsdUJBQUwsQ0FBNkJOLEtBQUssQ0FBQ0YsQ0FBTixHQUFVLENBQXZDLEVBQTBDRSxLQUFLLENBQUNELENBQU4sR0FBVSxDQUFwRCxFQUF1RCxHQUF2RCxFQUE0REMsS0FBNUQsRUFBbUVDLEdBQW5FLEVBeEJTLENBMEJUOztBQUNBLGtCQUFJZCxJQUFJLENBQUNQLE9BQUwsQ0FBYTJCLE1BQWIsSUFBdUIsQ0FBM0IsRUFBOEI7QUFDMUJ4QixnQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksZ0JBQVo7QUFDQSx1QkFBTyxJQUFQO0FBQ0gsZUE5QlEsQ0FnQ1Q7OztBQUNBRyxjQUFBQSxJQUFJLENBQUNQLE9BQUwsQ0FBYTRCLElBQWIsQ0FBa0JyQixJQUFJLENBQUNzQixXQUF2QjtBQUNBMUIsY0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksa0JBQVo7O0FBQ0EsbUJBQUssSUFBSU0sQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR0gsSUFBSSxDQUFDUCxPQUFMLENBQWEyQixNQUFqQyxFQUF5QyxFQUFFakIsQ0FBM0MsRUFBOEM7QUFDMUMsb0JBQUlvQixVQUFVLEdBQUd2QixJQUFJLENBQUNQLE9BQUwsQ0FBYVUsQ0FBYixDQUFqQjtBQUNBUCxnQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksV0FBVzBCLFVBQVUsQ0FBQ1osQ0FBdEIsR0FBMEIsSUFBMUIsR0FBaUNZLFVBQVUsQ0FBQ1gsQ0FBNUMsR0FBZ0QsT0FBaEQsR0FBMERXLFVBQVUsQ0FBQ04sQ0FBckUsR0FBeUUsTUFBekUsR0FBa0ZNLFVBQVUsQ0FBQ3hCLENBQTdGLEdBQWlHLE1BQWpHLEdBQTBHd0IsVUFBVSxDQUFDUCxDQUFqSTtBQUNILGVBdENRLENBd0NUOzs7QUFDQWhCLGNBQUFBLElBQUksQ0FBQ04sUUFBTCxDQUFjd0IsSUFBZCxDQUFtQmxCLElBQUksQ0FBQ1AsT0FBTCxDQUFhLENBQWIsQ0FBbkIsRUF6Q1MsQ0EwQ1Q7O0FBQ0FvQixjQUFBQSxLQUFLLEdBQUdiLElBQUksQ0FBQ1AsT0FBTCxDQUFhLENBQWIsQ0FBUjtBQUNBTyxjQUFBQSxJQUFJLENBQUNQLE9BQUwsQ0FBYStCLEtBQWIsR0E1Q1MsQ0E2Q1Q7QUFDQTs7QUFDQSxrQkFBSVgsS0FBSyxJQUFJQyxHQUFiLEVBQWtCO0FBQ2Q7QUFDQTtBQUNBZCxnQkFBQUEsSUFBSSxDQUFDTCxJQUFMLEdBQVksRUFBWjtBQUNBSyxnQkFBQUEsSUFBSSxDQUFDTCxJQUFMLENBQVV1QixJQUFWLENBQWVKLEdBQWYsRUFKYyxDQUtkOztBQUNBLHVCQUFPQSxHQUFHLENBQUNDLE1BQUosSUFBYyxJQUFyQixFQUEyQjtBQUN2QmYsa0JBQUFBLElBQUksQ0FBQ0wsSUFBTCxDQUFVdUIsSUFBVixDQUFlSixHQUFHLENBQUNDLE1BQW5CO0FBQ0FELGtCQUFBQSxHQUFHLEdBQUdBLEdBQUcsQ0FBQ0MsTUFBVjtBQUNILGlCQVRhLENBV2Q7OztBQUNBZixnQkFBQUEsSUFBSSxDQUFDTCxJQUFMLENBQVU4QixPQUFWO0FBQ0EsdUJBQU96QixJQUFJLENBQUNMLElBQVo7QUFDSDtBQUNKO0FBQ0o7QUFFRDs7Ozs7Ozs7c0NBS29CK0IsQyxFQUFHQyxDLEVBQVE7QUFDM0IsZ0JBQUlELENBQUMsQ0FBQ1YsQ0FBRixHQUFNVyxDQUFDLENBQUNYLENBQVosRUFDSSxPQUFPLENBQVAsQ0FESixLQUVLLElBQUlVLENBQUMsQ0FBQ1YsQ0FBRixJQUFPVyxDQUFDLENBQUNYLENBQWIsRUFDRCxPQUFPLENBQVAsQ0FEQyxLQUdELE9BQU8sQ0FBQyxDQUFSO0FBQ1A7QUFHRDs7Ozs7Ozs7Ozs7a0RBUWdDTCxDLEVBQUdDLEMsRUFBR0ssQyxFQUFHRixNLEVBQVFELEcsRUFBSztBQUNsRCxnQkFBSWQsSUFBSSxHQUFHLElBQVgsQ0FEa0QsQ0FHbEQ7O0FBQ0EsZ0JBQUlXLENBQUMsR0FBRyxDQUFKLElBQVNBLENBQUMsSUFBSVgsSUFBSSxDQUFDQyxJQUFuQixJQUNBVyxDQUFDLEdBQUcsQ0FESixJQUNTQSxDQUFDLElBQUlaLElBQUksQ0FBQ0UsSUFEdkIsRUFFSSxPQU44QyxDQVFsRDs7QUFDQSxnQkFBSTBCLFFBQVEsR0FBRzVCLElBQUksQ0FBQ1QsS0FBTCxDQUFXb0IsQ0FBWCxFQUFjQyxDQUFkLENBQWYsQ0FUa0QsQ0FVbEQ7O0FBQ0EsZ0JBQUlnQixRQUFRLElBQUksSUFBWixJQUNBQSxRQUFRLENBQUN2QyxJQUFULElBQWlCO0FBQUE7QUFBQSw0Q0FBWWtCLElBRDdCLElBRUFQLElBQUksQ0FBQzZCLFNBQUwsQ0FBZTdCLElBQUksQ0FBQ04sUUFBcEIsRUFBOEJrQyxRQUE5QixDQUZBLElBR0E1QixJQUFJLENBQUM2QixTQUFMLENBQWU3QixJQUFJLENBQUNQLE9BQXBCLEVBQTZCbUMsUUFBN0IsQ0FISixFQUlJLE9BZjhDLENBaUJsRDtBQUNBO0FBQ0E7O0FBQ0FBLFlBQUFBLFFBQVEsQ0FBQ2IsTUFBVCxHQUFrQkEsTUFBbEIsQ0FwQmtELENBcUJsRDs7QUFDQWEsWUFBQUEsUUFBUSxDQUFDWCxDQUFULEdBQWFGLE1BQU0sQ0FBQ0UsQ0FBUCxHQUFXQSxDQUF4QixDQXRCa0QsQ0F1QmxEOztBQUNBVyxZQUFBQSxRQUFRLENBQUM3QixDQUFULEdBQWErQixJQUFJLENBQUNDLEdBQUwsQ0FBU2pCLEdBQUcsQ0FBQ0gsQ0FBSixHQUFRaUIsUUFBUSxDQUFDakIsQ0FBMUIsSUFBK0JtQixJQUFJLENBQUNDLEdBQUwsQ0FBU2pCLEdBQUcsQ0FBQ0YsQ0FBSixHQUFRZ0IsUUFBUSxDQUFDaEIsQ0FBMUIsQ0FBNUM7QUFDQWdCLFlBQUFBLFFBQVEsQ0FBQ1osQ0FBVCxHQUFhWSxRQUFRLENBQUNYLENBQVQsR0FBYVcsUUFBUSxDQUFDN0IsQ0FBbkMsQ0F6QmtELENBMkJsRDs7QUFDQUMsWUFBQUEsSUFBSSxDQUFDUCxPQUFMLENBQWF5QixJQUFiLENBQWtCVSxRQUFsQjtBQUNIO0FBRUQ7Ozs7Ozs7O29DQUtrQkksRyxFQUFpQkMsTSxFQUFpQjtBQUNoRCxnQkFBSUMsTUFBZSxHQUFHLEtBQXRCO0FBQ0FGLFlBQUFBLEdBQUcsQ0FBQ0csSUFBSixDQUFTLFVBQVVDLEdBQVYsRUFBZTtBQUNwQixrQkFBSUEsR0FBRyxJQUFJSCxNQUFYLEVBQ0ksT0FBT0MsTUFBTSxHQUFHLElBQWhCO0FBQ1AsYUFIRDtBQUlBLG1CQUFPQSxNQUFQO0FBQ0g7QUFFRDs7Ozs7Ozs7b0NBS2tCRyxHLEVBQWFDLEcsRUFBYTtBQUN4QyxvQkFBUUMsU0FBUyxDQUFDbkIsTUFBbEI7QUFDSSxtQkFBSyxDQUFMO0FBQ0ksdUJBQU9vQixRQUFRLENBQUMsQ0FBQ1YsSUFBSSxDQUFDVyxNQUFMLEtBQWdCSixHQUFoQixHQUFzQixDQUF2QixFQUEwQkssUUFBMUIsRUFBRCxFQUF1QyxFQUF2QyxDQUFmO0FBQ0E7O0FBQ0osbUJBQUssQ0FBTDtBQUNJLHVCQUFPRixRQUFRLENBQUMsQ0FBQ1YsSUFBSSxDQUFDVyxNQUFMLE1BQWlCSCxHQUFHLEdBQUdELEdBQU4sR0FBWSxDQUE3QixJQUFrQ0EsR0FBbkMsRUFBd0NLLFFBQXhDLEVBQUQsRUFBcUQsRUFBckQsQ0FBZjtBQUNBOztBQUNKO0FBQ0ksdUJBQU8sQ0FBUDtBQUNBO0FBVFI7QUFXSDtBQUVEOzs7Ozs7a0NBR2dCQyxHLEVBQVVDLEcsRUFBVUMsSyxFQUFjO0FBQzlDLGdCQUFJN0MsSUFBSSxHQUFHLElBQVg7QUFFQTZDLFlBQUFBLEtBQUssR0FBR0EsS0FBSyxJQUFJQyxTQUFULEdBQXFCRCxLQUFyQixHQUE2Qi9ELEtBQUssQ0FBQ2lFLElBQTNDO0FBQ0EvQyxZQUFBQSxJQUFJLENBQUNnRCxHQUFMLENBQVNDLFNBQVQsR0FBcUJKLEtBQXJCO0FBQ0EsZ0JBQUlLLElBQUksR0FBRyxJQUFJUCxHQUFHLElBQUkzQyxJQUFJLENBQUNDLElBQUwsR0FBWSxDQUFoQixDQUFsQjtBQUNBLGdCQUFJa0QsSUFBSSxHQUFHLElBQUlQLEdBQUcsSUFBSTVDLElBQUksQ0FBQ0UsSUFBTCxHQUFZLENBQWhCLENBQWxCO0FBQ0FGLFlBQUFBLElBQUksQ0FBQ2dELEdBQUwsQ0FBU0ksUUFBVCxDQUFrQkYsSUFBbEIsRUFBd0JDLElBQXhCLEVBQThCbkQsSUFBSSxDQUFDQyxJQUFuQyxFQUF5Q0QsSUFBSSxDQUFDRSxJQUE5QztBQUNBTixZQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxhQUFaO0FBQ0g7QUFHRDs7Ozs7Ozs7d0NBS3FCd0QsSSxFQUFZQyxJLEVBQXVCO0FBRXBELGdCQUFJdEQsSUFBSSxHQUFHLElBQVgsQ0FGb0QsQ0FHcEQ7QUFDQTtBQUNBO0FBQ0E7O0FBRUFKLFlBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLHVCQUF1QndELElBQW5DLEVBUm9ELENBVXBEOztBQUNBLGdCQUFJRSxNQUFNLEdBQUcsQ0FBYjtBQUNBLGdCQUFJQyxhQUFhLEdBQUcsSUFBcEI7QUFFQSxnQkFBSUMsWUFBeUIsR0FBRyxFQUFoQztBQUNBLGdCQUFJQyxTQUFlLEdBQUc3RSxJQUFJLENBQUM4RSxJQUEzQixDQWZvRCxDQWlCcEQ7O0FBQ0EsZ0JBQUlDLFdBQVcsR0FBRzVELElBQUksQ0FBQzZELHFCQUFMLENBQTJCUixJQUEzQixDQUFsQjtBQUNBTyxZQUFBQSxXQUFXLENBQUNFLE9BQVosQ0FBb0IsVUFBQUMsT0FBTyxFQUFJO0FBQzNCLGtCQUFJQyxRQUFtQixHQUFHRCxPQUExQixDQUQyQixDQUczQjs7QUFDQSxrQkFBSUUsRUFBUSxHQUFHLElBQUlwRixJQUFKLENBQVNtRixRQUFRLENBQUNyRCxDQUFsQixFQUFxQnFELFFBQVEsQ0FBQ3BELENBQTlCLENBQWY7QUFDQWhCLGNBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLHNCQUFzQm9FLEVBQUUsQ0FBQ3ZCLFFBQUgsRUFBbEM7QUFDQSxrQkFBSXdCLE1BQWMsR0FBR2xFLElBQUksQ0FBQ21FLFdBQUwsQ0FBaUJkLElBQWpCLEVBQXVCWSxFQUF2QixDQUFyQjtBQUNBckUsY0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksZUFBZXFFLE1BQTNCLEVBUDJCLENBUTNCOztBQUNBLGtCQUFJVixhQUFhLElBQUksS0FBckIsRUFBNEI7QUFDeEIsb0JBQUlVLE1BQU0sR0FBR1gsTUFBYixFQUFxQjtBQUNqQkEsa0JBQUFBLE1BQU0sR0FBR1csTUFBVCxDQURpQixDQUVqQjs7QUFDQVQsa0JBQUFBLFlBQVksQ0FBQ3ZDLElBQWIsQ0FBa0IrQyxFQUFsQjtBQUNBckUsa0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGlDQUFaO0FBQ0gsaUJBTnVCLENBT3hCO0FBQ0E7QUFDQTs7QUFDSCxlQVZELE1BV0s7QUFDRDtBQUNBO0FBQ0EwRCxnQkFBQUEsTUFBTSxHQUFHVyxNQUFULENBSEMsQ0FJRDs7QUFDQVQsZ0JBQUFBLFlBQVksQ0FBQ3ZDLElBQWIsQ0FBa0IrQyxFQUFsQjtBQUNBckUsZ0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLDBDQUFaO0FBQ0g7QUFDSixhQTVCRCxFQW5Cb0QsQ0FnRHBEO0FBQ0E7QUFDQTs7QUFDQSxnQkFBSXVFLGVBQWUsR0FBRyxJQUF0QjtBQUNBLGdCQUFJQyxRQUFRLEdBQUcsQ0FBZixDQXBEb0QsQ0FxRHBEOztBQUNBWixZQUFBQSxZQUFZLENBQUNLLE9BQWIsQ0FBcUIsVUFBQUMsT0FBTyxFQUFJO0FBQzVCLGtCQUFJTyxRQUFjLEdBQUdQLE9BQXJCLENBRDRCLENBRzVCO0FBQ0E7O0FBQ0Esa0JBQUlRLFFBQVEsR0FBR3ZFLElBQUksQ0FBQ3dFLFFBQUwsQ0FBY0YsUUFBZCxFQUF3QmhCLElBQXhCLENBQWY7QUFDQTFELGNBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLDRCQUE0QjBFLFFBQXhDOztBQUNBLGtCQUFJSCxlQUFlLElBQUksS0FBdkIsRUFBOEI7QUFDMUIsb0JBQUlHLFFBQVEsR0FBR0YsUUFBZixFQUF5QjtBQUNyQkEsa0JBQUFBLFFBQVEsR0FBR0UsUUFBWDtBQUNBYixrQkFBQUEsU0FBUyxHQUFDWSxRQUFWO0FBQ0ExRSxrQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksNEJBQTRCd0UsUUFBeEM7QUFDSDtBQUNKLGVBTkQsTUFPSztBQUNEQSxnQkFBQUEsUUFBUSxHQUFHRSxRQUFYO0FBQ0FiLGdCQUFBQSxTQUFTLEdBQUNZLFFBQVY7QUFDSDtBQUNKLGFBbEJELEVBdERvRCxDQTBFcEQ7O0FBQ0EsZ0JBQUlHLGdCQUEwQixHQUFFekUsSUFBSSxDQUFDVCxLQUFMLENBQVdtRSxTQUFTLENBQUMvQyxDQUFyQixFQUF3QitDLFNBQVMsQ0FBQzlDLENBQWxDLENBQWhDO0FBQ0EsbUJBQVE2RCxnQkFBUjtBQUNIO0FBRUQ7Ozs7Ozs7O21DQUtpQkMsRSxFQUFVVCxFLEVBQWtCO0FBQ3pDLG1CQUFPcEYsSUFBSSxDQUFDOEYsS0FBTCxDQUFXRCxFQUFYLEVBQWVULEVBQWYsQ0FBUDtBQUNIO0FBRUQ7Ozs7Ozs7Z0RBSThCVyxFLEVBQXNCO0FBRWhELGdCQUFJNUUsSUFBSSxHQUFHLElBQVgsQ0FGZ0QsQ0FJaEQ7QUFDQTtBQUNBO0FBRUE7QUFFQTtBQUNBOztBQUNBLGdCQUFJNkUsT0FBTyxHQUFHL0MsSUFBSSxDQUFDZ0QsS0FBTCxDQUFXRixFQUFFLENBQUNqRSxDQUFkLENBQWQ7QUFDQSxnQkFBSW9FLE9BQU8sR0FBR2pELElBQUksQ0FBQ2dELEtBQUwsQ0FBV0YsRUFBRSxDQUFDaEUsQ0FBZCxDQUFkO0FBRUEsZ0JBQUlvRSxHQUFTLEdBQUcsSUFBSW5HLElBQUosQ0FBU2dHLE9BQVQsRUFBa0JFLE9BQWxCLENBQWhCLENBZmdELENBZ0JoRDs7QUFDQSxnQkFBSUUsYUFBeUIsR0FBRyxJQUFJekYsS0FBSixFQUFoQztBQUNBLGdCQUFJd0UsUUFBUSxHQUFHLElBQWYsQ0FsQmdELENBcUJoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLGdCQUFJaEUsSUFBSSxDQUFDa0YsU0FBTCxDQUFlRixHQUFmLEtBQXVCLElBQTNCLEVBQWlDO0FBQzdCQyxjQUFBQSxhQUFhLENBQUMvRCxJQUFkLENBQW1COEQsR0FBbkI7QUFDQXBGLGNBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGlCQUFaO0FBQ0gsYUFIRCxDQUlBO0FBRUE7QUFOQSxpQkFRSztBQUNEO0FBQ0FtRSxnQkFBQUEsUUFBUSxHQUFHaEUsSUFBSSxDQUFDVCxLQUFMLENBQVdzRixPQUFPLEdBQUcsQ0FBckIsRUFBd0JFLE9BQU8sR0FBRyxDQUFsQyxDQUFYO0FBQ0FFLGdCQUFBQSxhQUFhLENBQUMvRCxJQUFkLENBQW1COEMsUUFBbkIsRUFIQyxDQUtEOztBQUNBQSxnQkFBQUEsUUFBUSxHQUFHaEUsSUFBSSxDQUFDVCxLQUFMLENBQVdzRixPQUFYLEVBQW9CRSxPQUFPLEdBQUcsQ0FBOUIsQ0FBWDtBQUNBRSxnQkFBQUEsYUFBYSxDQUFDL0QsSUFBZCxDQUFtQjhDLFFBQW5CLEVBUEMsQ0FTRDs7QUFDQUEsZ0JBQUFBLFFBQVEsR0FBR2hFLElBQUksQ0FBQ1QsS0FBTCxDQUFXc0YsT0FBTyxHQUFHLENBQXJCLEVBQXdCRSxPQUFPLEdBQUcsQ0FBbEMsQ0FBWDtBQUNBRSxnQkFBQUEsYUFBYSxDQUFDL0QsSUFBZCxDQUFtQjhDLFFBQW5CLEVBWEMsQ0FhRDs7QUFDQUEsZ0JBQUFBLFFBQVEsR0FBR2hFLElBQUksQ0FBQ1QsS0FBTCxDQUFXc0YsT0FBTyxHQUFHLENBQXJCLEVBQXdCRSxPQUF4QixDQUFYO0FBQ0FFLGdCQUFBQSxhQUFhLENBQUMvRCxJQUFkLENBQW1COEMsUUFBbkIsRUFmQyxDQWlCRDs7QUFDQUEsZ0JBQUFBLFFBQVEsR0FBR2hFLElBQUksQ0FBQ1QsS0FBTCxDQUFXc0YsT0FBTyxHQUFHLENBQXJCLEVBQXdCRSxPQUF4QixDQUFYO0FBQ0FFLGdCQUFBQSxhQUFhLENBQUMvRCxJQUFkLENBQW1COEMsUUFBbkIsRUFuQkMsQ0FxQkQ7O0FBQ0FBLGdCQUFBQSxRQUFRLEdBQUdoRSxJQUFJLENBQUNULEtBQUwsQ0FBV3NGLE9BQU8sR0FBRyxDQUFyQixFQUF3QkUsT0FBTyxHQUFHLENBQWxDLENBQVg7QUFDQUUsZ0JBQUFBLGFBQWEsQ0FBQy9ELElBQWQsQ0FBbUI4QyxRQUFuQixFQXZCQyxDQXlCRDs7QUFDQUEsZ0JBQUFBLFFBQVEsR0FBR2hFLElBQUksQ0FBQ1QsS0FBTCxDQUFXc0YsT0FBWCxFQUFvQkUsT0FBTyxHQUFHLENBQTlCLENBQVg7QUFDQUUsZ0JBQUFBLGFBQWEsQ0FBQy9ELElBQWQsQ0FBbUI4QyxRQUFuQixFQTNCQyxDQTZCRDs7QUFDQUEsZ0JBQUFBLFFBQVEsR0FBR2hFLElBQUksQ0FBQ1QsS0FBTCxDQUFXc0YsT0FBTyxHQUFHLENBQXJCLEVBQXdCRSxPQUFPLEdBQUcsQ0FBbEMsQ0FBWDtBQUNBRSxnQkFBQUEsYUFBYSxDQUFDL0QsSUFBZCxDQUFtQjhDLFFBQW5CO0FBQ0FwRSxnQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksc0NBQXNDb0YsYUFBYSxDQUFDLENBQUQsQ0FBL0Q7QUFDSDs7QUFDRCxtQkFBT0EsYUFBUCxDQXBFZ0QsQ0FxRWhEO0FBQ0g7QUFFRDs7Ozs7OztvQ0FJa0JELEcsRUFBb0I7QUFDbEMsZ0JBQUlHLFNBQWtCLEdBQUcsS0FBekIsQ0FEa0MsQ0FFbEM7O0FBQ0EsZ0JBQUlILEdBQUcsQ0FBQ3JFLENBQUosR0FBUSxDQUFSLElBQWFxRSxHQUFHLENBQUNwRSxDQUFKLElBQVNaLElBQUksQ0FBQ0MsSUFBM0IsSUFDQStFLEdBQUcsQ0FBQ3JFLENBQUosR0FBUSxDQURSLElBQ2FxRSxHQUFHLENBQUNwRSxDQUFKLElBQVNaLElBQUksQ0FBQ0UsSUFEL0IsRUFFSWlGLFNBQVMsR0FBRyxJQUFaO0FBQ0osbUJBQU9BLFNBQVA7QUFDSDtBQUdEOzs7Ozs7OztzQ0FLb0JULEUsRUFBVVQsRSxFQUFrQjtBQUM1QyxnQkFBSW1CLE1BQU0sR0FBR3ZHLElBQUksQ0FBQ3dHLFFBQUwsQ0FBY1gsRUFBZCxFQUFrQlQsRUFBbEIsQ0FBYjtBQUNBckUsWUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksNEJBQTRCdUYsTUFBeEM7QUFDQSxtQkFBT0EsTUFBUDtBQUNIOzs7O1FBcmV5QnhHLFMsV0FFWFUsUSxHQUFxQixJOzs7OztpQkFxQ0gsSSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IF9kZWNvcmF0b3IsIENvbXBvbmVudCwgTm9kZSwgVmVjMywgVmVjMiwgYW5pbWF0aW9uLCBDb2xvciwgR3JhcGhpY3NDb21wb25lbnQsIHJlbmRlcmVyLCBMYXllcnMgfSBmcm9tICdjYyc7XHJcbmltcG9ydCB7IEFTdGFyTm9kZSwgRV9Ob2RlX1R5cGUgfSBmcm9tICcuL0FTdGFyTm9kZSc7XHJcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IF9kZWNvcmF0b3I7XHJcblxyXG4vLy8gPHN1bW1hcnk+XHJcbi8vLyBBU3RhcuWvu+i3r+eul+azleeahOWfuuacrOWOn+eQhuWwseaYr+S4jeWBnOeahOaJvuiHquW3seWRqOWbtOeahOeCue+8jOmAieWHuuS4gOS4quaWsOeahOeCueS9nOS4uui1t+eCueWGjeW+queOr+eahOaJvlxyXG4vLy8gMS7lr7vot6/mtojogJflhazlvI/vvJpcclxuLy8vICAgICAgICAgICBmKOWvu+i3r+a2iOiAlyk9ZyjnprvotbfngrnnmoTot53nprspK2go56a757uI54K555qE6Led56a7KVxyXG4vLy8gMi7lvIDlkK/liJfooajvvJpcclxuLy8vIOavj+asoeS7juaWsOeahOeCueaJvuWRqOWbtOeahOeCueaXtu+8jOWmguaenOWRqOWbtOeahOeCueW3sue7j+WcqOW8gOWQr+WIl+ihqOaIluiAheWFs+mXreWIl+ihqOS4reS6hu+8jOaIkeS7rOWwseS4jeWOu+euoeWug+S6hlxyXG4vLy8gMy7lhbPpl63liJfooajvvJpcclxuLy8vIOavj+asoeW+gOWFs+mXreWIl+ihqOS4reaUvueCueaXtu+8jOaIkeS7rOmDveW6lOivpeWIpOaWrei/meS4queCueaYr+S4jeaYr+WSjOe7iOeCueS4gOagt++8jOWmguaenOaYr+S4gOagt+ivgeaYjui3r+W+hOaJvuWujOS6hu+8jOWmguaenOS4jeS4gOagt++8jOe7p+e7reaJvuOAglxyXG4vLy8gNC7moLzlrZDlr7nosaHnmoTniLblr7nosaEgICBcclxuLy8vIDwvc3VtbWFyeT5cclxuQGNjY2xhc3MoJ0FTdGFydE1ncicpXHJcbmV4cG9ydCBjbGFzcyBBU3Rhck1nciBleHRlbmRzIENvbXBvbmVudCB7XHJcblxyXG4gICAgcHJpdmF0ZSBzdGF0aWMgaW5zdGFuY2U6IEFTdGFyTWdyID0gbnVsbDtcclxuXHJcbiAgICBwdWJsaWMgc3RhdGljIEluc3RhbmNlKCk6IEFTdGFyTWdyIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5pbnN0YW5jZTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIOWcsOWbvueahOWuvVxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIG1hcFc6IG51bWJlcjtcclxuXHJcbiAgICAvKipcclxuICAgICAqIOWcsOWbvueahOmrmFxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIG1hcEg6IG51bWJlcjtcclxuXHJcbiAgICAvKipcclxuICAgICAqIOWcsOWbvuebuOWFs+aJgOacieeahOagvOWtkOWvueixoeWuueWZqFxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgbm9kZXM6IEFycmF5PGFueT4gPSBuZXcgQXJyYXk8YW55PigpO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICog5byA5ZCv5YiX6KGoXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgb3BlbkxzdDogQXJyYXk8YW55PiA9IG5ldyBBcnJheTxhbnk+KCk7XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiAg5YWz6Zet5YiX6KGoXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgY2xvc2VMc3Q6IEFycmF5PGFueT4gPSBuZXcgQXJyYXk8YW55PigpO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICog6Lev5b6EXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgcGF0aDogQXJyYXk8YW55PiA9IG5ldyBBcnJheTxhbnk+KCk7XHJcblxyXG4gICAgQHByb3BlcnR5KHsgdHlwZTogR3JhcGhpY3NDb21wb25lbnQgfSlcclxuICAgIHByaXZhdGUgbWFwOiBHcmFwaGljc0NvbXBvbmVudCA9IG51bGw7XHJcblxyXG4gICAgY29uc3RydWN0b3IoKSB7XHJcbiAgICAgICAgc3VwZXIoKTtcclxuICAgICAgICBBU3Rhck1nci5pbnN0YW5jZSA9IHRoaXM7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIHB1YmxpYyBJbml0KCkge1xyXG4gICAgICAgIC8vQVN0YXJNZ3IuaW5zdGFuY2U9dGhpcztcclxuICAgICAgICBjb25zb2xlLmxvZyhcIkFTdGFyTWdyIEluaXQuLi5cIik7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiDliJ3lp4vljJblnLDlm75cclxuICAgICAqIEBwYXJhbSB3IOWcsOWbvueahOWuvVxyXG4gICAgICogQHBhcmFtIGgg5Zyw5Zu+55qE6auYXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBJbml0TWFwSW5mbyh3LCBoKSB7XHJcbiAgICAgICAgLy/moLnmja7lrr3pq5gg5Yib5bu65qC85a2QIOmYu+aMoeeahOmXrumimCDmiJHku6zlj6/ku6Xpmo/mnLrpmLvmjKFcclxuICAgICAgICAvL+WboOS4uuaIkeS7rOeOsOWcqOayoeacieWcsOWbvuebuOWFs+eahOaVsOaNrlxyXG5cclxuICAgICAgICBsZXQgc2VsZiA9IHRoaXM7XHJcblxyXG4gICAgICAgIC8v6K6w5b2V5a696auYXHJcbiAgICAgICAgc2VsZi5tYXBXID0gdztcclxuICAgICAgICBzZWxmLm1hcEggPSBoO1xyXG5cclxuICAgICAgICAvL+WjsOaYjuWuueWZqOWPr+S7peijheWkmuWwkeS4quagvOWtkFxyXG4gICAgICAgIC8vc2VsZi5ub2Rlcz0gbmV3IEFTdGFyTm9kZVt3XVtoXTtcclxuXHJcbiAgICAgICAgLy/nlJ/miJDmoLzlrZBcclxuICAgICAgICBmb3IgKGxldCBpOiBudW1iZXIgPSAwOyBpIDwgdzsgKytpKSB7XHJcbiAgICAgICAgICAgIC8vY29uc29sZS5sb2coXCJzZWxmLm5vZGVzLmxlbmd0aDpcIiArIHNlbGYubm9kZXMubGVuZ3RoKTtcclxuICAgICAgICAgICAgc2VsZi5ub2Rlc1tpXSA9IFtdO1xyXG4gICAgICAgICAgICBmb3IgKGxldCBqOiBudW1iZXIgPSAwOyBqIDwgaDsgKytqKSB7XHJcbiAgICAgICAgICAgICAgICAvL+eUqOS4ieebrui/kOeul+espumaj+acuueUn+aIkOmYu+aMoeagvOWtkFxyXG4gICAgICAgICAgICAgICAgLy/lupTor6Xku47lnLDlm77phY3nva7ooajor7vlj5bnlJ/miJDnmoRcclxuICAgICAgICAgICAgICAgIGxldCBub2RlT2JqOiBBU3Rhck5vZGUgPSBuZXcgQVN0YXJOb2RlKGksIGosIChzZWxmLlJhbmRvbU51bSgwLCAxMDApIDwgMjAgPyBFX05vZGVfVHlwZS5TdG9wIDogRV9Ob2RlX1R5cGUuV2FsaykpO1xyXG4gICAgICAgICAgICAgICAgc2VsZi5ub2Rlc1tpXVtqXSA9IG5vZGVPYmo7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiDlr7vot6/mlrnms5VcclxuICAgICAqIEBwYXJhbSBzdGFydFBvcyDlvIDlp4vngrlcclxuICAgICAqIEBwYXJhbSBlbmRQb3Mg57uT5p2f54K5XHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBGaW5kUGF0aChzdGFydFBvczogVmVjMiwgZW5kUG9zOiBWZWMyKSB7XHJcbiAgICAgICAgbGV0IHNlbGYgPSB0aGlzO1xyXG4gICAgICAgIC8v5a6e6ZmF6aG555uu5LitIOS8oOWFpeeahOeCueW+gOW+gOaYryDlnZDmoIfns7vkuK3nmoTngrlcclxuICAgICAgICAvL+aIkeS7rOi/memHjOecgeeVpeaNoueul+eahOatpemqpCDnm7TmjqXorqTkuLrlroPmmK/kvKDov5vmnaXnmoTmoLzlrZDlnZDmoIdcclxuXHJcbiAgICAgICAgLy/pppblhYjliKTmlq0g5Lyg5YWl55qE5Lik5Liq54K5IOaYr+WQpuWQiOazlVxyXG4gICAgICAgIC8vMS7pppblhYgg6KaB5Zyo5Zyw5Zu+6IyD5Zu05YaFXHJcbiAgICAgICAgLy/lpoLmnpzkuI3lkIjms5Ug5bqU6K+l55u05o6lIOi/lOWbnm51bGwg5oSP5ZGz552A5LiN6IO95a+76LevXHJcbiAgICAgICAgaWYgKHN0YXJ0UG9zLnggPCAwIHx8IHN0YXJ0UG9zLnggPj0gdGhpcy5tYXBXIHx8XHJcbiAgICAgICAgICAgIHN0YXJ0UG9zLnkgPCAwIHx8IHN0YXJ0UG9zLnkgPj0gdGhpcy5tYXBIIHx8XHJcbiAgICAgICAgICAgIGVuZFBvcy54IDwgMCB8fCBlbmRQb3MueCA+PSB0aGlzLm1hcFcgfHxcclxuICAgICAgICAgICAgZW5kUG9zLnkgPCAwIHx8IGVuZFBvcy55ID49IHRoaXMubWFwSCkge1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIlN0YXJ0IG9yIGVuZCBwb2ludHMgYXJlIG91dHNpZGUgdGhlIG1hcCBncmlkXCIpO1xyXG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8yLuimgeS4jeaYr+mYu+aMoVxyXG4gICAgICAgIC8v5b6X5Yiw6LW354K55ZKM57uI54K5ICDlr7nlupTnmoTmoLzlrZBcclxuICAgICAgICBsZXQgc3RhcnQ6IEFTdGFyTm9kZSA9IHNlbGYubm9kZXNbc3RhcnRQb3MueF1bc3RhcnRQb3MueV07XHJcbiAgICAgICAgbGV0IGVuZDogQVN0YXJOb2RlID0gc2VsZi5ub2Rlc1tlbmRQb3MueF1bZW5kUG9zLnldO1xyXG5cclxuICAgICAgICBpZiAoc3RhcnQudHlwZSA9PSBFX05vZGVfVHlwZS5TdG9wIHx8IGVuZC50eXBlID09IEVfTm9kZV9UeXBlLlN0b3ApIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJUaGUgc3RhcnQgb3IgZW5kIHBvaW50IGlzIHRoZSBibG9ja1wiKTtcclxuICAgICAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvL+a4heepuuS4iuS4gOasoeebuOWFs+eahOaVsOaNriDpgb/lhY3ku5bku6zlvbHlk40gIOi/meS4gOasoeeahOWvu+i3r+iuoeeul1xyXG5cclxuICAgICAgICAvL+a4heepuuWFs+mXreWSjOW8gOWQr+WIl+ihqFxyXG4gICAgICAgIHNlbGYuY2xvc2VMc3QgPSBbXTtcclxuICAgICAgICBzZWxmLm9wZW5Mc3QgPSBbXTtcclxuXHJcbiAgICAgICAgLy/miorlvIDlp4vngrnmlL7lhaXlhbPpl63liJfooajkuK1cclxuICAgICAgICBzdGFydC5mYXRoZXIgPSBudWxsO1xyXG4gICAgICAgIHN0YXJ0LmYgPSAwO1xyXG4gICAgICAgIHN0YXJ0LmcgPSAwO1xyXG4gICAgICAgIHN0YXJ0LmggPSAwO1xyXG4gICAgICAgIHNlbGYuY2xvc2VMc3QucHVzaChzdGFydCk7XHJcblxyXG4gICAgICAgIHdoaWxlICh0cnVlKSB7XHJcbiAgICAgICAgICAgIC8v5LuO6LW354K55byA5aeLIOaJvuWRqOWbtOeahOeCuSDlubbmlL7lhaXlvIDlkK/liJfooajkuK1cclxuICAgICAgICAgICAgLy/lt6bkuIogIHgtMSB5LTFcclxuICAgICAgICAgICAgc2VsZi5GaW5kTmVhcmx5Tm9kZVRvT3BlbkxzdChzdGFydC54IC0gMSwgc3RhcnQueSAtIDEsIDEuNCwgc3RhcnQsIGVuZCk7XHJcblxyXG4gICAgICAgICAgICAvL+S4iiB4ICB5LTFcclxuICAgICAgICAgICAgc2VsZi5GaW5kTmVhcmx5Tm9kZVRvT3BlbkxzdChzdGFydC54LCBzdGFydC55IC0gMSwgMSwgc3RhcnQsIGVuZCk7XHJcblxyXG4gICAgICAgICAgICAvL+WPs+S4iiAgeCsxIHktMVxyXG4gICAgICAgICAgICBzZWxmLkZpbmROZWFybHlOb2RlVG9PcGVuTHN0KHN0YXJ0LnggKyAxLCBzdGFydC55IC0gMSwgMS40LCBzdGFydCwgZW5kKTtcclxuXHJcbiAgICAgICAgICAgIC8v5bemIHgtMSB5XHJcbiAgICAgICAgICAgIHNlbGYuRmluZE5lYXJseU5vZGVUb09wZW5Mc3Qoc3RhcnQueCAtIDEsIHN0YXJ0LnksIDEsIHN0YXJ0LCBlbmQpO1xyXG5cclxuICAgICAgICAgICAgLy/lj7MgeCsxIHlcclxuICAgICAgICAgICAgc2VsZi5GaW5kTmVhcmx5Tm9kZVRvT3BlbkxzdChzdGFydC54ICsgMSwgc3RhcnQueSwgMSwgc3RhcnQsIGVuZCk7XHJcblxyXG4gICAgICAgICAgICAvL+W3puS4iyB4LTEgeSsxXHJcbiAgICAgICAgICAgIHNlbGYuRmluZE5lYXJseU5vZGVUb09wZW5Mc3Qoc3RhcnQueCAtIDEsIHN0YXJ0LnkgKyAxLCAxLjQsIHN0YXJ0LCBlbmQpO1xyXG5cclxuICAgICAgICAgICAgLy/kuIsgeCB5KzFcclxuICAgICAgICAgICAgc2VsZi5GaW5kTmVhcmx5Tm9kZVRvT3BlbkxzdChzdGFydC54LCBzdGFydC55ICsgMSwgMSwgc3RhcnQsIGVuZCk7XHJcblxyXG4gICAgICAgICAgICAvL+WPs+S4iyB4KzEgeSsxXHJcbiAgICAgICAgICAgIHNlbGYuRmluZE5lYXJseU5vZGVUb09wZW5Mc3Qoc3RhcnQueCArIDEsIHN0YXJ0LnkgKyAxLCAxLjQsIHN0YXJ0LCBlbmQpO1xyXG5cclxuICAgICAgICAgICAgLy/mrbvot6/liKTmlq0gIOW8gOWQr+WIl+ihqOS4uuepuiDpg73ov5jmsqHmnInmib7liLDnu4jngrkg5bCx6K6k5Li65piv5q276LevXHJcbiAgICAgICAgICAgIGlmIChzZWxmLm9wZW5Mc3QubGVuZ3RoID09IDApIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiQmxpbmQgYWxsZXkuLi5cIik7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLy/pgInlh7rlvIDlkK/liJfooajkuK0g5a+76Lev5raI6ICX5pyA5bCP55qE54K5XHJcbiAgICAgICAgICAgIHNlbGYub3BlbkxzdC5zb3J0KHNlbGYuU29ydE9wZW5Mc3QpO1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIioqKioqKioqKioqKioqKipcIik7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc2VsZi5vcGVuTHN0Lmxlbmd0aDsgKytpKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgdGFyZ2V0Tm9kZSA9IHNlbGYub3BlbkxzdFtpXTtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiUG9pbnQ6XCIgKyB0YXJnZXROb2RlLnggKyBcIiAsXCIgKyB0YXJnZXROb2RlLnkgKyBcIiAgOmc9XCIgKyB0YXJnZXROb2RlLmcgKyBcIiAgaD1cIiArIHRhcmdldE5vZGUuaCArIFwiICBmPVwiICsgdGFyZ2V0Tm9kZS5mKTtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLy/mlL7lhaXlhbPpl63liJfooajkuK0g54S25ZCO5YaN5LuO5byA5ZCv5YiX6KGo5Lit56e76ZmkXHJcbiAgICAgICAgICAgIHNlbGYuY2xvc2VMc3QucHVzaChzZWxmLm9wZW5Mc3RbMF0pO1xyXG4gICAgICAgICAgICAvL+aJvuW+l+i/meS4queCuSDlj4jlj5jmiJDmlrDnmoTotbfngrkg6L+b5YWl5LiL5LiA5qyh5a+76Lev6K6h566X5LqGXHJcbiAgICAgICAgICAgIHN0YXJ0ID0gc2VsZi5vcGVuTHN0WzBdO1xyXG4gICAgICAgICAgICBzZWxmLm9wZW5Mc3Quc2hpZnQoKTtcclxuICAgICAgICAgICAgLy/lpoLmnpzov5nkuKrngrnlt7Lnu4/mmK/nu4jngrkg6YKj5LmI5b6X5Yiw5pyA57uI57uT5p6c6L+U5Zue5Ye65Y67XHJcbiAgICAgICAgICAgIC8v5aaC5p6c6L+Z5Liq54K5IOS4jeaYr+e7iOeCuSDpgqPkuYjnu6fnu63lr7vot69cclxuICAgICAgICAgICAgaWYgKHN0YXJ0ID09IGVuZCkge1xyXG4gICAgICAgICAgICAgICAgLy/mib7lrozkuoYg5om+5Yiw6Lev5b6EXHJcbiAgICAgICAgICAgICAgICAvL+i/lOWbnui3r+W+hFxyXG4gICAgICAgICAgICAgICAgc2VsZi5wYXRoID0gW107XHJcbiAgICAgICAgICAgICAgICBzZWxmLnBhdGgucHVzaChlbmQpO1xyXG4gICAgICAgICAgICAgICAgLy9mYXRoZXLmmK/nqbrml7bmmK/mib7liLBzdGFydOeCue+8jHN0YXJ054K555qEZmF0aGVy5bCx5piv56m6XHJcbiAgICAgICAgICAgICAgICB3aGlsZSAoZW5kLmZhdGhlciAhPSBudWxsKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgc2VsZi5wYXRoLnB1c2goZW5kLmZhdGhlcik7XHJcbiAgICAgICAgICAgICAgICAgICAgZW5kID0gZW5kLmZhdGhlcjtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAvL+WIl+ihqOe/u+ato+W+l+WIsOato+ehrueahOi3r+W+hFxyXG4gICAgICAgICAgICAgICAgc2VsZi5wYXRoLnJldmVyc2UoKTtcclxuICAgICAgICAgICAgICAgIHJldHVybiBzZWxmLnBhdGg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiDmjpLluo/lh73mlbBcclxuICAgICAqIEBwYXJhbSBhIFxyXG4gICAgICogQHBhcmFtIGIgXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgU29ydE9wZW5Mc3QoYSwgYik6IGFueSB7XHJcbiAgICAgICAgaWYgKGEuZiA+IGIuZilcclxuICAgICAgICAgICAgcmV0dXJuIDE7XHJcbiAgICAgICAgZWxzZSBpZiAoYS5mID09IGIuZilcclxuICAgICAgICAgICAgcmV0dXJuIDE7XHJcbiAgICAgICAgZWxzZVxyXG4gICAgICAgICAgICByZXR1cm4gLTE7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICogIOaKiuS4tOi/keeahOeCueaUvuWFpeW8gOWQr+WIl+ihqOS4reeahOWHveaVsFxyXG4gICAgICogQHBhcmFtIHggXHJcbiAgICAgKiBAcGFyYW0geSBcclxuICAgICAqIEBwYXJhbSBnIFxyXG4gICAgICogQHBhcmFtIGZhdGhlciBcclxuICAgICAqIEBwYXJhbSBlbmQgXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgRmluZE5lYXJseU5vZGVUb09wZW5Mc3QoeCwgeSwgZywgZmF0aGVyLCBlbmQpIHtcclxuICAgICAgICBsZXQgc2VsZiA9IHRoaXM7XHJcblxyXG4gICAgICAgIC8v6L6555WM5Yik5patXHJcbiAgICAgICAgaWYgKHggPCAwIHx8IHggPj0gc2VsZi5tYXBXIHx8XHJcbiAgICAgICAgICAgIHkgPCAwIHx8IHkgPj0gc2VsZi5tYXBIKVxyXG4gICAgICAgICAgICByZXR1cm47XHJcblxyXG4gICAgICAgIC8v5Zyo6IyD5Zu05YaFIOWGjeWOu+WPlueCuVxyXG4gICAgICAgIGxldCB0ZW1wTm9kZSA9IHNlbGYubm9kZXNbeF1beV07XHJcbiAgICAgICAgLy/liKTmlq3ov5nkupvngrkg5piv5ZCm5piv6L6555WMIOaYr+WQpuaYr+mYu+aMoSDmmK/lkKblnKjlvIDlkK/miJbogIXlhbPpl63liJfooagg5aaC5p6c6YO95LiN5pivIOaJjeaUvuWFpeW8gOWQr+WIl+ihqFxyXG4gICAgICAgIGlmICh0ZW1wTm9kZSA9PSBudWxsIHx8XHJcbiAgICAgICAgICAgIHRlbXBOb2RlLnR5cGUgPT0gRV9Ob2RlX1R5cGUuU3RvcCB8fFxyXG4gICAgICAgICAgICBzZWxmLklzSW5BcnJheShzZWxmLmNsb3NlTHN0LCB0ZW1wTm9kZSkgfHxcclxuICAgICAgICAgICAgc2VsZi5Jc0luQXJyYXkoc2VsZi5vcGVuTHN0LCB0ZW1wTm9kZSkpXHJcbiAgICAgICAgICAgIHJldHVybjtcclxuXHJcbiAgICAgICAgLy/orqHnrpdm5YC8XHJcbiAgICAgICAgLy9mPWcraFxyXG4gICAgICAgIC8v6K6w5b2V54i25a+56LGhXHJcbiAgICAgICAgdGVtcE5vZGUuZmF0aGVyID0gZmF0aGVyO1xyXG4gICAgICAgIC8v6K6h566XZyAg5oiR56a76LW354K555qE6Led56a7ICDlsLHmmK/miJHniLboioLngrnnprvotbfngrnnmoTot53nprsgK+aIkeemu+aIkeeItuiKgueCueeahOi3neemu1xyXG4gICAgICAgIHRlbXBOb2RlLmcgPSBmYXRoZXIuZyArIGc7XHJcbiAgICAgICAgLy/mm7zlk4jpob/ooZfljLrnrpfms5VcclxuICAgICAgICB0ZW1wTm9kZS5oID0gTWF0aC5hYnMoZW5kLnggLSB0ZW1wTm9kZS54KSArIE1hdGguYWJzKGVuZC55IC0gdGVtcE5vZGUueSk7XHJcbiAgICAgICAgdGVtcE5vZGUuZiA9IHRlbXBOb2RlLmcgKyB0ZW1wTm9kZS5oO1xyXG5cclxuICAgICAgICAvL+WmguaenOmAmui/h+S6huS4iumdoueahOWQiOazlemqjOivgSDlrZjmlL7liLDlvIDlkK/liJfooajkuK1cclxuICAgICAgICBzZWxmLm9wZW5Mc3QucHVzaCh0ZW1wTm9kZSk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiDmmK/lkKblnKjmlbDnu4Tph4xcclxuICAgICAqIEBwYXJhbSBhcnIgXHJcbiAgICAgKiBAcGFyYW0gdGFyZ2V0XHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgSXNJbkFycmF5KGFycjogQXJyYXk8YW55PiwgdGFyZ2V0KTogYm9vbGVhbiB7XHJcbiAgICAgICAgbGV0IGlzRXhpdDogYm9vbGVhbiA9IGZhbHNlO1xyXG4gICAgICAgIGFyci5maW5kKGZ1bmN0aW9uICh2YWwpIHtcclxuICAgICAgICAgICAgaWYgKHZhbCA9PSB0YXJnZXQpXHJcbiAgICAgICAgICAgICAgICByZXR1cm4gaXNFeGl0ID0gdHJ1ZTtcclxuICAgICAgICB9KVxyXG4gICAgICAgIHJldHVybiBpc0V4aXQ7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiDnlJ/miJDpmo/mnLrmlbBcclxuICAgICAqIEBwYXJhbSBtaW4g5pyA5bCP5YC8XHJcbiAgICAgKiBAcGFyYW0gbWF4IOacgOWkp+WAvFxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIFJhbmRvbU51bShtaW46IG51bWJlciwgbWF4KTogbnVtYmVyIHtcclxuICAgICAgICBzd2l0Y2ggKGFyZ3VtZW50cy5sZW5ndGgpIHtcclxuICAgICAgICAgICAgY2FzZSAxOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHBhcnNlSW50KChNYXRoLnJhbmRvbSgpICogbWluICsgMSkudG9TdHJpbmcoKSwgMTApXHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgY2FzZSAyOlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHBhcnNlSW50KChNYXRoLnJhbmRvbSgpICogKG1heCAtIG1pbiArIDEpICsgbWluKS50b1N0cmluZygpLCAxMCk7XHJcbiAgICAgICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgICAgIHJldHVybiAwO1xyXG4gICAgICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICog5bel5YW357G777yM55Sf5oiQ572R5qC8XHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgRHJhd01hcChjb2w6IGFueSwgcm93OiBhbnksIGNvbG9yOiBDb2xvcikge1xyXG4gICAgICAgIGxldCBzZWxmID0gdGhpcztcclxuXHJcbiAgICAgICAgY29sb3IgPSBjb2xvciAhPSB1bmRlZmluZWQgPyBjb2xvciA6IENvbG9yLkdSQVk7XHJcbiAgICAgICAgc2VsZi5tYXAuZmlsbENvbG9yID0gY29sb3I7XHJcbiAgICAgICAgbGV0IHBvc1ggPSAyICsgY29sICogKHNlbGYubWFwVyArIDIpO1xyXG4gICAgICAgIGxldCBwb3NZID0gMiArIHJvdyAqIChzZWxmLm1hcEggKyAyKTtcclxuICAgICAgICBzZWxmLm1hcC5maWxsUmVjdChwb3NYLCBwb3NZLCBzZWxmLm1hcFcsIHNlbGYubWFwSCk7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJEcmF3IE1hcC4uLlwiKTtcclxuICAgIH1cclxuXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiDojrflj5bnjqnlrrbmiYDlnKjnmoTmoLzlrZBcclxuICAgICAqIEBwYXJhbSBwb3MxIOeOqeWutuS6jOe7tOWdkOagh1xyXG4gICAgICogQHBhcmFtIHBvczIg6L+95a+76ICF5LqM57u05Z2Q5qCHXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBHZXRQbGF5ZXJHcmlkKHBvczE6IFZlYzIsIHBvczI6IFZlYzIpOiBBU3Rhck5vZGUge1xyXG5cclxuICAgICAgICBsZXQgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgLy/pgJrov4dwb3Pljrvmn6Xmib5HcmlkXHJcbiAgICAgICAgLy/pppblhYhHcmlk5LiN5LiA5a6a5LiO546p5a625Z2Q5qCH5a+55bqUXHJcbiAgICAgICAgLy/kvYbkuI7njqnlrrblkajlm7TnmoTmoLzlrZDnm7jpgrtcclxuICAgICAgICAvL+S8oOi/m+eahOWdkOagh+aYr1ZlYzLvvIzov5nmhI/lkbPnnYDnjqnlrrZWZWMz5Z2Q5qCH5YmU6ZmkWeWdkOagh1xyXG5cclxuICAgICAgICBjb25zb2xlLmxvZyhcIldoYXQgYWJvdXQgcG9zIGlzOlwiICsgcG9zMSk7XHJcblxyXG4gICAgICAgIC8v5Y+v5Lul6YeH55So56Kw5pKe5qOA5rWL77yM5L2G6YKj5aSq6ICX5oCn6IO9XHJcbiAgICAgICAgbGV0IG1pbkRpcyA9IDA7XHJcbiAgICAgICAgbGV0IGlzQ2FsRGlzRnJpc3QgPSB0cnVlO1xyXG5cclxuICAgICAgICBsZXQgdGFyZ2V0UG9zQXJyOiBBcnJheTxWZWMyPiA9IFtdO1xyXG4gICAgICAgIGxldCB0YXJnZXRQb3M6IFZlYzIgPSBWZWMyLlpFUk87XHJcblxyXG4gICAgICAgIC8v5Lul546p5a625Li65Lit5b+D77yM6I635Y+W5ZGo5Zu0OOS4queCueaIluiAhWFueVxyXG4gICAgICAgIGxldCBuZWFyR3JpZExzdCA9IHNlbGYuQ2V0R3JpZExzdEJ5UGxheWVyUG9zKHBvczEpO1xyXG4gICAgICAgIG5lYXJHcmlkTHN0LmZvckVhY2goZWxlbWVudCA9PiB7XHJcbiAgICAgICAgICAgIGxldCB0ZW1wR3JpZDogQVN0YXJOb2RlID0gZWxlbWVudCBhcyBBU3Rhck5vZGU7XHJcblxyXG4gICAgICAgICAgICAvL+iuoeeul+S4pOeCuei3neemu1xyXG4gICAgICAgICAgICBsZXQgdjI6IFZlYzIgPSBuZXcgVmVjMih0ZW1wR3JpZC54LCB0ZW1wR3JpZC55KTtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJXaGF0IGFib3V0IHYyIGlzOlwiICsgdjIudG9TdHJpbmcoKSlcclxuICAgICAgICAgICAgbGV0IGN1ckRpczogbnVtYmVyID0gc2VsZi5DYWxEaXN0YW5jZShwb3MxLCB2Mik7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiY3VyRGlzIGlzOlwiICsgY3VyRGlzKTtcclxuICAgICAgICAgICAgLy/lvqrnjq/mo4DmtYvojrflvpfmnIDnn63nmoTpgqPkuKrngrlcclxuICAgICAgICAgICAgaWYgKGlzQ2FsRGlzRnJpc3QgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgIGlmIChjdXJEaXMgPCBtaW5EaXMpIHtcclxuICAgICAgICAgICAgICAgICAgICBtaW5EaXMgPSBjdXJEaXM7XHJcbiAgICAgICAgICAgICAgICAgICAgLy/ot53nprvmnIDnn63nmoTngrnlj6/og73mnInlpJrkuKpcclxuICAgICAgICAgICAgICAgICAgICB0YXJnZXRQb3NBcnIucHVzaCh2Mik7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJwdXNoIGVsZW1lbnQgdG8gdGFyZ2V0UG9zQXJyLi4uXCIpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy/kvJrlh7rnjrDkuKTnp43mg4XlhrXvvJpcclxuICAgICAgICAgICAgICAgIC8vMS7lnKjmoLzlrZDph4xcclxuICAgICAgICAgICAgICAgIC8vMi7lnKjkuKTkuKrmoLzlrZDovrnnlYzkuK1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgICAgIC8v5LiA6Iis5p2l6K6y77yM5Lik54K55LiN6YeN5ZCI55qE6K+d77yM6Led56a75piv5aSn5LqO6Zu255qEXHJcbiAgICAgICAgICAgICAgICAvL+i/memHjOeUqOS6juesrOS4gOasoei1i+WAvG1pbkRpc1xyXG4gICAgICAgICAgICAgICAgbWluRGlzID0gY3VyRGlzO1xyXG4gICAgICAgICAgICAgICAgLy/nrKzkuIDmrKHotYvlgLzml7bvvIzkuZ/lupTor6VwdXNoXHJcbiAgICAgICAgICAgICAgICB0YXJnZXRQb3NBcnIucHVzaCh2Mik7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcInB1c2ggZWxlbWVudCB0byB0YXJnZXRQb3NBcnIgaW4gZnJpc3QuLi5cIilcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIC8v6Led56a75pyA55+t5Y+v6IO95pyJ5aSa5Liq54K577yM5oiR5Lus5Y+q5Y+W5LiO6L+95o2V6ICF6KeG57q/5LiA6Ie055qE54K5XHJcbiAgICAgICAgLy/ov5nkuKrmg7Pms5Xlj6/og73kuZ/mmK/plJnnmoRcclxuICAgICAgICAvL+WboOS4uuaciemYu+aMoeWMuuWfn1xyXG4gICAgICAgIGxldCBpc0NhbEFuZ2xlRnJpc3QgPSB0cnVlO1xyXG4gICAgICAgIGxldCBtaW5BbmdsZSA9IDA7XHJcbiAgICAgICAgLy/orqHnrpfop5LluqZcclxuICAgICAgICB0YXJnZXRQb3NBcnIuZm9yRWFjaChlbGVtZW50ID0+IHtcclxuICAgICAgICAgICAgbGV0IHRlbXBWZWMyOiBWZWMyID0gZWxlbWVudDtcclxuXHJcbiAgICAgICAgICAgIC8v5ou/5Yiw5pyA5bCP6KeS5bqmXHJcbiAgICAgICAgICAgIC8v5Lya5LiN5Lya5pyJ6Zeu6aKY77yf5q2j6LSf5byn5bqm5bqU6K+l5LiN5Lya5Ye6546wXHJcbiAgICAgICAgICAgIGxldCBjdXJBbmdsZSA9IHNlbGYuQ2FsQW5nbGUodGVtcFZlYzIsIHBvczIpO1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIndoYXQgYWJvdXQgY3VyQW5nbGUgaXM6XCIgKyBjdXJBbmdsZSk7XHJcbiAgICAgICAgICAgIGlmIChpc0NhbEFuZ2xlRnJpc3QgPT0gZmFsc2UpIHtcclxuICAgICAgICAgICAgICAgIGlmIChjdXJBbmdsZSA8IG1pbkFuZ2xlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbWluQW5nbGUgPSBjdXJBbmdsZTtcclxuICAgICAgICAgICAgICAgICAgICB0YXJnZXRQb3M9dGVtcFZlYzI7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJ3aGF0IGFib3V0IG1pbkFuZ2xlIGlzOlwiICsgbWluQW5nbGUpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgZWxzZSB7XHJcbiAgICAgICAgICAgICAgICBtaW5BbmdsZSA9IGN1ckFuZ2xlO1xyXG4gICAgICAgICAgICAgICAgdGFyZ2V0UG9zPXRlbXBWZWMyO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIC8v5pyA5ZCO5qC55o2u54K55ou/5Yiw5a+55bqU55qEQVN0YXJOb2RlXHJcbiAgICAgICAgbGV0IHRhcmdldFBsYXllck5vZGU6QVN0YXJOb2RlPSBzZWxmLm5vZGVzW3RhcmdldFBvcy54XVt0YXJnZXRQb3MueV07XHJcbiAgICAgICAgcmV0dXJuICB0YXJnZXRQbGF5ZXJOb2RlO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICogIOiuoeeul+S4pOeCueS5i+mXtOeahOinkuW6plxyXG4gICAgICogQHBhcmFtIHYxIFxyXG4gICAgICogQHBhcmFtIHYyIFxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIENhbEFuZ2xlKHYxOiBWZWMyLCB2MjogVmVjMik6IG51bWJlciB7XHJcbiAgICAgICAgcmV0dXJuIFZlYzIuYW5nbGUodjEsIHYyKTtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIOiOt+WPluS7peeOqeWutuS4uuS4reW/g++8jOWRqOWbtDjkuKrngrnmiJbkuInkuKrngrnmiJbkuKTkuKrngrnmiJbkuIDkuKrngrk/Pz8/XHJcbiAgICAgKiBAcGFyYW0gcDEg546p5a626IqC54K5XHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgQ2V0R3JpZExzdEJ5UGxheWVyUG9zKHAxOiBWZWMyKTogQXJyYXk8YW55PiB7XHJcblxyXG4gICAgICAgIGxldCBzZWxmID0gdGhpcztcclxuXHJcbiAgICAgICAgLy/pppblhYjliJLliIbmoLzlrZDlpKflsI/kuIDlrpropoHmnInluo/lubbkuJTpgILlvZPjgIHml6DlsI/mlbBcclxuICAgICAgICAvL+S+i+Wmgu+8mjEwKjEw55qE5Zyw5Zu+77yM6ZW/5bqm5Li6MTDlrr3luqbkuZ/kuLoxMO+8jO+8iDDvvIww77yJ77yIMO+8jDHvvInvvIgw77yMMu+8iS4uLlxyXG4gICAgICAgIC8v6L+Z5qC35YGa55qE5aW95aSE5bCx5piv6IO95L2/6Zeu6aKY566A5Y2V5YyWXHJcblxyXG4gICAgICAgIC8v5YW25qyh77yM546p5a625LiN5Y+v6IO96Lqr5aSE6Zi75oyh5Yy65Z+fXHJcblxyXG4gICAgICAgIC8v5a+5cDHnmoRYLFnliIbliKvlm5voiI3kupTlhaVcclxuICAgICAgICAvL+inhOaVtOWMllxyXG4gICAgICAgIGxldCB0YXJnZXJYID0gTWF0aC5yb3VuZChwMS54KTtcclxuICAgICAgICBsZXQgdGFyZ2VyWSA9IE1hdGgucm91bmQocDEueSk7XHJcblxyXG4gICAgICAgIGxldCBwb3M6IFZlYzIgPSBuZXcgVmVjMih0YXJnZXJYLCB0YXJnZXJZKTtcclxuICAgICAgICAvL+iOt+WPlueOqeWutuS4uuS4reW/gzjkuKrngrnmiJbkuIDkuKrngrlcclxuICAgICAgICBsZXQgdGFyZ2V0Tm9kZUxzdDogQXJyYXk8YW55PiA9IG5ldyBBcnJheTxhbnk+KCk7XHJcbiAgICAgICAgbGV0IHRlbXBHcmlkID0gbnVsbDtcclxuXHJcblxyXG4gICAgICAgIC8vI3JlZ2lvbiDlpoLmnpznjqnlrrbkvY3kuo7ovrnnlYxcclxuICAgICAgICAvL+WmguaenOeOqeWutuS9jeS6jui+ueeVjFxyXG4gICAgICAgIC8v5Y+q6ZyA5Y+W5LiA54K5XHJcbiAgICAgICAgLy/lj6/og73kvY3kuo7kuKTngrnkuYvpl7RcclxuICAgICAgICAvL+acgOe7iOaYr+WTquS4gOeCueWPluWGs+S6juWbm+iIjeS6lOWFpeeahOe7k+aenFxyXG4gICAgICAgIGlmIChzZWxmLklzQXRCb3VuZChwb3MpID09IHRydWUpIHtcclxuICAgICAgICAgICAgdGFyZ2V0Tm9kZUxzdC5wdXNoKHBvcyk7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiUG9zIGlzIGF0IGJvdW5kXCIpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIC8vI2VuZHJlZ2lvblxyXG5cclxuICAgICAgICAvLyNyZWdpb24gIOWmguaenOeOqeWutuS4jeS9jeS6jui+ueeVjFxyXG5cclxuICAgICAgICBlbHNlIHtcclxuICAgICAgICAgICAgLy/lt6bkuIogIHgtMSB5LTFcclxuICAgICAgICAgICAgdGVtcEdyaWQgPSBzZWxmLm5vZGVzW3RhcmdlclggLSAxXVt0YXJnZXJZIC0gMV07XHJcbiAgICAgICAgICAgIHRhcmdldE5vZGVMc3QucHVzaCh0ZW1wR3JpZCk7XHJcblxyXG4gICAgICAgICAgICAvL+S4iiB4ICB5LTFcclxuICAgICAgICAgICAgdGVtcEdyaWQgPSBzZWxmLm5vZGVzW3RhcmdlclhdW3RhcmdlclkgLSAxXTtcclxuICAgICAgICAgICAgdGFyZ2V0Tm9kZUxzdC5wdXNoKHRlbXBHcmlkKTtcclxuXHJcbiAgICAgICAgICAgIC8v5Y+z5LiKICB4KzEgeS0xXHJcbiAgICAgICAgICAgIHRlbXBHcmlkID0gc2VsZi5ub2Rlc1t0YXJnZXJYICsgMV1bdGFyZ2VyWSAtIDFdO1xyXG4gICAgICAgICAgICB0YXJnZXROb2RlTHN0LnB1c2godGVtcEdyaWQpO1xyXG5cclxuICAgICAgICAgICAgLy/lt6YgeC0xIHlcclxuICAgICAgICAgICAgdGVtcEdyaWQgPSBzZWxmLm5vZGVzW3RhcmdlclggLSAxXVt0YXJnZXJZXTtcclxuICAgICAgICAgICAgdGFyZ2V0Tm9kZUxzdC5wdXNoKHRlbXBHcmlkKTtcclxuXHJcbiAgICAgICAgICAgIC8v5Y+zIHgrMSB5XHJcbiAgICAgICAgICAgIHRlbXBHcmlkID0gc2VsZi5ub2Rlc1t0YXJnZXJYICsgMV1bdGFyZ2VyWV07XHJcbiAgICAgICAgICAgIHRhcmdldE5vZGVMc3QucHVzaCh0ZW1wR3JpZCk7XHJcblxyXG4gICAgICAgICAgICAvL+W3puS4iyB4LTEgeSsxXHJcbiAgICAgICAgICAgIHRlbXBHcmlkID0gc2VsZi5ub2Rlc1t0YXJnZXJYIC0gMV1bdGFyZ2VyWSArIDFdO1xyXG4gICAgICAgICAgICB0YXJnZXROb2RlTHN0LnB1c2godGVtcEdyaWQpO1xyXG5cclxuICAgICAgICAgICAgLy/kuIsgeCB5KzFcclxuICAgICAgICAgICAgdGVtcEdyaWQgPSBzZWxmLm5vZGVzW3RhcmdlclhdW3RhcmdlclkgKyAxXTtcclxuICAgICAgICAgICAgdGFyZ2V0Tm9kZUxzdC5wdXNoKHRlbXBHcmlkKTtcclxuXHJcbiAgICAgICAgICAgIC8v5Y+z5LiLIHgrMSB5KzFcclxuICAgICAgICAgICAgdGVtcEdyaWQgPSBzZWxmLm5vZGVzW3RhcmdlclggKyAxXVt0YXJnZXJZICsgMV07XHJcbiAgICAgICAgICAgIHRhcmdldE5vZGVMc3QucHVzaCh0ZW1wR3JpZCk7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiR2V0R3JpZExzdEJ5UGxheWVyUG9zIHJldHVybiBsc3Q6XCIgKyB0YXJnZXROb2RlTHN0WzBdKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmV0dXJuIHRhcmdldE5vZGVMc3Q7XHJcbiAgICAgICAgLy8jZW5kcmVnaW9uXHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiDmmK/lkKblnKjovrnnlYwv5piv5ZCm5o6l6L+R6L6555WMXHJcbiAgICAgKiBAcGFyYW0gcG9zIOS8oOWFpeinhOaVtOWMlueahOWdkOagh1xyXG4gICAgICovXHJcbiAgICBwcml2YXRlIElzQXRCb3VuZChwb3M6IFZlYzIpOiBib29sZWFuIHtcclxuICAgICAgICBsZXQgaXNBdEJvdW5kOiBib29sZWFuID0gZmFsc2U7XHJcbiAgICAgICAgLy/ovrnnlYzliKTmlq1cclxuICAgICAgICBpZiAocG9zLnggPCAwIHx8IHBvcy55ID49IHNlbGYubWFwVyB8fFxyXG4gICAgICAgICAgICBwb3MueCA8IDAgfHwgcG9zLnkgPj0gc2VsZi5tYXBIKVxyXG4gICAgICAgICAgICBpc0F0Qm91bmQgPSB0cnVlO1xyXG4gICAgICAgIHJldHVybiBpc0F0Qm91bmQ7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICog6K6h566X5Lik54K55LmL6Ze055qE6Led56a7XHJcbiAgICAgKiBAcGFyYW0gdjEg6LW354K5ICjnjqnlrrbkuoznu7TlnZDmoIcpXHJcbiAgICAgKiBAcGFyYW0gdjIg57uI54K5IChub2Rlc+mHjOeahOeCuSlcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBDYWxEaXN0YW5jZSh2MTogVmVjMiwgdjI6IFZlYzIpOiBudW1iZXIge1xyXG4gICAgICAgIGxldCBkaXNWYWwgPSBWZWMyLmRpc3RhbmNlKHYxLCB2Mik7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJDYWxEaXN0YW5jZSdzIHZhbHVlIGlzOlwiICsgZGlzVmFsKTtcclxuICAgICAgICByZXR1cm4gZGlzVmFsO1xyXG4gICAgfVxyXG59XHJcbiJdfQ==