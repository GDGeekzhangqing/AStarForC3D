System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, _dec, _class, _crd, ccclass, property, MapCfgData;

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  _export({
    _dec: void 0,
    _class: void 0
  });

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
    }],
    execute: function () {
      _cclegacy._RF.push({}, "7b5e9OvfA5OkoSIKru9VWR1", "MapCfgData", _context.meta);

      _crd = true;
      ccclass = _decorator.ccclass;
      property = _decorator.property;
      /**
       * 地图数据类，但是地图大小不在json指定
       */

      _export("MapCfgData", MapCfgData = (_dec = ccclass('MapCfgData'), _dec(_class = function MapCfgData(id, mapx, mapy, type) {
        _classCallCheck(this, MapCfgData);

        this.id = id;
        this.mapX = mapx;
        this.mapY = mapy;
        this.type = type;
      }) || _class));

      _crd = false;

      _cclegacy._RF.pop();
    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vRDovQ29Db3MzRExzdC9NeUFTdGFydC9hc3NldHMvc2NpcHRzL015L01hcENmZ0RhdGEudHMiXSwibmFtZXMiOlsiX2RlY29yYXRvciIsImNjY2xhc3MiLCJwcm9wZXJ0eSIsIk1hcENmZ0RhdGEiLCJpZCIsIm1hcHgiLCJtYXB5IiwidHlwZSIsIm1hcFgiLCJtYXBZIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7QUFBU0EsTUFBQUEsVSxPQUFBQSxVOzs7Ozs7QUFFREMsTUFBQUEsTyxHQUFzQkQsVSxDQUF0QkMsTztBQUFTQyxNQUFBQSxRLEdBQWFGLFUsQ0FBYkUsUTtBQUlqQjs7Ozs0QkFJYUMsVSxXQURaRixPQUFPLENBQUMsWUFBRCxDLGdCQVdKLG9CQUFZRyxFQUFaLEVBQXNCQyxJQUF0QixFQUFrQ0MsSUFBbEMsRUFBOENDLElBQTlDLEVBQStEO0FBQUE7O0FBQzFELGFBQUtILEVBQUwsR0FBUUEsRUFBUjtBQUNBLGFBQUtJLElBQUwsR0FBVUgsSUFBVjtBQUNBLGFBQUtJLElBQUwsR0FBVUgsSUFBVjtBQUNBLGFBQUtDLElBQUwsR0FBVUEsSUFBVjtBQUNKLE8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBfZGVjb3JhdG9yLCBDb21wb25lbnQsIE5vZGUgfSBmcm9tICdjYyc7XHJcbmltcG9ydCB7IEVfTm9kZV9UeXBlIH0gZnJvbSAnLi9BU3Rhck5vZGUnO1xyXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBfZGVjb3JhdG9yO1xyXG5cclxuXHJcblxyXG4vKipcclxuICog5Zyw5Zu+5pWw5o2u57G777yM5L2G5piv5Zyw5Zu+5aSn5bCP5LiN5ZyoanNvbuaMh+WumlxyXG4gKi9cclxuQGNjY2xhc3MoJ01hcENmZ0RhdGEnKVxyXG5leHBvcnQgY2xhc3MgTWFwQ2ZnRGF0YSAge1xyXG4gICAgXHJcbiAgICBwdWJsaWMgaWQ6bnVtYmVyO1xyXG5cclxuICAgIHB1YmxpYyAgbWFwWDpudW1iZXI7XHJcblxyXG4gICAgcHVibGljIG1hcFk6bnVtYmVyO1xyXG5cclxuICAgIHB1YmxpYyB0eXBlOkVfTm9kZV9UeXBlO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKGlkOm51bWJlcixtYXB4Om51bWJlcixtYXB5Om51bWJlcix0eXBlOkVfTm9kZV9UeXBlKXtcclxuICAgICAgICAgdGhpcy5pZD1pZDtcclxuICAgICAgICAgdGhpcy5tYXBYPW1hcHg7XHJcbiAgICAgICAgIHRoaXMubWFwWT1tYXB5O1xyXG4gICAgICAgICB0aGlzLnR5cGU9dHlwZTtcclxuICAgIH1cclxuXHJcbn1cclxuIl19