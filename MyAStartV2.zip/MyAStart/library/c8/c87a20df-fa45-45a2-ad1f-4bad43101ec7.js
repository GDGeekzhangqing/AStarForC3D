System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, _dec, _class, _temp, _crd, ccclass, property, TwoDArray;

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  _export({
    _dec: void 0,
    _class: void 0,
    _temp: void 0
  });

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
    }],
    execute: function () {
      _cclegacy._RF.push({}, "c87a2Df+kVFoq0fS61DEB7H", "TwoDArray", _context.meta);

      _crd = true;
      ccclass = _decorator.ccclass;
      property = _decorator.property;

      _export("TwoDArray", TwoDArray = (_dec = ccclass('TwoDArray'), _dec(_class = (_temp = /*#__PURE__*/function () {
        function TwoDArray(rows, columns, val) {
          _classCallCheck(this, TwoDArray);

          this.obj = new Array();
          this.rows = rows;
          this.columns = columns;
        }
        /**
         * 取数组中的值
         * @param rows 
         * @param columns 
         */


        _createClass(TwoDArray, [{
          key: "GetValue",
          value: function GetValue(rows, columns) {
            if (rows < 0 || columns < 0 || rows >= this.rows || columns >= this.columns) {
              return null;
            }

            return this.obj[rows][columns];
          }
          /**
           * 为数组赋值
           * @param rows 
           * @param columns 
           * @param val 
           */

        }, {
          key: "SetValue",
          value: function SetValue(rows, columns, val) {
            if (rows < 0 || columns < 0 || rows >= this.rows || columns >= this.columns) {
              return;
            }

            this.obj[rows][columns] = val;
          }
          /**
           * 初始化行数
           * @param rows 
           */

        }, {
          key: "InitRows",
          value: function InitRows(rows) {
            if (rows < 1) {
              return;
            }

            for (var i = 0; i < rows; i++) {
              this.obj.push(new Array());
            }
          }
          /**
           * 初始化列数
           * @param columns 
           * @param value 
           */

        }, {
          key: "InitColumns",
          value: function InitColumns(columns, value) {
            if (columns < 1) {
              return;
            }

            for (var i = 0; i < this.obj.length; i++) {
              for (var j = 0; j < columns; j++) {
                this.obj[i].push(value);
              }
            }
          }
          /**
           * 获得数组
           */

        }, {
          key: "GetArray",
          value: function GetArray() {
            return this.obj;
          }
        }]);

        return TwoDArray;
      }(), _temp)) || _class));

      _crd = false;

      _cclegacy._RF.pop();
    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vRDovQ29Db3MzRExzdC9NeUFTdGFydC9hc3NldHMvc2NpcHRzL015L1R3b0RBcnJheS50cyJdLCJuYW1lcyI6WyJfZGVjb3JhdG9yIiwiY2NjbGFzcyIsInByb3BlcnR5IiwiVHdvREFycmF5Iiwicm93cyIsImNvbHVtbnMiLCJ2YWwiLCJvYmoiLCJBcnJheSIsImkiLCJwdXNoIiwidmFsdWUiLCJsZW5ndGgiLCJqIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFTQSxNQUFBQSxVLE9BQUFBLFU7Ozs7OztBQUNEQyxNQUFBQSxPLEdBQXNCRCxVLENBQXRCQyxPO0FBQVNDLE1BQUFBLFEsR0FBYUYsVSxDQUFiRSxROzsyQkFHSkMsUyxXQURaRixPQUFPLENBQUMsV0FBRCxDO0FBT0osMkJBQVlHLElBQVosRUFBMEJDLE9BQTFCLEVBQTJDQyxHQUEzQyxFQUF3RDtBQUFBOztBQUFBLGVBTGhEQyxHQUtnRCxHQUxwQixJQUFJQyxLQUFKLEVBS29CO0FBQ3BELGVBQUtKLElBQUwsR0FBWUEsSUFBWjtBQUNBLGVBQUtDLE9BQUwsR0FBZUEsT0FBZjtBQUNIO0FBRUQ7Ozs7Ozs7OzttQ0FLZ0JELEksRUFBY0MsTyxFQUF5QjtBQUNuRCxnQkFBSUQsSUFBSSxHQUFHLENBQVAsSUFBWUMsT0FBTyxHQUFHLENBQXRCLElBQTJCRCxJQUFJLElBQUksS0FBS0EsSUFBeEMsSUFBZ0RDLE9BQU8sSUFBSSxLQUFLQSxPQUFwRSxFQUE2RTtBQUN6RSxxQkFBTyxJQUFQO0FBQ0g7O0FBRUQsbUJBQU8sS0FBS0UsR0FBTCxDQUFTSCxJQUFULEVBQWVDLE9BQWYsQ0FBUDtBQUNIO0FBRUQ7Ozs7Ozs7OzttQ0FNZ0JELEksRUFBY0MsTyxFQUFpQkMsRyxFQUFtQjtBQUM5RCxnQkFBSUYsSUFBSSxHQUFHLENBQVAsSUFBWUMsT0FBTyxHQUFHLENBQXRCLElBQTJCRCxJQUFJLElBQUksS0FBS0EsSUFBeEMsSUFBZ0RDLE9BQU8sSUFBSSxLQUFLQSxPQUFwRSxFQUE2RTtBQUN6RTtBQUNIOztBQUVELGlCQUFLRSxHQUFMLENBQVNILElBQVQsRUFBZUMsT0FBZixJQUEwQkMsR0FBMUI7QUFDSDtBQUVEOzs7Ozs7O21DQUlpQkYsSSxFQUFvQjtBQUNqQyxnQkFBSUEsSUFBSSxHQUFHLENBQVgsRUFBYztBQUNWO0FBQ0g7O0FBRUQsaUJBQUssSUFBSUssQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR0wsSUFBcEIsRUFBMEJLLENBQUMsRUFBM0IsRUFBK0I7QUFDM0IsbUJBQUtGLEdBQUwsQ0FBU0csSUFBVCxDQUFjLElBQUlGLEtBQUosRUFBZDtBQUNIO0FBQ0o7QUFFRDs7Ozs7Ozs7c0NBS29CSCxPLEVBQWlCTSxLLEVBQXFCO0FBQ3RELGdCQUFJTixPQUFPLEdBQUcsQ0FBZCxFQUFpQjtBQUNiO0FBQ0g7O0FBRUQsaUJBQUssSUFBSUksQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBRyxLQUFLRixHQUFMLENBQVNLLE1BQTdCLEVBQXFDSCxDQUFDLEVBQXRDLEVBQTBDO0FBQ3RDLG1CQUFLLElBQUlJLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdSLE9BQXBCLEVBQTZCUSxDQUFDLEVBQTlCLEVBQWtDO0FBQzlCLHFCQUFLTixHQUFMLENBQVNFLENBQVQsRUFBWUMsSUFBWixDQUFpQkMsS0FBakI7QUFDSDtBQUNKO0FBQ0o7QUFFRDs7Ozs7O3FDQUd3QztBQUNwQyxtQkFBTyxLQUFLSixHQUFaO0FBQ0giLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBfZGVjb3JhdG9yLCBDb21wb25lbnQsIE5vZGUgfSBmcm9tICdjYyc7XHJcbmNvbnN0IHsgY2NjbGFzcywgcHJvcGVydHkgfSA9IF9kZWNvcmF0b3I7XHJcblxyXG5AY2NjbGFzcygnVHdvREFycmF5JylcclxuZXhwb3J0IGNsYXNzIFR3b0RBcnJheSB7XHJcbiAgICBwcml2YXRlIG9iajogQXJyYXk8QXJyYXk8bnVtYmVyPj4gPSBuZXcgQXJyYXk8QXJyYXk8bnVtYmVyPj4oKTtcclxuXHJcbiAgICBwcml2YXRlIHJvd3M6IG51bWJlcjtcclxuICAgIHByaXZhdGUgY29sdW1uczogbnVtYmVyO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKHJvd3M6IG51bWJlciwgY29sdW1uczogbnVtYmVyLCB2YWw6IG51bWJlcikge1xyXG4gICAgICAgIHRoaXMucm93cyA9IHJvd3M7XHJcbiAgICAgICAgdGhpcy5jb2x1bW5zID0gY29sdW1ucztcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIOWPluaVsOe7hOS4reeahOWAvFxyXG4gICAgICogQHBhcmFtIHJvd3MgXHJcbiAgICAgKiBAcGFyYW0gY29sdW1ucyBcclxuICAgICAqL1xyXG4gICAgcHVibGljIEdldFZhbHVlKHJvd3M6IG51bWJlciwgY29sdW1uczogbnVtYmVyKTogbnVtYmVyIHtcclxuICAgICAgICBpZiAocm93cyA8IDAgfHwgY29sdW1ucyA8IDAgfHwgcm93cyA+PSB0aGlzLnJvd3MgfHwgY29sdW1ucyA+PSB0aGlzLmNvbHVtbnMpIHtcclxuICAgICAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gdGhpcy5vYmpbcm93c11bY29sdW1uc107XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiDkuLrmlbDnu4TotYvlgLxcclxuICAgICAqIEBwYXJhbSByb3dzIFxyXG4gICAgICogQHBhcmFtIGNvbHVtbnMgXHJcbiAgICAgKiBAcGFyYW0gdmFsIFxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgU2V0VmFsdWUocm93czogbnVtYmVyLCBjb2x1bW5zOiBudW1iZXIsIHZhbDogbnVtYmVyKTogdm9pZCB7XHJcbiAgICAgICAgaWYgKHJvd3MgPCAwIHx8IGNvbHVtbnMgPCAwIHx8IHJvd3MgPj0gdGhpcy5yb3dzIHx8IGNvbHVtbnMgPj0gdGhpcy5jb2x1bW5zKSB7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHRoaXMub2JqW3Jvd3NdW2NvbHVtbnNdID0gdmFsO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICog5Yid5aeL5YyW6KGM5pWwXHJcbiAgICAgKiBAcGFyYW0gcm93cyBcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBJbml0Um93cyhyb3dzOiBudW1iZXIpOiB2b2lkIHtcclxuICAgICAgICBpZiAocm93cyA8IDEpIHtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCByb3dzOyBpKyspIHtcclxuICAgICAgICAgICAgdGhpcy5vYmoucHVzaChuZXcgQXJyYXk8bnVtYmVyPigpKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiDliJ3lp4vljJbliJfmlbBcclxuICAgICAqIEBwYXJhbSBjb2x1bW5zIFxyXG4gICAgICogQHBhcmFtIHZhbHVlIFxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIEluaXRDb2x1bW5zKGNvbHVtbnM6IG51bWJlciwgdmFsdWU6IG51bWJlcik6IHZvaWQge1xyXG4gICAgICAgIGlmIChjb2x1bW5zIDwgMSkge1xyXG4gICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMub2JqLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgY29sdW1uczsgaisrKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLm9ialtpXS5wdXNoKHZhbHVlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIOiOt+W+l+aVsOe7hFxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgR2V0QXJyYXkoKTogQXJyYXk8QXJyYXk8bnVtYmVyPj4ge1xyXG4gICAgICAgIHJldHVybiB0aGlzLm9iajtcclxuICAgIH1cclxuXHJcblxyXG59XHJcbiJdfQ==