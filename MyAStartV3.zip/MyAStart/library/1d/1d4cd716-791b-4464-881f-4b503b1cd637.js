System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, _dec, _class, _crd, ccclass, property, E_Node_Type, NodeDir, AStarNode;

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  _export({
    _dec: void 0,
    _class: void 0,
    E_Node_Type: void 0,
    NodeDir: void 0
  });

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
    }],
    execute: function () {
      _cclegacy._RF.push({}, "1d4cdcWeRtEZIgfS1A7HNY3", "AStarNode", _context.meta);

      _crd = true;
      ccclass = _decorator.ccclass;
      property = _decorator.property; /// <summary>
      /// 格子的类型
      /// </summary>

      (function (E_Node_Type) {
        E_Node_Type[E_Node_Type["Walk"] = 0] = "Walk";
        E_Node_Type[E_Node_Type["Stop"] = 1] = "Stop";
        E_Node_Type[E_Node_Type["Start"] = 2] = "Start";
        E_Node_Type[E_Node_Type["End"] = 3] = "End";
      })(E_Node_Type || _export("E_Node_Type", E_Node_Type = {}));

      (function (NodeDir) {
        NodeDir[NodeDir["None"] = 0] = "None";
        NodeDir[NodeDir["LeftToTop"] = 1] = "LeftToTop";
        NodeDir[NodeDir["RightToTop"] = 2] = "RightToTop";
        NodeDir[NodeDir["LeftToDown"] = 3] = "LeftToDown";
        NodeDir[NodeDir["RightToDown"] = 4] = "RightToDown";
      })(NodeDir || _export("NodeDir", NodeDir = {}));

      _export("AStarNode", AStarNode = (_dec = ccclass('AStarNode'), _dec(_class =
      /**
       * 格子对象的X坐标
       */

      /**
       * 格子对象的Y坐标
       */

      /**
       * 寻路消耗
       */

      /**
       * 离起点的距离
       */

      /**
       * 离终点的距离
       */

      /**
       * 父节点
       */

      /**
       * 格子的类型
       */

      /**
       * 格子类构造函数，传入坐标和格子类型
       * @param x 
       * @param y 
       * @param type 
       */
      function AStarNode(x, y, type) {
        _classCallCheck(this, AStarNode);

        this.x = x;
        this.y = y;
        this.type = type;
      }) || _class));

      _crd = false;

      _cclegacy._RF.pop();
    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vRDovQ29Db3MzRExzdC9NeUFTdGFydC9hc3NldHMvc2NpcHRzL015L0FTdGFyTm9kZS50cyJdLCJuYW1lcyI6WyJfZGVjb3JhdG9yIiwiY2NjbGFzcyIsInByb3BlcnR5IiwiRV9Ob2RlX1R5cGUiLCJOb2RlRGlyIiwiQVN0YXJOb2RlIiwieCIsInkiLCJ0eXBlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFTQSxNQUFBQSxVLE9BQUFBLFU7Ozs7OztBQUNEQyxNQUFBQSxPLEdBQXNCRCxVLENBQXRCQyxPO0FBQVNDLE1BQUFBLFEsR0FBYUYsVSxDQUFiRSxRLEVBRWpCO0FBQ0E7QUFDQTs7aUJBQ1lDLFc7QUFBQUEsUUFBQUEsVyxDQUFBQSxXO0FBQUFBLFFBQUFBLFcsQ0FBQUEsVztBQUFBQSxRQUFBQSxXLENBQUFBLFc7QUFBQUEsUUFBQUEsVyxDQUFBQSxXO1NBQUFBLFcsMkJBQUFBLFc7O2lCQTRCQUMsTztBQUFBQSxRQUFBQSxPLENBQUFBLE87QUFBQUEsUUFBQUEsTyxDQUFBQSxPO0FBQUFBLFFBQUFBLE8sQ0FBQUEsTztBQUFBQSxRQUFBQSxPLENBQUFBLE87QUFBQUEsUUFBQUEsTyxDQUFBQSxPO1NBQUFBLE8sdUJBQUFBLE87OzJCQXdCQ0MsUyxXQURaSixPQUFPLENBQUMsV0FBRCxDO0FBSVA7Ozs7QUFLQTs7OztBQUtBOzs7O0FBS0E7Ozs7QUFLQTs7OztBQUtBOzs7O0FBS0E7Ozs7QUFLQTs7Ozs7O0FBTUEseUJBQVlLLENBQVosRUFBZUMsQ0FBZixFQUFrQkMsSUFBbEIsRUFBd0I7QUFBQTs7QUFDdkIsYUFBS0YsQ0FBTCxHQUFTQSxDQUFUO0FBQ0EsYUFBS0MsQ0FBTCxHQUFTQSxDQUFUO0FBQ0EsYUFBS0MsSUFBTCxHQUFZQSxJQUFaO0FBQ0EsTyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IF9kZWNvcmF0b3IsIENvbXBvbmVudCwgTm9kZSB9IGZyb20gJ2NjJztcclxuY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gX2RlY29yYXRvcjtcclxuXHJcbi8vLyA8c3VtbWFyeT5cclxuLy8vIOagvOWtkOeahOexu+Wei1xyXG4vLy8gPC9zdW1tYXJ5PlxyXG5leHBvcnQgZW51bSBFX05vZGVfVHlwZSB7XHJcblx0LyoqXHJcblx0ICog5Y+v5Lul6LWw55qE5Zyw5pa5XHJcblx0ICovXHJcblx0V2FsayxcclxuXHJcblx0LyoqXHJcblx0ICog5LiN6IO96LWw55qE6Zi75oyhXHJcblx0ICovXHJcblx0U3RvcCxcclxuXHJcblx0LyoqXHJcblx0ICog5byA5aeLXHJcblx0ICovXHJcblx0U3RhcnQsXHJcblxyXG5cdC8qKlxyXG5cdCAqIOe7k+adn1xyXG5cdCAqL1xyXG5cdEVuZFxyXG59XHJcblxyXG4vKipcclxuICrotbfngrnkuI7nu4jngrnmlrnkvY3liKTlrppcclxuICpcclxuICogQGV4cG9ydFxyXG4gKiBAZW51bSB7bnVtYmVyfVxyXG4gKi9cclxuZXhwb3J0IGVudW0gTm9kZURpciB7XHJcblx0LyoqXHJcblx0ICog5pegXHJcblx0ICovXHJcblx0Tm9uZSxcclxuXHQvKipcclxuXHQgKuW3puS4ilxyXG5cdCAqL1xyXG5cdExlZnRUb1RvcCxcclxuXHQvKipcclxuXHQgKuWPs+S4ilxyXG5cdCAqL1xyXG5cdFJpZ2h0VG9Ub3AsXHJcblx0LyoqXHJcblx0ICog5bem5LiLXHJcblx0ICovXHJcblx0TGVmdFRvRG93bixcclxuXHQvKipcclxuXHQgKuWPs+S4i1xyXG5cdCAqL1xyXG5cdFJpZ2h0VG9Eb3duXHJcbn1cclxuXHJcbkBjY2NsYXNzKCdBU3Rhck5vZGUnKVxyXG5leHBvcnQgY2xhc3MgQVN0YXJOb2RlIHtcclxuXHJcblxyXG5cdC8qKlxyXG5cdCAqIOagvOWtkOWvueixoeeahFjlnZDmoIdcclxuXHQgKi9cclxuXHRwdWJsaWMgeDogbnVtYmVyO1xyXG5cclxuXHQvKipcclxuXHQgKiDmoLzlrZDlr7nosaHnmoRZ5Z2Q5qCHXHJcblx0ICovXHJcblx0cHVibGljIHk6IG51bWJlcjtcclxuXHJcblx0LyoqXHJcblx0ICog5a+76Lev5raI6ICXXHJcblx0ICovXHJcblx0cHVibGljIGY7XHJcblxyXG5cdC8qKlxyXG5cdCAqIOemu+i1t+eCueeahOi3neemu1xyXG5cdCAqL1xyXG5cdHB1YmxpYyBnO1xyXG5cclxuXHQvKipcclxuXHQgKiDnprvnu4jngrnnmoTot53nprtcclxuXHQgKi9cclxuXHRwdWJsaWMgaDtcclxuXHJcblx0LyoqXHJcblx0ICog54i26IqC54K5XHJcblx0ICovXHJcblx0cHVibGljIGZhdGhlcjogQVN0YXJOb2RlO1xyXG5cclxuXHQvKipcclxuXHQgKiDmoLzlrZDnmoTnsbvlnotcclxuXHQgKi9cclxuXHRwdWJsaWMgdHlwZTogRV9Ob2RlX1R5cGU7XHJcblxyXG5cdC8qKlxyXG5cdCAqIOagvOWtkOexu+aehOmAoOWHveaVsO+8jOS8oOWFpeWdkOagh+WSjOagvOWtkOexu+Wei1xyXG5cdCAqIEBwYXJhbSB4IFxyXG5cdCAqIEBwYXJhbSB5IFxyXG5cdCAqIEBwYXJhbSB0eXBlIFxyXG5cdCAqL1xyXG5cdGNvbnN0cnVjdG9yKHgsIHksIHR5cGUpIHtcclxuXHRcdHRoaXMueCA9IHg7XHJcblx0XHR0aGlzLnkgPSB5O1xyXG5cdFx0dGhpcy50eXBlID0gdHlwZTtcclxuXHR9XHJcblxyXG59XHJcbiJdfQ==