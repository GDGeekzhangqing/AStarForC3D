System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, _crd, ccclass, property, GridType, Grid;

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  _export("GridType", void 0);

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
    }],
    execute: function () {
      _cclegacy._RF.push({}, "230736FxDhDb7RnU+Ga8+Wz", "Grid", _context.meta);

      _crd = true;
      ccclass = _decorator.ccclass;
      property = _decorator.property;

      (function (GridType) {
        GridType[GridType["Barrier"] = 0] = "Barrier";
        GridType[GridType["Normal"] = 1] = "Normal";
        GridType[GridType["Start"] = 2] = "Start";
        GridType[GridType["End"] = 3] = "End";
      })(GridType || _export("GridType", GridType = {}));

      /**
       * 格子类
       */
      _export("Grid", Grid =
      /**
       *构造器
       */
      function Grid() {
        _classCallCheck(this, Grid);

        this.x = 0;
        this.y = 0;
        this.f = 0;
        this.g = 0;
        this.h = 0;
        this.parent = null;
        this.type = GridType.Normal;
      });

      _crd = false;

      _cclegacy._RF.pop();
    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vRDovQ29Db3MzRExzdC9NeUFTdGFydC9hc3NldHMvc2NpcHRzL0dyaWQudHMiXSwibmFtZXMiOlsiX2RlY29yYXRvciIsImNjY2xhc3MiLCJwcm9wZXJ0eSIsIkdyaWRUeXBlIiwiR3JpZCIsIngiLCJ5IiwiZiIsImciLCJoIiwicGFyZW50IiwidHlwZSIsIk5vcm1hbCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBQVNBLE1BQUFBLFUsT0FBQUEsVTs7Ozs7O0FBQ0RDLE1BQUFBLE8sR0FBc0JELFUsQ0FBdEJDLE87QUFBU0MsTUFBQUEsUSxHQUFhRixVLENBQWJFLFE7O2lCQUVMQyxRO0FBQUFBLFFBQUFBLFEsQ0FBQUEsUTtBQUFBQSxRQUFBQSxRLENBQUFBLFE7QUFBQUEsUUFBQUEsUSxDQUFBQSxRO0FBQUFBLFFBQUFBLFEsQ0FBQUEsUTtTQUFBQSxRLHdCQUFBQSxROztBQXdCWjs7O3NCQUdjQyxJO0FBV1Y7OztBQUdBLHNCQUFjO0FBQUE7O0FBRVYsYUFBS0MsQ0FBTCxHQUFPLENBQVA7QUFDQSxhQUFLQyxDQUFMLEdBQU8sQ0FBUDtBQUNBLGFBQUtDLENBQUwsR0FBTyxDQUFQO0FBQ0EsYUFBS0MsQ0FBTCxHQUFPLENBQVA7QUFDQSxhQUFLQyxDQUFMLEdBQU8sQ0FBUDtBQUNBLGFBQUtDLE1BQUwsR0FBWSxJQUFaO0FBQ0EsYUFBS0MsSUFBTCxHQUFVUixRQUFRLENBQUNTLE1BQW5CO0FBQ0gsTyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IF9kZWNvcmF0b3IsIENvbXBvbmVudCwgTm9kZSB9IGZyb20gJ2NjJztcclxuY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gX2RlY29yYXRvcjtcclxuXHJcbmV4cG9ydCBlbnVtIEdyaWRUeXBle1xyXG4gICAgXHJcbiAgICAvKipcclxuICAgICAqIOmanOeijeeJqVxyXG4gICAgICovXHJcbiAgICBCYXJyaWVyLFxyXG5cclxuICAgIC8qKlxyXG4gICAgICog5q2j5bi4XHJcbiAgICAgKi9cclxuICAgIE5vcm1hbCxcclxuXHJcbiAgICAvKipcclxuICAgICAqIOi1t+eCuVxyXG4gICAgICovXHJcbiAgICBTdGFydCxcclxuXHJcbiAgICAvKipcclxuICAgICAqIOe7iOeCuVxyXG4gICAgICovXHJcbiAgICBFbmRcclxufVxyXG5cclxuXHJcbi8qKlxyXG4gKiDmoLzlrZDnsbtcclxuICovXHJcbmV4cG9ydCAgY2xhc3MgR3JpZCAge1xyXG5cclxuICAgIHB1YmxpYyAgeDpudW1iZXI7XHJcbiAgICBwdWJsaWMgIHk6bnVtYmVyO1xyXG4gICAgcHVibGljICBmOm51bWJlcjtcclxuICAgIHB1YmxpYyAgZzpudW1iZXI7XHJcbiAgICBwdWJsaWMgIGg6bnVtYmVyO1xyXG5cclxuICAgIHB1YmxpYyBwYXJlbnQ6R3JpZDtcclxuICAgIHB1YmxpYyB0eXBlOkdyaWRUeXBlO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICrmnoTpgKDlmahcclxuICAgICAqL1xyXG4gICAgY29uc3RydWN0b3IoKSB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhpcy54PTA7XHJcbiAgICAgICAgdGhpcy55PTA7XHJcbiAgICAgICAgdGhpcy5mPTA7XHJcbiAgICAgICAgdGhpcy5nPTA7XHJcbiAgICAgICAgdGhpcy5oPTA7XHJcbiAgICAgICAgdGhpcy5wYXJlbnQ9bnVsbDtcclxuICAgICAgICB0aGlzLnR5cGU9R3JpZFR5cGUuTm9ybWFsO1xyXG4gICAgfVxyXG5cclxuICAgXHJcbn1cclxuIl19