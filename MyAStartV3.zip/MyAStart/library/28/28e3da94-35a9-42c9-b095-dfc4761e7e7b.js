System.register(["cc", "code-quality:cr", "./MapCfgData.js"], function (_export, _context) {
  "use strict";

  var _cclegacy, _reporterNs, _decorator, Component, Node, loader, ModelComponent, GFXPrimitiveMode, utils, GFXAttributeName, GFXFormat, Material, JsonAsset, MapCfgData, _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _temp, _crd, ccclass, property, MapMgr;

  function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

  function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

  function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

  function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfMapCfgData(extras) {
    _reporterNs.report("MapCfgData", "./MapCfgData", _context.meta, extras);
  }

  _export({
    _dec: void 0,
    _dec2: void 0,
    _dec3: void 0,
    _class: void 0,
    _class2: void 0,
    _descriptor: void 0,
    _descriptor2: void 0,
    _temp: void 0
  });

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      loader = _cc.loader;
      ModelComponent = _cc.ModelComponent;
      GFXPrimitiveMode = _cc.GFXPrimitiveMode;
      utils = _cc.utils;
      GFXAttributeName = _cc.GFXAttributeName;
      GFXFormat = _cc.GFXFormat;
      Material = _cc.Material;
      JsonAsset = _cc.JsonAsset;
    }, function (_codeQualityCr) {
      _reporterNs = _codeQualityCr;
    }, function (_MapCfgDataJs) {
      MapCfgData = _MapCfgDataJs.MapCfgData;
    }],
    execute: function () {
      _cclegacy._RF.push({}, "28e3dqUNalCybCV38R2Hn57", "MapMgr", _context.meta);

      _crd = true;
      ccclass = _decorator.ccclass;
      property = _decorator.property;

      _export("MapMgr", MapMgr = (_dec = ccclass('MapMgr'), _dec2 = property({
        type: Node
      }), _dec3 = property({
        type: Material
      }), _dec(_class = (_class2 = (_temp = /*#__PURE__*/function (_Component) {
        _inherits(MapMgr, _Component);

        /**
         * 地图配置表路径
         */
        function MapMgr() {
          var _this;

          _classCallCheck(this, MapMgr);

          _this = _possibleConstructorReturn(this, _getPrototypeOf(MapMgr).call(this));

          _initializerDefineProperty(_this, "targerNode", _descriptor, _assertThisInitialized(_this));

          _this.gridW = 6;
          _this.gridH = 6;
          _this.maxTick = 2;
          _this.meshName = "MeshDrawRoot";
          _this.path = "configs/MapCfg.json";

          _initializerDefineProperty(_this, "mat", _descriptor2, _assertThisInitialized(_this));

          _this.mapCfgArr = [];
          return _this;
        }

        _createClass(MapMgr, [{
          key: "onLoad",
          value: function onLoad() {
            var self = this; //self.InitMapCfg(self.path);
            // self.DrawMap(2, 2);
            //self.CreateGrid("editor/grid");
          }
        }, {
          key: "start",
          value: function start() {
            this.CreateGrid('editor/grid');
          }
        }, {
          key: "InitMapCfg",

          /**
           * 初始化地图数据
           * @param path 配置表路径
           */
          value: function InitMapCfg(path) {
            var self = this;
            loader.loadRes(path, null, null, null, function (err, obj) {
              if (err) {
                console.log("err while read" + err);
                return;
              } //解析数据


              var mapData = JsonAsset.deserialize(obj);
              var data = mapData.json;

              for (var i = 0; i < data.length; i++) {
                var currId = data[i].id;
                var currMapX = data[i].mapX;
                var currMapY = data[i].mapY;
                var currType = data[i].type;
                var map = new (_crd && MapCfgData === void 0 ? (_reportPossibleCrUseOfMapCfgData({
                  error: Error()
                }), MapCfgData) : MapCfgData)(currId, currMapX, currMapY, currType);
                self.mapCfgArr.push(map);
                console.log("data[0]'s value is:" + data[i].des);
                console.log("now ,I want to know map's value:" + map.id + "  " + "  " + map.mapX + "  " + map.mapY + "  " + map.type);
                console.log("Also,I want to know mapCfgArr's length is: " + self.mapCfgArr.length);
              }

              console.log("MapDataCfg init successfully!!! ");
            });
          }
          /**
           * 获取ID对应的MapData
           * @param id 
           */

        }, {
          key: "GetMapCfgDataByID",
          value: function GetMapCfgDataByID(id) {
            var self = this;
            var mcd = null;
            self.mapCfgArr.forEach(function (element) {
              if (element.id == id) mcd = element;else console.log("Not found it...");
            });
            return mcd;
          }
        }, {
          key: "DrawMesh",
          value: function DrawMesh() {}
          /**
           * 创建Mesh
           * @param effectName 节点名
           */

        }, {
          key: "CreateGrid",
          value: function CreateGrid(effectName) {
            var tempNode = new Node(effectName);
            tempNode.parent = this.node;
            tempNode.setWorldPosition(cc.v3(0, 0, 0));
            var model = tempNode.addComponent(ModelComponent);
            var positions = [];
            var colors = [];
            var indices = [];
            var xLineNum = 10;
            var zLineNum = 10;
            var space = 1;

            for (var i = 0; i < xLineNum; i++) {
              positions.push(i * space, -1000);
              positions.push(i * space, 1000);
            }

            for (var j = 0; j < zLineNum; j++) {
              positions.push(-1000, j * space);
              positions.push(1000, j * space);
            }

            for (var _i = 0; _i < positions.length; _i += 2) {
              indices.push(_i / 2);
            }

            var primitiveMode = GFXPrimitiveMode.LINE_STRIP_ADJACENCY; // 使用二维顶点来节省顶点数据

            var attributes = [{
              name: GFXAttributeName.ATTR_POSITION,
              format: GFXFormat.RG32F
            }];
            var mesh = utils.createMesh({
              positions: positions,
              indices: indices,
              colors: colors,
              primitiveMode: primitiveMode,
              attributes: attributes
            });
            model.mesh = mesh;
            model.material = this.mat;
            return model;
          }
        }]);

        return MapMgr;
      }(Component), _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "targerNode", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "mat", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      _crd = false;

      _cclegacy._RF.pop();
    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vRDovQ29Db3MzRExzdC9NeUFTdGFydC9hc3NldHMvc2NpcHRzL015L01hcE1nci50cyJdLCJuYW1lcyI6WyJfZGVjb3JhdG9yIiwiQ29tcG9uZW50IiwiTm9kZSIsImxvYWRlciIsIk1vZGVsQ29tcG9uZW50IiwiR0ZYUHJpbWl0aXZlTW9kZSIsInV0aWxzIiwiR0ZYQXR0cmlidXRlTmFtZSIsIkdGWEZvcm1hdCIsIk1hdGVyaWFsIiwiSnNvbkFzc2V0IiwiTWFwQ2ZnRGF0YSIsImNjY2xhc3MiLCJwcm9wZXJ0eSIsIk1hcE1nciIsInR5cGUiLCJncmlkVyIsImdyaWRIIiwibWF4VGljayIsIm1lc2hOYW1lIiwicGF0aCIsIm1hcENmZ0FyciIsInNlbGYiLCJDcmVhdGVHcmlkIiwibG9hZFJlcyIsImVyciIsIm9iaiIsImNvbnNvbGUiLCJsb2ciLCJtYXBEYXRhIiwiZGVzZXJpYWxpemUiLCJkYXRhIiwianNvbiIsImkiLCJsZW5ndGgiLCJjdXJySWQiLCJpZCIsImN1cnJNYXBYIiwibWFwWCIsImN1cnJNYXBZIiwibWFwWSIsImN1cnJUeXBlIiwibWFwIiwicHVzaCIsImRlcyIsIm1jZCIsImZvckVhY2giLCJlbGVtZW50IiwiZWZmZWN0TmFtZSIsInRlbXBOb2RlIiwicGFyZW50Iiwibm9kZSIsInNldFdvcmxkUG9zaXRpb24iLCJjYyIsInYzIiwibW9kZWwiLCJhZGRDb21wb25lbnQiLCJwb3NpdGlvbnMiLCJjb2xvcnMiLCJpbmRpY2VzIiwieExpbmVOdW0iLCJ6TGluZU51bSIsInNwYWNlIiwiaiIsInByaW1pdGl2ZU1vZGUiLCJMSU5FX1NUUklQX0FESkFDRU5DWSIsImF0dHJpYnV0ZXMiLCJuYW1lIiwiQVRUUl9QT1NJVElPTiIsImZvcm1hdCIsIlJHMzJGIiwibWVzaCIsImNyZWF0ZU1lc2giLCJtYXRlcmlhbCIsIm1hdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBU0EsTUFBQUEsVSxPQUFBQSxVO0FBQVlDLE1BQUFBLFMsT0FBQUEsUztBQUFXQyxNQUFBQSxJLE9BQUFBLEk7QUFBMERDLE1BQUFBLE0sT0FBQUEsTTtBQUFRQyxNQUFBQSxjLE9BQUFBLGM7QUFBc0JDLE1BQUFBLGdCLE9BQUFBLGdCO0FBQWtCQyxNQUFBQSxLLE9BQUFBLEs7QUFBT0MsTUFBQUEsZ0IsT0FBQUEsZ0I7QUFBa0JDLE1BQUFBLFMsT0FBQUEsUztBQUFXQyxNQUFBQSxRLE9BQUFBLFE7QUFBVUMsTUFBQUEsUyxPQUFBQSxTOzs7O0FBQy9LQyxNQUFBQSxVLGlCQUFBQSxVOzs7Ozs7QUFFREMsTUFBQUEsTyxHQUFzQlosVSxDQUF0QlksTztBQUFTQyxNQUFBQSxRLEdBQWFiLFUsQ0FBYmEsUTs7d0JBR0pDLE0sV0FEWkYsT0FBTyxDQUFDLFFBQUQsQyxVQUtIQyxRQUFRLENBQUM7QUFBRUUsUUFBQUEsSUFBSSxFQUFFYjtBQUFSLE9BQUQsQyxVQWlCUlcsUUFBUSxDQUFDO0FBQUNFLFFBQUFBLElBQUksRUFBRU47QUFBUCxPQUFELEM7OztBQUxUOzs7QUFRQSwwQkFBYztBQUFBOztBQUFBOztBQUNWOztBQURVOztBQUFBLGdCQWpCUE8sS0FpQk8sR0FqQkMsQ0FpQkQ7QUFBQSxnQkFoQlBDLEtBZ0JPLEdBaEJDLENBZ0JEO0FBQUEsZ0JBWk5DLE9BWU0sR0FaRSxDQVlGO0FBQUEsZ0JBVkxDLFFBVUssR0FWSSxjQVVKO0FBQUEsZ0JBTEdDLElBS0gsR0FMVSxxQkFLVjs7QUFBQTs7QUFBQSxnQkFpQlBDLFNBakJPLEdBaUJ3QixFQWpCeEI7QUFBQTtBQUViOzs7O21DQUVRO0FBQ0wsZ0JBQUlDLElBQUksR0FBRyxJQUFYLENBREssQ0FHTDtBQUNBO0FBRUE7QUFDSDs7O2tDQUVNO0FBQ0osaUJBQUtDLFVBQUwsQ0FBZ0IsYUFBaEI7QUFDRjs7OztBQUlEOzs7O3FDQUltQkgsSSxFQUFjO0FBQzdCLGdCQUFJRSxJQUFJLEdBQUcsSUFBWDtBQUVBbkIsWUFBQUEsTUFBTSxDQUFDcUIsT0FBUCxDQUFxQkosSUFBckIsRUFBMkIsSUFBM0IsRUFBaUMsSUFBakMsRUFBdUMsSUFBdkMsRUFBNkMsVUFBVUssR0FBVixFQUFlQyxHQUFmLEVBQW9CO0FBQzdELGtCQUFJRCxHQUFKLEVBQVM7QUFDTEUsZ0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLG1CQUFtQkgsR0FBL0I7QUFDQTtBQUNILGVBSjRELENBTTdEOzs7QUFDQSxrQkFBSUksT0FBTyxHQUFHbkIsU0FBUyxDQUFDb0IsV0FBVixDQUFzQkosR0FBdEIsQ0FBZDtBQUNBLGtCQUFJSyxJQUFJLEdBQUdGLE9BQU8sQ0FBQ0csSUFBbkI7O0FBQ0EsbUJBQUssSUFBSUMsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR0YsSUFBSSxDQUFDRyxNQUF6QixFQUFpQ0QsQ0FBQyxFQUFsQyxFQUFzQztBQUNsQyxvQkFBSUUsTUFBTSxHQUFHSixJQUFJLENBQUNFLENBQUQsQ0FBSixDQUFRRyxFQUFyQjtBQUNBLG9CQUFJQyxRQUFRLEdBQUdOLElBQUksQ0FBQ0UsQ0FBRCxDQUFKLENBQVFLLElBQXZCO0FBQ0Esb0JBQUlDLFFBQVEsR0FBR1IsSUFBSSxDQUFDRSxDQUFELENBQUosQ0FBUU8sSUFBdkI7QUFDQSxvQkFBSUMsUUFBUSxHQUFHVixJQUFJLENBQUNFLENBQUQsQ0FBSixDQUFRbEIsSUFBdkI7QUFFQSxvQkFBSTJCLEdBQWUsR0FBRztBQUFBO0FBQUEsOENBQWVQLE1BQWYsRUFBdUJFLFFBQXZCLEVBQWlDRSxRQUFqQyxFQUEyQ0UsUUFBM0MsQ0FBdEI7QUFDQW5CLGdCQUFBQSxJQUFJLENBQUNELFNBQUwsQ0FBZXNCLElBQWYsQ0FBb0JELEdBQXBCO0FBQ0FmLGdCQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSx3QkFBd0JHLElBQUksQ0FBQ0UsQ0FBRCxDQUFKLENBQVFXLEdBQTVDO0FBQ0FqQixnQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVkscUNBQW1DYyxHQUFHLENBQUNOLEVBQXZDLEdBQTBDLElBQTFDLEdBQStDLElBQS9DLEdBQW9ETSxHQUFHLENBQUNKLElBQXhELEdBQTZELElBQTdELEdBQWtFSSxHQUFHLENBQUNGLElBQXRFLEdBQTJFLElBQTNFLEdBQWdGRSxHQUFHLENBQUMzQixJQUFoRztBQUNBWSxnQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksZ0RBQThDTixJQUFJLENBQUNELFNBQUwsQ0FBZWEsTUFBekU7QUFDSDs7QUFFRFAsY0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksa0NBQVo7QUFDSCxhQXZCRDtBQXdCSDtBQUVEOzs7Ozs7OzRDQUl5QlEsRSxFQUFnQjtBQUNyQyxnQkFBSWQsSUFBSSxHQUFHLElBQVg7QUFDQSxnQkFBSXVCLEdBQWUsR0FBRyxJQUF0QjtBQUVBdkIsWUFBQUEsSUFBSSxDQUFDRCxTQUFMLENBQWV5QixPQUFmLENBQXVCLFVBQUFDLE9BQU8sRUFBSTtBQUM5QixrQkFBSUEsT0FBTyxDQUFDWCxFQUFSLElBQWNBLEVBQWxCLEVBQ0lTLEdBQUcsR0FBR0UsT0FBTixDQURKLEtBR0lwQixPQUFPLENBQUNDLEdBQVIsQ0FBWSxpQkFBWjtBQUNQLGFBTEQ7QUFPQSxtQkFBT2lCLEdBQVA7QUFDSDs7O3FDQUdnQixDQUVoQjtBQUVEOzs7Ozs7O3FDQUlrQkcsVSxFQUFZO0FBQzFCLGdCQUFNQyxRQUFRLEdBQUcsSUFBSS9DLElBQUosQ0FBUzhDLFVBQVQsQ0FBakI7QUFFQUMsWUFBQUEsUUFBUSxDQUFDQyxNQUFULEdBQWtCLEtBQUtDLElBQXZCO0FBQ0FGLFlBQUFBLFFBQVEsQ0FBQ0csZ0JBQVQsQ0FBMEJDLEVBQUUsQ0FBQ0MsRUFBSCxDQUFNLENBQU4sRUFBUyxDQUFULEVBQVksQ0FBWixDQUExQjtBQUNBLGdCQUFNQyxLQUFLLEdBQUdOLFFBQVEsQ0FBQ08sWUFBVCxDQUFzQnBELGNBQXRCLENBQWQ7QUFFQSxnQkFBTXFELFNBQVMsR0FBRyxFQUFsQjtBQUNBLGdCQUFNQyxNQUFNLEdBQUcsRUFBZjtBQUNBLGdCQUFNQyxPQUFPLEdBQUcsRUFBaEI7QUFFQSxnQkFBTUMsUUFBUSxHQUFHLEVBQWpCO0FBQ0EsZ0JBQU1DLFFBQVEsR0FBRyxFQUFqQjtBQUNBLGdCQUFNQyxLQUFLLEdBQUcsQ0FBZDs7QUFFQSxpQkFBSyxJQUFJN0IsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBRzJCLFFBQXBCLEVBQThCM0IsQ0FBQyxFQUEvQixFQUFtQztBQUMvQndCLGNBQUFBLFNBQVMsQ0FBQ2QsSUFBVixDQUFlVixDQUFDLEdBQUM2QixLQUFqQixFQUF3QixDQUFDLElBQXpCO0FBQ0FMLGNBQUFBLFNBQVMsQ0FBQ2QsSUFBVixDQUFlVixDQUFDLEdBQUM2QixLQUFqQixFQUF3QixJQUF4QjtBQUNIOztBQUVELGlCQUFLLElBQUlDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdGLFFBQXBCLEVBQThCRSxDQUFDLEVBQS9CLEVBQW1DO0FBQy9CTixjQUFBQSxTQUFTLENBQUNkLElBQVYsQ0FBZSxDQUFDLElBQWhCLEVBQXNCb0IsQ0FBQyxHQUFDRCxLQUF4QjtBQUNBTCxjQUFBQSxTQUFTLENBQUNkLElBQVYsQ0FBZSxJQUFmLEVBQXFCb0IsQ0FBQyxHQUFDRCxLQUF2QjtBQUNIOztBQUVELGlCQUFLLElBQUk3QixFQUFDLEdBQUcsQ0FBYixFQUFnQkEsRUFBQyxHQUFHd0IsU0FBUyxDQUFDdkIsTUFBOUIsRUFBc0NELEVBQUMsSUFBSSxDQUEzQyxFQUE4QztBQUMxQzBCLGNBQUFBLE9BQU8sQ0FBQ2hCLElBQVIsQ0FBYVYsRUFBQyxHQUFHLENBQWpCO0FBQ0g7O0FBRUQsZ0JBQU0rQixhQUFhLEdBQUczRCxnQkFBZ0IsQ0FBQzRELG9CQUF2QyxDQTdCMEIsQ0E4QjFCOztBQUNBLGdCQUFNQyxVQUFVLEdBQUcsQ0FBQztBQUNoQkMsY0FBQUEsSUFBSSxFQUFFNUQsZ0JBQWdCLENBQUM2RCxhQURQO0FBRWhCQyxjQUFBQSxNQUFNLEVBQUU3RCxTQUFTLENBQUM4RDtBQUZGLGFBQUQsQ0FBbkI7QUFJQSxnQkFBTUMsSUFBSSxHQUFHakUsS0FBSyxDQUFDa0UsVUFBTixDQUFpQjtBQUFDZixjQUFBQSxTQUFTLEVBQVRBLFNBQUQ7QUFBWUUsY0FBQUEsT0FBTyxFQUFQQSxPQUFaO0FBQXFCRCxjQUFBQSxNQUFNLEVBQU5BLE1BQXJCO0FBQTZCTSxjQUFBQSxhQUFhLEVBQWJBLGFBQTdCO0FBQTRDRSxjQUFBQSxVQUFVLEVBQVZBO0FBQTVDLGFBQWpCLENBQWI7QUFFQVgsWUFBQUEsS0FBSyxDQUFDZ0IsSUFBTixHQUFhQSxJQUFiO0FBQ0FoQixZQUFBQSxLQUFLLENBQUNrQixRQUFOLEdBQWlCLEtBQUtDLEdBQXRCO0FBRUEsbUJBQU9uQixLQUFQO0FBQ0g7Ozs7UUFoSnVCdEQsUzs7Ozs7aUJBS0UsSTs7Ozs7OztpQkFpQkgsSSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IF9kZWNvcmF0b3IsIENvbXBvbmVudCwgTm9kZSwgR3JhcGhpY3NDb21wb25lbnQsIENvbG9yLCBHRlhfRFJBV19JTkZPX1NJWkUsIHBhdGgsIGxvYWRlciwgTW9kZWxDb21wb25lbnQsIE1lc2gsIEdGWFByaW1pdGl2ZU1vZGUsIHV0aWxzLCBHRlhBdHRyaWJ1dGVOYW1lLCBHRlhGb3JtYXQsIE1hdGVyaWFsLCBKc29uQXNzZXQsIGFuaW1hdGlvbiwgVmVjMyB9IGZyb20gJ2NjJztcclxuaW1wb3J0IHsgTWFwQ2ZnRGF0YSB9IGZyb20gJy4vTWFwQ2ZnRGF0YSc7XHJcbmltcG9ydCB7IEVfTm9kZV9UeXBlIH0gZnJvbSAnLi9BU3Rhck5vZGUnO1xyXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBfZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3MoJ01hcE1ncicpXHJcbmV4cG9ydCBjbGFzcyBNYXBNZ3IgZXh0ZW5kcyBDb21wb25lbnQge1xyXG5cclxuICBcclxuXHJcbiAgICBAcHJvcGVydHkoeyB0eXBlOiBOb2RlIH0pXHJcbiAgICBwdWJsaWMgdGFyZ2VyTm9kZTogTm9kZSA9IG51bGw7XHJcblxyXG4gICAgcHVibGljIGdyaWRXID0gNjtcclxuICAgIHB1YmxpYyBncmlkSCA9IDY7XHJcblxyXG4gICAgcHVibGljIG1lc2hWOiBNZXNoO1xyXG5cclxuICAgIHByaXZhdGUgbWF4VGljaz0yO1xyXG5cclxuICAgIHByaXZhdGUgIG1lc2hOYW1lPVwiTWVzaERyYXdSb290XCJcclxuXHJcbiAgICAvKipcclxuICAgICAqIOWcsOWbvumFjee9ruihqOi3r+W+hFxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIHJlYWRvbmx5IHBhdGggPSBcImNvbmZpZ3MvTWFwQ2ZnLmpzb25cIjtcclxuXHJcbiAgICBAcHJvcGVydHkoe3R5cGU6IE1hdGVyaWFsfSlcclxuICAgIHB1YmxpYyBtYXQ6IE1hdGVyaWFsID0gbnVsbDs7XHJcblxyXG4gICAgY29uc3RydWN0b3IoKSB7XHJcbiAgICAgICAgc3VwZXIoKTtcclxuICAgIH1cclxuXHJcbiAgICBvbkxvYWQoKSB7XHJcbiAgICAgICAgbGV0IHNlbGYgPSB0aGlzO1xyXG5cclxuICAgICAgICAvL3NlbGYuSW5pdE1hcENmZyhzZWxmLnBhdGgpO1xyXG4gICAgICAgIC8vIHNlbGYuRHJhd01hcCgyLCAyKTtcclxuXHJcbiAgICAgICAgLy9zZWxmLkNyZWF0ZUdyaWQoXCJlZGl0b3IvZ3JpZFwiKTtcclxuICAgIH1cclxuXHJcbiAgICBzdGFydCgpe1xyXG4gICAgICAgdGhpcy5DcmVhdGVHcmlkKCdlZGl0b3IvZ3JpZCcpO1xyXG4gICAgfVxyXG5cclxuICAgIHB1YmxpYyBtYXBDZmdBcnI6IEFycmF5PE1hcENmZ0RhdGE+ID0gW107XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiDliJ3lp4vljJblnLDlm77mlbDmja5cclxuICAgICAqIEBwYXJhbSBwYXRoIOmFjee9ruihqOi3r+W+hFxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIEluaXRNYXBDZmcocGF0aDogc3RyaW5nKSB7XHJcbiAgICAgICAgbGV0IHNlbGYgPSB0aGlzO1xyXG5cclxuICAgICAgICBsb2FkZXIubG9hZFJlczxKU09OPihwYXRoLCBudWxsLCBudWxsLCBudWxsLCBmdW5jdGlvbiAoZXJyLCBvYmopIHtcclxuICAgICAgICAgICAgaWYgKGVycikge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJlcnIgd2hpbGUgcmVhZFwiICsgZXJyKTtcclxuICAgICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLy/op6PmnpDmlbDmja5cclxuICAgICAgICAgICAgbGV0IG1hcERhdGEgPSBKc29uQXNzZXQuZGVzZXJpYWxpemUob2JqKTsgICAgXHJcbiAgICAgICAgICAgIGxldCBkYXRhID0gbWFwRGF0YS5qc29uOyAgICBcclxuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkYXRhLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgY3VycklkID0gZGF0YVtpXS5pZDtcclxuICAgICAgICAgICAgICAgIGxldCBjdXJyTWFwWCA9IGRhdGFbaV0ubWFwWDtcclxuICAgICAgICAgICAgICAgIGxldCBjdXJyTWFwWSA9IGRhdGFbaV0ubWFwWTtcclxuICAgICAgICAgICAgICAgIGxldCBjdXJyVHlwZSA9IGRhdGFbaV0udHlwZTtcclxuXHJcbiAgICAgICAgICAgICAgICBsZXQgbWFwOiBNYXBDZmdEYXRhID0gbmV3IE1hcENmZ0RhdGEoY3VycklkLCBjdXJyTWFwWCwgY3Vyck1hcFksIGN1cnJUeXBlKTtcclxuICAgICAgICAgICAgICAgIHNlbGYubWFwQ2ZnQXJyLnB1c2gobWFwKTtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiZGF0YVswXSdzIHZhbHVlIGlzOlwiICsgZGF0YVtpXS5kZXMpO1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJub3cgLEkgd2FudCB0byBrbm93IG1hcCdzIHZhbHVlOlwiK21hcC5pZCtcIiAgXCIrXCIgIFwiK21hcC5tYXBYK1wiICBcIittYXAubWFwWStcIiAgXCIrbWFwLnR5cGUpO1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJBbHNvLEkgd2FudCB0byBrbm93IG1hcENmZ0FycidzIGxlbmd0aCBpczogXCIrc2VsZi5tYXBDZmdBcnIubGVuZ3RoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgIFxyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIk1hcERhdGFDZmcgaW5pdCBzdWNjZXNzZnVsbHkhISEgXCIpO1xyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICog6I635Y+WSUTlr7nlupTnmoRNYXBEYXRhXHJcbiAgICAgKiBAcGFyYW0gaWQgXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBHZXRNYXBDZmdEYXRhQnlJRChpZCk6IE1hcENmZ0RhdGEge1xyXG4gICAgICAgIGxldCBzZWxmID0gdGhpcztcclxuICAgICAgICBsZXQgbWNkOiBNYXBDZmdEYXRhID0gbnVsbDtcclxuXHJcbiAgICAgICAgc2VsZi5tYXBDZmdBcnIuZm9yRWFjaChlbGVtZW50ID0+IHtcclxuICAgICAgICAgICAgaWYgKGVsZW1lbnQuaWQgPT0gaWQpXHJcbiAgICAgICAgICAgICAgICBtY2QgPSBlbGVtZW50O1xyXG4gICAgICAgICAgICBlbHNlXHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIk5vdCBmb3VuZCBpdC4uLlwiKTtcclxuICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgcmV0dXJuIG1jZDtcclxuICAgIH1cclxuXHJcbiAgXHJcbiAgICBwdWJsaWMgRHJhd01lc2goKXtcclxuXHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiDliJvlu7pNZXNoXHJcbiAgICAgKiBAcGFyYW0gZWZmZWN0TmFtZSDoioLngrnlkI1cclxuICAgICAqL1xyXG4gICAgcHVibGljIENyZWF0ZUdyaWQoZWZmZWN0TmFtZSkge1xyXG4gICAgICAgIGNvbnN0IHRlbXBOb2RlID0gbmV3IE5vZGUoZWZmZWN0TmFtZSk7XHJcblxyXG4gICAgICAgIHRlbXBOb2RlLnBhcmVudCA9IHRoaXMubm9kZTtcclxuICAgICAgICB0ZW1wTm9kZS5zZXRXb3JsZFBvc2l0aW9uKGNjLnYzKDAsIDAsIDApKTtcclxuICAgICAgICBjb25zdCBtb2RlbCA9IHRlbXBOb2RlLmFkZENvbXBvbmVudChNb2RlbENvbXBvbmVudCk7XHJcblxyXG4gICAgICAgIGNvbnN0IHBvc2l0aW9ucyA9IFtdO1xyXG4gICAgICAgIGNvbnN0IGNvbG9ycyA9IFtdO1xyXG4gICAgICAgIGNvbnN0IGluZGljZXMgPSBbXTtcclxuXHJcbiAgICAgICAgY29uc3QgeExpbmVOdW0gPSAxMDtcclxuICAgICAgICBjb25zdCB6TGluZU51bSA9IDEwO1xyXG4gICAgICAgIGNvbnN0IHNwYWNlID0gMTtcclxuICAgICAgICBcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHhMaW5lTnVtOyBpKyspIHtcclxuICAgICAgICAgICAgcG9zaXRpb25zLnB1c2goaSpzcGFjZSwgLTEwMDApO1xyXG4gICAgICAgICAgICBwb3NpdGlvbnMucHVzaChpKnNwYWNlLCAxMDAwKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgekxpbmVOdW07IGorKykge1xyXG4gICAgICAgICAgICBwb3NpdGlvbnMucHVzaCgtMTAwMCwgaipzcGFjZSk7XHJcbiAgICAgICAgICAgIHBvc2l0aW9ucy5wdXNoKDEwMDAsIGoqc3BhY2UpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBwb3NpdGlvbnMubGVuZ3RoOyBpICs9IDIpIHtcclxuICAgICAgICAgICAgaW5kaWNlcy5wdXNoKGkgLyAyKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IHByaW1pdGl2ZU1vZGUgPSBHRlhQcmltaXRpdmVNb2RlLkxJTkVfU1RSSVBfQURKQUNFTkNZO1xyXG4gICAgICAgIC8vIOS9v+eUqOS6jOe7tOmhtueCueadpeiKguecgemhtueCueaVsOaNrlxyXG4gICAgICAgIGNvbnN0IGF0dHJpYnV0ZXMgPSBbe1xyXG4gICAgICAgICAgICBuYW1lOiBHRlhBdHRyaWJ1dGVOYW1lLkFUVFJfUE9TSVRJT04sXHJcbiAgICAgICAgICAgIGZvcm1hdDogR0ZYRm9ybWF0LlJHMzJGLFxyXG4gICAgICAgIH1dO1xyXG4gICAgICAgIGNvbnN0IG1lc2ggPSB1dGlscy5jcmVhdGVNZXNoKHtwb3NpdGlvbnMsIGluZGljZXMsIGNvbG9ycywgcHJpbWl0aXZlTW9kZSwgYXR0cmlidXRlc30pO1xyXG5cclxuICAgICAgICBtb2RlbC5tZXNoID0gbWVzaDtcclxuICAgICAgICBtb2RlbC5tYXRlcmlhbCA9IHRoaXMubWF0O1xyXG5cclxuICAgICAgICByZXR1cm4gbW9kZWw7XHJcbiAgICB9XHJcblxyXG59XHJcbiJdfQ==