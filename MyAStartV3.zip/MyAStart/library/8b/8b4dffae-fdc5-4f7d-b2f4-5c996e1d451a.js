System.register(["cc", "code-quality:cr", "./AStar.js"], function (_export, _context) {
  "use strict";

  var _cclegacy, _reporterNs, _decorator, Component, AStar, _dec, _class, _crd, ccclass, property, GamdCtrl;

  function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

  function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

  function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

  function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

  function _reportPossibleCrUseOfAStar(extras) {
    _reporterNs.report("AStar", "./AStar", _context.meta, extras);
  }

  _export({
    _dec: void 0,
    _class: void 0
  });

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
    }, function (_codeQualityCr) {
      _reporterNs = _codeQualityCr;
    }, function (_AStarJs) {
      AStar = _AStarJs.AStar;
    }],
    execute: function () {
      _cclegacy._RF.push({}, "8b4df+u/cVPfbL0XJluHUUa", "GameCtrl", _context.meta);

      _crd = true;
      ccclass = _decorator.ccclass;
      property = _decorator.property;

      _export("GamdCtrl", GamdCtrl = (_dec = ccclass('GridCtrl'), _dec(_class = /*#__PURE__*/function (_Component) {
        _inherits(GamdCtrl, _Component);

        function GamdCtrl() {
          _classCallCheck(this, GamdCtrl);

          return _possibleConstructorReturn(this, _getPrototypeOf(GamdCtrl).apply(this, arguments));
        }

        _createClass(GamdCtrl, [{
          key: "start",
          value: function start() {}
        }, {
          key: "OnBtnRestart",
          value: function OnBtnRestart() {
            this.node.getComponent(_crd && AStar === void 0 ? (_reportPossibleCrUseOfAStar({
              error: Error()
            }), AStar) : AStar).InitMap();
          }
        }, {
          key: "OnCheck",
          value: function OnCheck(toggle, v) {
            if (v == 8) {
              this.node.getComponent(_crd && AStar === void 0 ? (_reportPossibleCrUseOfAStar({
                error: Error()
              }), AStar) : AStar).is8dir = toggle.isChecked;
            } else {
              this.node.getComponent(_crd && AStar === void 0 ? (_reportPossibleCrUseOfAStar({
                error: Error()
              }), AStar) : AStar).is8dir = !toggle.isChecked;
            }
          }
        }]);

        return GamdCtrl;
      }(Component)) || _class));

      _crd = false;

      _cclegacy._RF.pop();
    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vRDovQ29Db3MzRExzdC9NeUFTdGFydC9hc3NldHMvc2NpcHRzL0dhbWVDdHJsLnRzIl0sIm5hbWVzIjpbIl9kZWNvcmF0b3IiLCJDb21wb25lbnQiLCJBU3RhciIsImNjY2xhc3MiLCJwcm9wZXJ0eSIsIkdhbWRDdHJsIiwibm9kZSIsImdldENvbXBvbmVudCIsIkluaXRNYXAiLCJ0b2dnbGUiLCJ2IiwiaXM4ZGlyIiwiaXNDaGVja2VkIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFTQSxNQUFBQSxVLE9BQUFBLFU7QUFBWUMsTUFBQUEsUyxPQUFBQSxTOzs7O0FBQ1pDLE1BQUFBLEssWUFBQUEsSzs7Ozs7O0FBQ0RDLE1BQUFBLE8sR0FBc0JILFUsQ0FBdEJHLE87QUFBU0MsTUFBQUEsUSxHQUFhSixVLENBQWJJLFE7OzBCQUdKQyxRLFdBRFpGLE9BQU8sQ0FBQyxVQUFELEM7Ozs7Ozs7Ozs7O2tDQUdFLENBRVA7Ozt5Q0FFcUI7QUFDcEIsaUJBQUtHLElBQUwsQ0FBVUMsWUFBVjtBQUFBO0FBQUEsZ0NBQThCQyxPQUE5QjtBQUNEOzs7a0NBR2NDLE0sRUFBUUMsQyxFQUFHO0FBQ3hCLGdCQUFJQSxDQUFDLElBQUksQ0FBVCxFQUFZO0FBQ1YsbUJBQUtKLElBQUwsQ0FBVUMsWUFBVjtBQUFBO0FBQUEsa0NBQThCSSxNQUE5QixHQUF1Q0YsTUFBTSxDQUFDRyxTQUE5QztBQUNELGFBRkQsTUFFTztBQUNMLG1CQUFLTixJQUFMLENBQVVDLFlBQVY7QUFBQTtBQUFBLGtDQUE4QkksTUFBOUIsR0FBdUMsQ0FBQ0YsTUFBTSxDQUFDRyxTQUEvQztBQUNEO0FBQ0Y7Ozs7UUFqQjJCWCxTIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgX2RlY29yYXRvciwgQ29tcG9uZW50LCBOb2RlIH0gZnJvbSAnY2MnO1xyXG5pbXBvcnQgeyBBU3RhciB9IGZyb20gJy4vQVN0YXInO1xyXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBfZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3MoJ0dyaWRDdHJsJylcclxuZXhwb3J0IGNsYXNzIEdhbWRDdHJsIGV4dGVuZHMgQ29tcG9uZW50IHtcclxuXHJcbiAgc3RhcnQoKSB7XHJcblxyXG4gIH1cclxuXHJcbiAgcHVibGljIE9uQnRuUmVzdGFydCgpIHtcclxuICAgIHRoaXMubm9kZS5nZXRDb21wb25lbnQoQVN0YXIpLkluaXRNYXAoKTtcclxuICB9XHJcblxyXG5cclxuICBwdWJsaWMgT25DaGVjayh0b2dnbGUsIHYpIHtcclxuICAgIGlmICh2ID09IDgpIHtcclxuICAgICAgdGhpcy5ub2RlLmdldENvbXBvbmVudChBU3RhcikuaXM4ZGlyID0gdG9nZ2xlLmlzQ2hlY2tlZDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHRoaXMubm9kZS5nZXRDb21wb25lbnQoQVN0YXIpLmlzOGRpciA9ICF0b2dnbGUuaXNDaGVja2VkO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcblxyXG59XHJcbiJdfQ==