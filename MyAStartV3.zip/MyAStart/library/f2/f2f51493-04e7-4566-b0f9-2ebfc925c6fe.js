System.register(["cc", "code-quality:cr", "./Grid.js"], function (_export, _context) {
  "use strict";

  var _cclegacy, _reporterNs, _decorator, Component, Node, GraphicsComponent, systemEvent, SystemEventType, Color, Vec2, GridType, Grid, _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _temp, _crd, ccclass, property, AStar;

  function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } return _assertThisInitialized(self); }

  function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

  function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

  function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); if (superClass) _setPrototypeOf(subClass, superClass); }

  function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfGridType(extras) {
    _reporterNs.report("GridType", "./Grid", _context.meta, extras);
  }

  function _reportPossibleCrUseOfGrid(extras) {
    _reporterNs.report("Grid", "./Grid", _context.meta, extras);
  }

  _export({
    _dec: void 0,
    _dec2: void 0,
    _dec3: void 0,
    _class: void 0,
    _class2: void 0,
    _descriptor: void 0,
    _descriptor2: void 0,
    _temp: void 0
  });

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      GraphicsComponent = _cc.GraphicsComponent;
      systemEvent = _cc.systemEvent;
      SystemEventType = _cc.SystemEventType;
      Color = _cc.Color;
      Vec2 = _cc.Vec2;
    }, function (_codeQualityCr) {
      _reporterNs = _codeQualityCr;
    }, function (_GridJs) {
      GridType = _GridJs.GridType;
      Grid = _GridJs.Grid;
    }],
    execute: function () {
      _cclegacy._RF.push({}, "f2f51STBOdFZrD5Lr/JJcb+", "AStar", _context.meta);

      _crd = true;
      ccclass = _decorator.ccclass;
      property = _decorator.property;

      _export("AStar", AStar = (_dec = ccclass('AStar'), _dec2 = property({
        type: Node
      }), _dec3 = property({
        type: GraphicsComponent
      }), _dec(_class = (_class2 = (_temp = /*#__PURE__*/function (_Component) {
        _inherits(AStar, _Component);

        /**
         * 格子列表
         */

        /**
         * 路径数组
         */

        /**
         * 开启列表
         */

        /**
         * 关闭列表
         */
        function AStar() {
          var _this;

          _classCallCheck(this, AStar);

          _this = _possibleConstructorReturn(this, _getPrototypeOf(AStar).call(this));

          _initializerDefineProperty(_this, "mapPos", _descriptor, _assertThisInitialized(_this));

          _initializerDefineProperty(_this, "map", _descriptor2, _assertThisInitialized(_this));

          _this.gridsLst = new Array();
          _this.path = null;
          _this.openLst = null;
          _this.closeLst = null;
          _this.map;
          return _this;
        }

        _createClass(AStar, [{
          key: "onLoad",
          value: function onLoad() {
            this.gridW = 50;
            this.gridH = 50;
            this.mapH = 15;
            this.mapW = 25;
            this.is8dir = true;
            systemEvent.on(SystemEventType.TOUCH_START, this.OnTouchStart, this);
            systemEvent.on(SystemEventType.TOUCH_MOVE, this.OnTouchMove, this);
            systemEvent.on(SystemEventType.TOUCH_START, this.OnTouchEnd, this); //初始化map
            //this.map=this.mapPos.getComponent<GraphicsComponent>();
            //初始化地图

            this.InitMap();
          }
          /**
           * 当触摸开始时
           */

        }, {
          key: "OnTouchStart",
          value: function OnTouchStart() {} // this.InitMap();

          /** 
           * 当触摸时
          */

        }, {
          key: "OnTouchMove",
          value: function OnTouchMove(event) {
            var pos = event.getLocation();
            var x = Math.floor(pos.x / (this.gridW + 2));
            var y = Math.floor(pos.y / (this.gridH + 2));

            if (this.gridsLst[x][y].type == (_crd && GridType === void 0 ? (_reportPossibleCrUseOfGridType({
              error: Error()
            }), GridType) : GridType).Normal) {
              this.gridsLst[x][y].type = (_crd && GridType === void 0 ? (_reportPossibleCrUseOfGridType({
                error: Error()
              }), GridType) : GridType).Barrier;
              this.Draw(x, y, Color.CYAN);
            }
          }
          /**
           * 当触摸结束时
           */

        }, {
          key: "OnTouchEnd",
          value: function OnTouchEnd() {
            // 开始寻路
            this.FindPath(new Vec2(1, 2), new Vec2(16, 3));
          }
          /**
           * 初始化地图
           */

        }, {
          key: "InitMap",
          value: function InitMap() {
            this.openLst = new Array();
            this.closeLst = new Array();
            this.path = new Array(); // 初始化格子二维数组

            this.gridsLst = new Array(this.mapW + 1);

            for (var col = 0; col < this.gridsLst.length; col++) {
              this.gridsLst[col] = new Array(this.mapH + 1);
            }

            console.log("map 是否存在：" + this.map);
            this.map.clear();

            for (var _col = 0; _col <= this.mapW; _col++) {
              for (var row = 0; row <= this.mapH; row++) {
                this.Draw(_col, row, Color.WHITE);
                this.AddGrid(_col, row, (_crd && GridType === void 0 ? (_reportPossibleCrUseOfGridType({
                  error: Error()
                }), GridType) : GridType).Normal);
              }
            } // 设置起点和终点


            var startX = 1;
            var startY = 2;
            var endX = 16;
            var endY = 3;
            this.gridsLst[startX][startY].type = (_crd && GridType === void 0 ? (_reportPossibleCrUseOfGridType({
              error: Error()
            }), GridType) : GridType).Start;
            this.Draw(startX, startY, Color.MAGENTA);
            this.gridsLst[endX][endY].type = (_crd && GridType === void 0 ? (_reportPossibleCrUseOfGridType({
              error: Error()
            }), GridType) : GridType).End;
            this.Draw(endX, endY, Color.BLUE);
          }
          /**
           * 添加格子
           * @param x 列
           * @param y 行
           * @param type 格子类型
           */

        }, {
          key: "AddGrid",
          value: function AddGrid(x, y, type) {
            var grid = new (_crd && Grid === void 0 ? (_reportPossibleCrUseOfGrid({
              error: Error()
            }), Grid) : Grid)();
            grid.x = x;
            grid.y = y;
            grid.type = type;
            this.gridsLst[x][y] = grid;
          }
          /**
           * 排序方法
           * @param x 格子1
           * @param y 格子2
           */

        }, {
          key: "SortFunc",
          value: function SortFunc(x, y) {
            return x.f - y.f;
          }
          /**
           * 生成路径
           * @param grid 
           */

        }, {
          key: "GeneratePath",
          value: function GeneratePath(grid) {
            this.path.push(grid);

            while (grid.parent) {
              grid = grid.parent;
              this.path.push(grid);
            }

            console.log("Path.length: " + this.path.length);

            for (var i = 0; i < this.path.length; i++) {
              // 起点终点不覆盖，方便看效果
              if (i != 0 && i != this.path.length - 1) {
                var _grid = this.path[i];
                this.Draw(_grid.x, _grid.y, Color.GREEN);
              }
            }
          }
          /**
            * 找到路径
            * @param startPos 起点
            * @param endPos 终点
            */

        }, {
          key: "FindPath",
          value: function FindPath(startPos, endPos) {
            //首先判断 传入的两个点 是否合法
            //1.首先 要在地图范围内
            //如果不合法 应该直接 返回null 意味着不能寻路
            if (startPos.x < 0 || startPos.x >= this.mapW || startPos.y < 0 || startPos.y >= this.mapH || endPos.x < 0 || endPos.y >= this.mapH) {
              console.log("开始或者结束点在地图格子范围外");
              return;
            } else {
              //要不是阻挡
              //得到起点和终点 对应的格子
              var startGrid = this.gridsLst[startPos.x][startPos.y];
              var endGrid = this.gridsLst[endPos.x][endPos.y];
              this.openLst.push(startGrid);
              var curGrid = this.openLst[0];

              while (this.openLst.length > 0 && curGrid.type != (_crd && GridType === void 0 ? (_reportPossibleCrUseOfGridType({
                error: Error()
              }), GridType) : GridType).Start) {
                // 每次都取出f值最小的节点进行查找
                curGrid = this.openLst[0];

                if (curGrid.type == (_crd && GridType === void 0 ? (_reportPossibleCrUseOfGridType({
                  error: Error()
                }), GridType) : GridType).Start) {
                  console.log("Find path success.");
                  this.GeneratePath(curGrid);
                  return;
                }

                for (var i = -1; i <= 1; i++) {
                  for (var j = -1; j <= 1; j++) {
                    if (i != 0 || j != 0) {
                      var col = curGrid.x + i;
                      var row = curGrid.y + j;

                      if (col >= 0 && row >= 0 && col <= this.mapW && row <= this.mapH && this.gridsLst[col][row].type != (_crd && GridType === void 0 ? (_reportPossibleCrUseOfGridType({
                        error: Error()
                      }), GridType) : GridType).Barrier && this.closeLst.indexOf(this.gridsLst[col][row]) < 0) {
                        if (this.is8dir) {
                          // 8方向 斜向走动时要考虑相邻的是不是障碍物
                          if (this.gridsLst[col - i][row].type == (_crd && GridType === void 0 ? (_reportPossibleCrUseOfGridType({
                            error: Error()
                          }), GridType) : GridType).Barrier || this.gridsLst[col][row - j].type == (_crd && GridType === void 0 ? (_reportPossibleCrUseOfGridType({
                            error: Error()
                          }), GridType) : GridType).Barrier) {
                            continue;
                          }
                        } else {
                          // 四方形行走
                          if (Math.abs(i) == Math.abs(j)) {
                            continue;
                          }
                        } // 计算g值


                        var g = curGrid.g + parseInt(Math.sqrt(Math.pow(i * 10, 2) + Math.pow(j * 10, 2)).toString());

                        if (this.gridsLst[col][row].g == 0 || this.gridsLst[col][row].g > g) {
                          this.gridsLst[col][row].g = g; // 更新父节点

                          this.gridsLst[col][row].parent = curGrid;
                        } // 计算h值 manhattan估算法


                        this.gridsLst[col][row].h = Math.abs(endPos.x - col) + Math.abs(endPos.y - row); // 更新f值

                        this.gridsLst[col][row].f = this.gridsLst[col][row].g + this.gridsLst[col][row].h; // 如果不在开放列表里则添加到开放列表里

                        if (this.openLst.indexOf(this.gridsLst[col][row]) < 0) {
                          this.openLst.push(this.gridsLst[col][row]);
                        } // // 重新按照f值排序（升序排列)
                        // this.openList.sort(this._sortFunc);

                      }
                    }
                  }
                } // 遍历完四周节点后把当前节点加入关闭列表


                this.closeLst.push(curGrid); // 从开放列表把当前节点移除

                this.openLst.splice(this.openLst.indexOf(curGrid), 1);

                if (this.openLst.length <= 0) {
                  console.log("Find path failed.");
                } // 重新按照f值排序（升序排列)


                this.openLst.sort(this.SortFunc);
              }
            }
          }
          /**
           * 划线
           * @param col 列
           * @param row 行
           * @param color 颜色
           */

        }, {
          key: "Draw",
          value: function Draw(col, row, color) {
            color = color != undefined ? color : Color.GRAY;
            this.map.fillColor = color;
            var posX = 2 + col * (this.gridW + 2);
            var posY = 2 + row * (this.gridH + 2);
            this.map.fillRect(posX, posY, this.gridW, this.gridH);
          }
        }]);

        return AStar;
      }(Component), _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "mapPos", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "map", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      _crd = false;

      _cclegacy._RF.pop();
    }
  };
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vRDovQ29Db3MzRExzdC9NeUFTdGFydC9hc3NldHMvc2NpcHRzL0FTdGFyLnRzIl0sIm5hbWVzIjpbIl9kZWNvcmF0b3IiLCJDb21wb25lbnQiLCJOb2RlIiwiR3JhcGhpY3NDb21wb25lbnQiLCJzeXN0ZW1FdmVudCIsIlN5c3RlbUV2ZW50VHlwZSIsIkNvbG9yIiwiVmVjMiIsIkdyaWRUeXBlIiwiR3JpZCIsImNjY2xhc3MiLCJwcm9wZXJ0eSIsIkFTdGFyIiwidHlwZSIsImdyaWRzTHN0IiwiQXJyYXkiLCJwYXRoIiwib3BlbkxzdCIsImNsb3NlTHN0IiwibWFwIiwiZ3JpZFciLCJncmlkSCIsIm1hcEgiLCJtYXBXIiwiaXM4ZGlyIiwib24iLCJUT1VDSF9TVEFSVCIsIk9uVG91Y2hTdGFydCIsIlRPVUNIX01PVkUiLCJPblRvdWNoTW92ZSIsIk9uVG91Y2hFbmQiLCJJbml0TWFwIiwiZXZlbnQiLCJwb3MiLCJnZXRMb2NhdGlvbiIsIngiLCJNYXRoIiwiZmxvb3IiLCJ5IiwiTm9ybWFsIiwiQmFycmllciIsIkRyYXciLCJDWUFOIiwiRmluZFBhdGgiLCJjb2wiLCJsZW5ndGgiLCJjb25zb2xlIiwibG9nIiwiY2xlYXIiLCJyb3ciLCJXSElURSIsIkFkZEdyaWQiLCJzdGFydFgiLCJzdGFydFkiLCJlbmRYIiwiZW5kWSIsIlN0YXJ0IiwiTUFHRU5UQSIsIkVuZCIsIkJMVUUiLCJncmlkIiwiZiIsInB1c2giLCJwYXJlbnQiLCJpIiwiR1JFRU4iLCJzdGFydFBvcyIsImVuZFBvcyIsInN0YXJ0R3JpZCIsImVuZEdyaWQiLCJjdXJHcmlkIiwiR2VuZXJhdGVQYXRoIiwiaiIsImluZGV4T2YiLCJhYnMiLCJnIiwicGFyc2VJbnQiLCJzcXJ0IiwicG93IiwidG9TdHJpbmciLCJoIiwic3BsaWNlIiwic29ydCIsIlNvcnRGdW5jIiwiY29sb3IiLCJ1bmRlZmluZWQiLCJHUkFZIiwiZmlsbENvbG9yIiwicG9zWCIsInBvc1kiLCJmaWxsUmVjdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQVNBLE1BQUFBLFUsT0FBQUEsVTtBQUFZQyxNQUFBQSxTLE9BQUFBLFM7QUFBV0MsTUFBQUEsSSxPQUFBQSxJO0FBQWdCQyxNQUFBQSxpQixPQUFBQSxpQjtBQUFtQkMsTUFBQUEsVyxPQUFBQSxXO0FBQTBCQyxNQUFBQSxlLE9BQUFBLGU7QUFBaUJDLE1BQUFBLEssT0FBQUEsSztBQUFPQyxNQUFBQSxJLE9BQUFBLEk7Ozs7QUFDNUdDLE1BQUFBLFEsV0FBQUEsUTtBQUFVQyxNQUFBQSxJLFdBQUFBLEk7Ozs7OztBQUNYQyxNQUFBQSxPLEdBQXNCVixVLENBQXRCVSxPO0FBQVNDLE1BQUFBLFEsR0FBYVgsVSxDQUFiVyxROzt1QkFHSkMsSyxXQURaRixPQUFPLENBQUMsT0FBRCxDLFVBSUhDLFFBQVEsQ0FBQztBQUFFRSxRQUFBQSxJQUFJLEVBQUVYO0FBQVIsT0FBRCxDLFVBR1JTLFFBQVEsQ0FBQztBQUFFRSxRQUFBQSxJQUFJLEVBQUVWO0FBQVIsT0FBRCxDOzs7QUErQlQ7Ozs7QUFLQTs7OztBQUtBOzs7O0FBS0E7OztBQU9BLHlCQUFjO0FBQUE7O0FBQUE7O0FBQ1Y7O0FBRFU7O0FBQUE7O0FBQUEsZ0JBbkJQVyxRQW1CTyxHQW5Cd0IsSUFBSUMsS0FBSixFQW1CeEI7QUFBQSxnQkFkUEMsSUFjTyxHQWRhLElBY2I7QUFBQSxnQkFUUEMsT0FTTyxHQVRnQixJQVNoQjtBQUFBLGdCQUpQQyxRQUlPLEdBSmlCLElBSWpCO0FBRVYsZ0JBQUtDLEdBQUw7QUFGVTtBQUdiOzs7O21DQUdRO0FBRUwsaUJBQUtDLEtBQUwsR0FBYSxFQUFiO0FBQ0EsaUJBQUtDLEtBQUwsR0FBYSxFQUFiO0FBQ0EsaUJBQUtDLElBQUwsR0FBWSxFQUFaO0FBQ0EsaUJBQUtDLElBQUwsR0FBWSxFQUFaO0FBRUEsaUJBQUtDLE1BQUwsR0FBYyxJQUFkO0FBRUFwQixZQUFBQSxXQUFXLENBQUNxQixFQUFaLENBQWVwQixlQUFlLENBQUNxQixXQUEvQixFQUE0QyxLQUFLQyxZQUFqRCxFQUErRCxJQUEvRDtBQUNBdkIsWUFBQUEsV0FBVyxDQUFDcUIsRUFBWixDQUFlcEIsZUFBZSxDQUFDdUIsVUFBL0IsRUFBMkMsS0FBS0MsV0FBaEQsRUFBNkQsSUFBN0Q7QUFDQXpCLFlBQUFBLFdBQVcsQ0FBQ3FCLEVBQVosQ0FBZXBCLGVBQWUsQ0FBQ3FCLFdBQS9CLEVBQTRDLEtBQUtJLFVBQWpELEVBQTZELElBQTdELEVBWEssQ0FjTDtBQUNBO0FBRUE7O0FBQ0EsaUJBQUtDLE9BQUw7QUFDSDtBQUdEOzs7Ozs7eUNBR3VCLENBRXRCLEMsQ0FERzs7QUFHSjs7Ozs7O3NDQUdvQkMsSyxFQUFPO0FBQ3ZCLGdCQUFJQyxHQUFHLEdBQUdELEtBQUssQ0FBQ0UsV0FBTixFQUFWO0FBQ0EsZ0JBQUlDLENBQUMsR0FBR0MsSUFBSSxDQUFDQyxLQUFMLENBQVdKLEdBQUcsQ0FBQ0UsQ0FBSixJQUFTLEtBQUtmLEtBQUwsR0FBYSxDQUF0QixDQUFYLENBQVI7QUFDQSxnQkFBSWtCLENBQUMsR0FBR0YsSUFBSSxDQUFDQyxLQUFMLENBQVdKLEdBQUcsQ0FBQ0ssQ0FBSixJQUFTLEtBQUtqQixLQUFMLEdBQWEsQ0FBdEIsQ0FBWCxDQUFSOztBQUNBLGdCQUFJLEtBQUtQLFFBQUwsQ0FBY3FCLENBQWQsRUFBaUJHLENBQWpCLEVBQW9CekIsSUFBcEIsSUFBNEI7QUFBQTtBQUFBLHNDQUFTMEIsTUFBekMsRUFBaUQ7QUFDN0MsbUJBQUt6QixRQUFMLENBQWNxQixDQUFkLEVBQWlCRyxDQUFqQixFQUFvQnpCLElBQXBCLEdBQTJCO0FBQUE7QUFBQSx3Q0FBUzJCLE9BQXBDO0FBQ0EsbUJBQUtDLElBQUwsQ0FBVU4sQ0FBVixFQUFhRyxDQUFiLEVBQWdCaEMsS0FBSyxDQUFDb0MsSUFBdEI7QUFDSDtBQUNKO0FBRUQ7Ozs7Ozt1Q0FHcUI7QUFDakI7QUFDQSxpQkFBS0MsUUFBTCxDQUFjLElBQUlwQyxJQUFKLENBQVMsQ0FBVCxFQUFZLENBQVosQ0FBZCxFQUE4QixJQUFJQSxJQUFKLENBQVMsRUFBVCxFQUFhLENBQWIsQ0FBOUI7QUFDSDtBQUdEOzs7Ozs7b0NBR2lCO0FBQ2IsaUJBQUtVLE9BQUwsR0FBZSxJQUFJRixLQUFKLEVBQWY7QUFDQSxpQkFBS0csUUFBTCxHQUFnQixJQUFJSCxLQUFKLEVBQWhCO0FBQ0EsaUJBQUtDLElBQUwsR0FBWSxJQUFJRCxLQUFKLEVBQVosQ0FIYSxDQUliOztBQUNBLGlCQUFLRCxRQUFMLEdBQWdCLElBQUlDLEtBQUosQ0FBVSxLQUFLUSxJQUFMLEdBQVksQ0FBdEIsQ0FBaEI7O0FBQ0EsaUJBQUssSUFBSXFCLEdBQUcsR0FBRyxDQUFmLEVBQWtCQSxHQUFHLEdBQUcsS0FBSzlCLFFBQUwsQ0FBYytCLE1BQXRDLEVBQThDRCxHQUFHLEVBQWpELEVBQXFEO0FBQ2pELG1CQUFLOUIsUUFBTCxDQUFjOEIsR0FBZCxJQUFxQixJQUFJN0IsS0FBSixDQUFVLEtBQUtPLElBQUwsR0FBWSxDQUF0QixDQUFyQjtBQUNIOztBQUVEd0IsWUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksY0FBYyxLQUFLNUIsR0FBL0I7QUFFQSxpQkFBS0EsR0FBTCxDQUFTNkIsS0FBVDs7QUFFQSxpQkFBSyxJQUFJSixJQUFHLEdBQUcsQ0FBZixFQUFrQkEsSUFBRyxJQUFJLEtBQUtyQixJQUE5QixFQUFvQ3FCLElBQUcsRUFBdkMsRUFBMkM7QUFDdkMsbUJBQUssSUFBSUssR0FBRyxHQUFHLENBQWYsRUFBa0JBLEdBQUcsSUFBSSxLQUFLM0IsSUFBOUIsRUFBb0MyQixHQUFHLEVBQXZDLEVBQTJDO0FBQ3ZDLHFCQUFLUixJQUFMLENBQVVHLElBQVYsRUFBZUssR0FBZixFQUFvQjNDLEtBQUssQ0FBQzRDLEtBQTFCO0FBQ0EscUJBQUtDLE9BQUwsQ0FBYVAsSUFBYixFQUFrQkssR0FBbEIsRUFBdUI7QUFBQTtBQUFBLDBDQUFTVixNQUFoQztBQUNIO0FBQ0osYUFuQlksQ0FxQmI7OztBQUNBLGdCQUFJYSxNQUFNLEdBQUcsQ0FBYjtBQUNBLGdCQUFJQyxNQUFNLEdBQUcsQ0FBYjtBQUNBLGdCQUFJQyxJQUFJLEdBQUcsRUFBWDtBQUNBLGdCQUFJQyxJQUFJLEdBQUcsQ0FBWDtBQUNBLGlCQUFLekMsUUFBTCxDQUFjc0MsTUFBZCxFQUFzQkMsTUFBdEIsRUFBOEJ4QyxJQUE5QixHQUFxQztBQUFBO0FBQUEsc0NBQVMyQyxLQUE5QztBQUNBLGlCQUFLZixJQUFMLENBQVVXLE1BQVYsRUFBa0JDLE1BQWxCLEVBQTBCL0MsS0FBSyxDQUFDbUQsT0FBaEM7QUFFQSxpQkFBSzNDLFFBQUwsQ0FBY3dDLElBQWQsRUFBb0JDLElBQXBCLEVBQTBCMUMsSUFBMUIsR0FBaUM7QUFBQTtBQUFBLHNDQUFTNkMsR0FBMUM7QUFDQSxpQkFBS2pCLElBQUwsQ0FBVWEsSUFBVixFQUFnQkMsSUFBaEIsRUFBc0JqRCxLQUFLLENBQUNxRCxJQUE1QjtBQUNIO0FBRUQ7Ozs7Ozs7OztrQ0FNZXhCLEMsRUFBV0csQyxFQUFXekIsSSxFQUFnQjtBQUVqRCxnQkFBSStDLElBQVUsR0FBRztBQUFBO0FBQUEsK0JBQWpCO0FBQ0FBLFlBQUFBLElBQUksQ0FBQ3pCLENBQUwsR0FBU0EsQ0FBVDtBQUNBeUIsWUFBQUEsSUFBSSxDQUFDdEIsQ0FBTCxHQUFTQSxDQUFUO0FBQ0FzQixZQUFBQSxJQUFJLENBQUMvQyxJQUFMLEdBQVlBLElBQVo7QUFDQSxpQkFBS0MsUUFBTCxDQUFjcUIsQ0FBZCxFQUFpQkcsQ0FBakIsSUFBc0JzQixJQUF0QjtBQUNIO0FBRUQ7Ozs7Ozs7O21DQUtpQnpCLEMsRUFBU0csQyxFQUFTO0FBQy9CLG1CQUFPSCxDQUFDLENBQUMwQixDQUFGLEdBQU12QixDQUFDLENBQUN1QixDQUFmO0FBQ0g7QUFHRDs7Ozs7Ozt1Q0FJcUJELEksRUFBWTtBQUM3QixpQkFBSzVDLElBQUwsQ0FBVThDLElBQVYsQ0FBZUYsSUFBZjs7QUFDQSxtQkFBT0EsSUFBSSxDQUFDRyxNQUFaLEVBQW9CO0FBQ2hCSCxjQUFBQSxJQUFJLEdBQUdBLElBQUksQ0FBQ0csTUFBWjtBQUNBLG1CQUFLL0MsSUFBTCxDQUFVOEMsSUFBVixDQUFlRixJQUFmO0FBQ0g7O0FBQ0RkLFlBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGtCQUFrQixLQUFLL0IsSUFBTCxDQUFVNkIsTUFBeEM7O0FBQ0EsaUJBQUssSUFBSW1CLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUcsS0FBS2hELElBQUwsQ0FBVTZCLE1BQTlCLEVBQXNDbUIsQ0FBQyxFQUF2QyxFQUEyQztBQUN2QztBQUNBLGtCQUFJQSxDQUFDLElBQUksQ0FBTCxJQUFVQSxDQUFDLElBQUksS0FBS2hELElBQUwsQ0FBVTZCLE1BQVYsR0FBbUIsQ0FBdEMsRUFBeUM7QUFDckMsb0JBQUllLEtBQUksR0FBRyxLQUFLNUMsSUFBTCxDQUFVZ0QsQ0FBVixDQUFYO0FBQ0EscUJBQUt2QixJQUFMLENBQVVtQixLQUFJLENBQUN6QixDQUFmLEVBQWtCeUIsS0FBSSxDQUFDdEIsQ0FBdkIsRUFBMEJoQyxLQUFLLENBQUMyRCxLQUFoQztBQUNIO0FBQ0o7QUFDSjtBQUdEOzs7Ozs7OzttQ0FLaUJDLFEsRUFBZ0JDLE0sRUFBYztBQUczQztBQUNBO0FBQ0E7QUFDQSxnQkFBSUQsUUFBUSxDQUFDL0IsQ0FBVCxHQUFhLENBQWIsSUFBa0IrQixRQUFRLENBQUMvQixDQUFULElBQWMsS0FBS1osSUFBckMsSUFDRzJDLFFBQVEsQ0FBQzVCLENBQVQsR0FBYSxDQURoQixJQUNxQjRCLFFBQVEsQ0FBQzVCLENBQVQsSUFBYyxLQUFLaEIsSUFEeEMsSUFFRzZDLE1BQU0sQ0FBQ2hDLENBQVAsR0FBVyxDQUZkLElBRW1CZ0MsTUFBTSxDQUFDN0IsQ0FBUCxJQUFZLEtBQUtoQixJQUZ4QyxFQUU4QztBQUMxQ3dCLGNBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGlCQUFaO0FBQ0E7QUFDSCxhQUxELE1BTUs7QUFFRDtBQUNBO0FBQ0Esa0JBQUlxQixTQUFlLEdBQUcsS0FBS3RELFFBQUwsQ0FBY29ELFFBQVEsQ0FBQy9CLENBQXZCLEVBQTBCK0IsUUFBUSxDQUFDNUIsQ0FBbkMsQ0FBdEI7QUFDQSxrQkFBSStCLE9BQWEsR0FBRyxLQUFLdkQsUUFBTCxDQUFjcUQsTUFBTSxDQUFDaEMsQ0FBckIsRUFBd0JnQyxNQUFNLENBQUM3QixDQUEvQixDQUFwQjtBQUVBLG1CQUFLckIsT0FBTCxDQUFhNkMsSUFBYixDQUFrQk0sU0FBbEI7QUFDQSxrQkFBSUUsT0FBYSxHQUFHLEtBQUtyRCxPQUFMLENBQWEsQ0FBYixDQUFwQjs7QUFDQSxxQkFBTyxLQUFLQSxPQUFMLENBQWE0QixNQUFiLEdBQXNCLENBQXRCLElBQTJCeUIsT0FBTyxDQUFDekQsSUFBUixJQUFnQjtBQUFBO0FBQUEsd0NBQVMyQyxLQUEzRCxFQUFrRTtBQUM5RDtBQUNBYyxnQkFBQUEsT0FBTyxHQUFHLEtBQUtyRCxPQUFMLENBQWEsQ0FBYixDQUFWOztBQUNBLG9CQUFJcUQsT0FBTyxDQUFDekQsSUFBUixJQUFnQjtBQUFBO0FBQUEsMENBQVMyQyxLQUE3QixFQUFvQztBQUNoQ1Ysa0JBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLG9CQUFaO0FBQ0EsdUJBQUt3QixZQUFMLENBQWtCRCxPQUFsQjtBQUNBO0FBQ0g7O0FBRUQscUJBQUssSUFBSU4sQ0FBQyxHQUFHLENBQUMsQ0FBZCxFQUFpQkEsQ0FBQyxJQUFJLENBQXRCLEVBQXlCQSxDQUFDLEVBQTFCLEVBQThCO0FBQzFCLHVCQUFLLElBQUlRLENBQUMsR0FBRyxDQUFDLENBQWQsRUFBaUJBLENBQUMsSUFBSSxDQUF0QixFQUF5QkEsQ0FBQyxFQUExQixFQUE4QjtBQUMxQix3QkFBSVIsQ0FBQyxJQUFJLENBQUwsSUFBVVEsQ0FBQyxJQUFJLENBQW5CLEVBQXNCO0FBQ2xCLDBCQUFJNUIsR0FBRyxHQUFHMEIsT0FBTyxDQUFDbkMsQ0FBUixHQUFZNkIsQ0FBdEI7QUFDQSwwQkFBSWYsR0FBRyxHQUFHcUIsT0FBTyxDQUFDaEMsQ0FBUixHQUFZa0MsQ0FBdEI7O0FBQ0EsMEJBQUk1QixHQUFHLElBQUksQ0FBUCxJQUFZSyxHQUFHLElBQUksQ0FBbkIsSUFBd0JMLEdBQUcsSUFBSSxLQUFLckIsSUFBcEMsSUFBNEMwQixHQUFHLElBQUksS0FBSzNCLElBQXhELElBQ0csS0FBS1IsUUFBTCxDQUFjOEIsR0FBZCxFQUFtQkssR0FBbkIsRUFBd0JwQyxJQUF4QixJQUFnQztBQUFBO0FBQUEsZ0RBQVMyQixPQUQ1QyxJQUVHLEtBQUt0QixRQUFMLENBQWN1RCxPQUFkLENBQXNCLEtBQUszRCxRQUFMLENBQWM4QixHQUFkLEVBQW1CSyxHQUFuQixDQUF0QixJQUFpRCxDQUZ4RCxFQUUyRDtBQUN2RCw0QkFBSSxLQUFLekIsTUFBVCxFQUFpQjtBQUNiO0FBQ0EsOEJBQUksS0FBS1YsUUFBTCxDQUFjOEIsR0FBRyxHQUFHb0IsQ0FBcEIsRUFBdUJmLEdBQXZCLEVBQTRCcEMsSUFBNUIsSUFBb0M7QUFBQTtBQUFBLG9EQUFTMkIsT0FBN0MsSUFBd0QsS0FBSzFCLFFBQUwsQ0FBYzhCLEdBQWQsRUFBbUJLLEdBQUcsR0FBR3VCLENBQXpCLEVBQTRCM0QsSUFBNUIsSUFBb0M7QUFBQTtBQUFBLG9EQUFTMkIsT0FBekcsRUFBa0g7QUFDOUc7QUFDSDtBQUNKLHlCQUxELE1BS087QUFDSDtBQUNBLDhCQUFJSixJQUFJLENBQUNzQyxHQUFMLENBQVNWLENBQVQsS0FBZTVCLElBQUksQ0FBQ3NDLEdBQUwsQ0FBU0YsQ0FBVCxDQUFuQixFQUFnQztBQUM1QjtBQUNIO0FBQ0oseUJBWHNELENBYXZEOzs7QUFDQSw0QkFBSUcsQ0FBQyxHQUFHTCxPQUFPLENBQUNLLENBQVIsR0FBWUMsUUFBUSxDQUFDeEMsSUFBSSxDQUFDeUMsSUFBTCxDQUFVekMsSUFBSSxDQUFDMEMsR0FBTCxDQUFTZCxDQUFDLEdBQUcsRUFBYixFQUFpQixDQUFqQixJQUFzQjVCLElBQUksQ0FBQzBDLEdBQUwsQ0FBU04sQ0FBQyxHQUFHLEVBQWIsRUFBaUIsQ0FBakIsQ0FBaEMsRUFBcURPLFFBQXJELEVBQUQsQ0FBNUI7O0FBQ0EsNEJBQUksS0FBS2pFLFFBQUwsQ0FBYzhCLEdBQWQsRUFBbUJLLEdBQW5CLEVBQXdCMEIsQ0FBeEIsSUFBNkIsQ0FBN0IsSUFBa0MsS0FBSzdELFFBQUwsQ0FBYzhCLEdBQWQsRUFBbUJLLEdBQW5CLEVBQXdCMEIsQ0FBeEIsR0FBNEJBLENBQWxFLEVBQXFFO0FBQ2pFLCtCQUFLN0QsUUFBTCxDQUFjOEIsR0FBZCxFQUFtQkssR0FBbkIsRUFBd0IwQixDQUF4QixHQUE0QkEsQ0FBNUIsQ0FEaUUsQ0FFakU7O0FBQ0EsK0JBQUs3RCxRQUFMLENBQWM4QixHQUFkLEVBQW1CSyxHQUFuQixFQUF3QmMsTUFBeEIsR0FBaUNPLE9BQWpDO0FBQ0gseUJBbkJzRCxDQW9CdkQ7OztBQUNBLDZCQUFLeEQsUUFBTCxDQUFjOEIsR0FBZCxFQUFtQkssR0FBbkIsRUFBd0IrQixDQUF4QixHQUE0QjVDLElBQUksQ0FBQ3NDLEdBQUwsQ0FBU1AsTUFBTSxDQUFDaEMsQ0FBUCxHQUFXUyxHQUFwQixJQUEyQlIsSUFBSSxDQUFDc0MsR0FBTCxDQUFTUCxNQUFNLENBQUM3QixDQUFQLEdBQVdXLEdBQXBCLENBQXZELENBckJ1RCxDQXNCdkQ7O0FBQ0EsNkJBQUtuQyxRQUFMLENBQWM4QixHQUFkLEVBQW1CSyxHQUFuQixFQUF3QlksQ0FBeEIsR0FBNEIsS0FBSy9DLFFBQUwsQ0FBYzhCLEdBQWQsRUFBbUJLLEdBQW5CLEVBQXdCMEIsQ0FBeEIsR0FBNEIsS0FBSzdELFFBQUwsQ0FBYzhCLEdBQWQsRUFBbUJLLEdBQW5CLEVBQXdCK0IsQ0FBaEYsQ0F2QnVELENBd0J2RDs7QUFDQSw0QkFBSSxLQUFLL0QsT0FBTCxDQUFhd0QsT0FBYixDQUFxQixLQUFLM0QsUUFBTCxDQUFjOEIsR0FBZCxFQUFtQkssR0FBbkIsQ0FBckIsSUFBZ0QsQ0FBcEQsRUFBdUQ7QUFDbkQsK0JBQUtoQyxPQUFMLENBQWE2QyxJQUFiLENBQWtCLEtBQUtoRCxRQUFMLENBQWM4QixHQUFkLEVBQW1CSyxHQUFuQixDQUFsQjtBQUNILHlCQTNCc0QsQ0E0QnZEO0FBQ0E7O0FBQ0g7QUFDSjtBQUNKO0FBQ0osaUJBakQ2RCxDQWtEOUQ7OztBQUNBLHFCQUFLL0IsUUFBTCxDQUFjNEMsSUFBZCxDQUFtQlEsT0FBbkIsRUFuRDhELENBb0Q5RDs7QUFDQSxxQkFBS3JELE9BQUwsQ0FBYWdFLE1BQWIsQ0FBb0IsS0FBS2hFLE9BQUwsQ0FBYXdELE9BQWIsQ0FBcUJILE9BQXJCLENBQXBCLEVBQW1ELENBQW5EOztBQUNBLG9CQUFJLEtBQUtyRCxPQUFMLENBQWE0QixNQUFiLElBQXVCLENBQTNCLEVBQThCO0FBQzFCQyxrQkFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksbUJBQVo7QUFDSCxpQkF4RDZELENBMEQ5RDs7O0FBQ0EscUJBQUs5QixPQUFMLENBQWFpRSxJQUFiLENBQWtCLEtBQUtDLFFBQXZCO0FBQ0g7QUFDSjtBQUNKO0FBRUQ7Ozs7Ozs7OzsrQkFNYXZDLEcsRUFBVUssRyxFQUFVbUMsSyxFQUFjO0FBRTNDQSxZQUFBQSxLQUFLLEdBQUdBLEtBQUssSUFBSUMsU0FBVCxHQUFxQkQsS0FBckIsR0FBNkI5RSxLQUFLLENBQUNnRixJQUEzQztBQUNBLGlCQUFLbkUsR0FBTCxDQUFTb0UsU0FBVCxHQUFxQkgsS0FBckI7QUFDQSxnQkFBSUksSUFBSSxHQUFHLElBQUk1QyxHQUFHLElBQUksS0FBS3hCLEtBQUwsR0FBYSxDQUFqQixDQUFsQjtBQUNBLGdCQUFJcUUsSUFBSSxHQUFHLElBQUl4QyxHQUFHLElBQUksS0FBSzVCLEtBQUwsR0FBYSxDQUFqQixDQUFsQjtBQUNBLGlCQUFLRixHQUFMLENBQVN1RSxRQUFULENBQWtCRixJQUFsQixFQUF3QkMsSUFBeEIsRUFBOEIsS0FBS3JFLEtBQW5DLEVBQTBDLEtBQUtDLEtBQS9DO0FBQ0g7Ozs7UUE3U3NCcEIsUzs7Ozs7aUJBSUQsSTs7Ozs7OztpQkFHVSxJIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgX2RlY29yYXRvciwgQ29tcG9uZW50LCBOb2RlLCBncmFwaGljcywgR3JhcGhpY3NDb21wb25lbnQsIHN5c3RlbUV2ZW50LCBTeXN0ZW1FdmVudCwgU3lzdGVtRXZlbnRUeXBlLCBDb2xvciwgVmVjMiB9IGZyb20gJ2NjJztcclxuaW1wb3J0IHsgR3JpZFR5cGUsIEdyaWQgfSBmcm9tICcuL0dyaWQnO1xyXG5jb25zdCB7IGNjY2xhc3MsIHByb3BlcnR5IH0gPSBfZGVjb3JhdG9yO1xyXG5cclxuQGNjY2xhc3MoJ0FTdGFyJylcclxuZXhwb3J0IGNsYXNzIEFTdGFyIGV4dGVuZHMgQ29tcG9uZW50IHtcclxuXHJcblxyXG4gICAgQHByb3BlcnR5KHsgdHlwZTogTm9kZSB9KVxyXG4gICAgcHVibGljIG1hcFBvczogTm9kZSA9IG51bGw7XHJcblxyXG4gICAgQHByb3BlcnR5KHsgdHlwZTogR3JhcGhpY3NDb21wb25lbnQgfSlcclxuICAgIHB1YmxpYyBtYXA6IEdyYXBoaWNzQ29tcG9uZW50ID0gbnVsbDtcclxuXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiDljZXlhYPmoLzlrZDnmoTlrr3luqZcclxuICAgICAqL1xyXG4gICAgcHVibGljIGdyaWRXOiBhbnk7XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICog5Y2V5YWD5qC85a2Q55qE6auY5bqmXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBncmlkSDogYW55O1xyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIOe6teWQkeagvOWtkOeahOaVsOmHj1xyXG4gICAgICovXHJcbiAgICBwdWJsaWMgbWFwSDogbnVtYmVyO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICog5qiq5ZCR5qC85a2Q55qE5pWw6YePXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBtYXBXOiBudW1iZXI7XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiDmmK/lkKblhavmlrnlkJHlr7vot69cclxuICAgICAqL1xyXG4gICAgcHVibGljIGlzOGRpcjogYm9vbGVhbjtcclxuXHJcbiAgICAvKipcclxuICAgICAqIOagvOWtkOWIl+ihqFxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgZ3JpZHNMc3Q6IEFycmF5PEFycmF5PEdyaWQ+PiA9IG5ldyBBcnJheTxBcnJheTxHcmlkPj4oKTtcclxuXHJcbiAgICAvKipcclxuICAgICAqIOi3r+W+hOaVsOe7hFxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgcGF0aDogQXJyYXk8R3JpZD4gPSBudWxsO1xyXG5cclxuICAgIC8qKlxyXG4gICAgICog5byA5ZCv5YiX6KGoXHJcbiAgICAgKi9cclxuICAgIHB1YmxpYyBvcGVuTHN0OiBBcnJheTxHcmlkPiA9IG51bGw7XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiDlhbPpl63liJfooahcclxuICAgICAqL1xyXG4gICAgcHVibGljIGNsb3NlTHN0OiBBcnJheTxHcmlkPiA9IG51bGw7XHJcblxyXG5cclxuXHJcbiAgICBjb25zdHJ1Y3RvcigpIHtcclxuICAgICAgICBzdXBlcigpO1xyXG4gICAgICAgIHRoaXMubWFwO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICBvbkxvYWQoKSB7XHJcblxyXG4gICAgICAgIHRoaXMuZ3JpZFcgPSA1MDtcclxuICAgICAgICB0aGlzLmdyaWRIID0gNTA7XHJcbiAgICAgICAgdGhpcy5tYXBIID0gMTU7XHJcbiAgICAgICAgdGhpcy5tYXBXID0gMjU7XHJcblxyXG4gICAgICAgIHRoaXMuaXM4ZGlyID0gdHJ1ZTtcclxuXHJcbiAgICAgICAgc3lzdGVtRXZlbnQub24oU3lzdGVtRXZlbnRUeXBlLlRPVUNIX1NUQVJULCB0aGlzLk9uVG91Y2hTdGFydCwgdGhpcyk7XHJcbiAgICAgICAgc3lzdGVtRXZlbnQub24oU3lzdGVtRXZlbnRUeXBlLlRPVUNIX01PVkUsIHRoaXMuT25Ub3VjaE1vdmUsIHRoaXMpO1xyXG4gICAgICAgIHN5c3RlbUV2ZW50Lm9uKFN5c3RlbUV2ZW50VHlwZS5UT1VDSF9TVEFSVCwgdGhpcy5PblRvdWNoRW5kLCB0aGlzKTtcclxuXHJcblxyXG4gICAgICAgIC8v5Yid5aeL5YyWbWFwXHJcbiAgICAgICAgLy90aGlzLm1hcD10aGlzLm1hcFBvcy5nZXRDb21wb25lbnQ8R3JhcGhpY3NDb21wb25lbnQ+KCk7XHJcblxyXG4gICAgICAgIC8v5Yid5aeL5YyW5Zyw5Zu+XHJcbiAgICAgICAgdGhpcy5Jbml0TWFwKCk7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC8qKlxyXG4gICAgICog5b2T6Kem5pG45byA5aeL5pe2XHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgT25Ub3VjaFN0YXJ0KCkge1xyXG4gICAgICAgIC8vIHRoaXMuSW5pdE1hcCgpO1xyXG4gICAgfVxyXG5cclxuICAgIC8qKiBcclxuICAgICAqIOW9k+inpuaRuOaXtlxyXG4gICAgKi9cclxuICAgIHByaXZhdGUgT25Ub3VjaE1vdmUoZXZlbnQpIHtcclxuICAgICAgICBsZXQgcG9zID0gZXZlbnQuZ2V0TG9jYXRpb24oKTtcclxuICAgICAgICBsZXQgeCA9IE1hdGguZmxvb3IocG9zLnggLyAodGhpcy5ncmlkVyArIDIpKTtcclxuICAgICAgICBsZXQgeSA9IE1hdGguZmxvb3IocG9zLnkgLyAodGhpcy5ncmlkSCArIDIpKTtcclxuICAgICAgICBpZiAodGhpcy5ncmlkc0xzdFt4XVt5XS50eXBlID09IEdyaWRUeXBlLk5vcm1hbCkge1xyXG4gICAgICAgICAgICB0aGlzLmdyaWRzTHN0W3hdW3ldLnR5cGUgPSBHcmlkVHlwZS5CYXJyaWVyO1xyXG4gICAgICAgICAgICB0aGlzLkRyYXcoeCwgeSwgQ29sb3IuQ1lBTik7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICog5b2T6Kem5pG457uT5p2f5pe2XHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgT25Ub3VjaEVuZCgpIHtcclxuICAgICAgICAvLyDlvIDlp4vlr7vot69cclxuICAgICAgICB0aGlzLkZpbmRQYXRoKG5ldyBWZWMyKDEsIDIpLCBuZXcgVmVjMigxNiwgMykpO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIOWIneWni+WMluWcsOWbvlxyXG4gICAgICovXHJcbiAgICBwdWJsaWMgSW5pdE1hcCgpIHtcclxuICAgICAgICB0aGlzLm9wZW5Mc3QgPSBuZXcgQXJyYXk8R3JpZD4oKTtcclxuICAgICAgICB0aGlzLmNsb3NlTHN0ID0gbmV3IEFycmF5PEdyaWQ+KCk7XHJcbiAgICAgICAgdGhpcy5wYXRoID0gbmV3IEFycmF5PEdyaWQ+KCk7XHJcbiAgICAgICAgLy8g5Yid5aeL5YyW5qC85a2Q5LqM57u05pWw57uEXHJcbiAgICAgICAgdGhpcy5ncmlkc0xzdCA9IG5ldyBBcnJheSh0aGlzLm1hcFcgKyAxKTtcclxuICAgICAgICBmb3IgKGxldCBjb2wgPSAwOyBjb2wgPCB0aGlzLmdyaWRzTHN0Lmxlbmd0aDsgY29sKyspIHtcclxuICAgICAgICAgICAgdGhpcy5ncmlkc0xzdFtjb2xdID0gbmV3IEFycmF5KHRoaXMubWFwSCArIDEpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc29sZS5sb2coXCJtYXAg5piv5ZCm5a2Y5Zyo77yaXCIgKyB0aGlzLm1hcCk7XHJcblxyXG4gICAgICAgIHRoaXMubWFwLmNsZWFyKCk7XHJcblxyXG4gICAgICAgIGZvciAobGV0IGNvbCA9IDA7IGNvbCA8PSB0aGlzLm1hcFc7IGNvbCsrKSB7XHJcbiAgICAgICAgICAgIGZvciAobGV0IHJvdyA9IDA7IHJvdyA8PSB0aGlzLm1hcEg7IHJvdysrKSB7XHJcbiAgICAgICAgICAgICAgICB0aGlzLkRyYXcoY29sLCByb3csIENvbG9yLldISVRFKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuQWRkR3JpZChjb2wsIHJvdywgR3JpZFR5cGUuTm9ybWFsKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8g6K6+572u6LW354K55ZKM57uI54K5XHJcbiAgICAgICAgbGV0IHN0YXJ0WCA9IDE7XHJcbiAgICAgICAgbGV0IHN0YXJ0WSA9IDI7XHJcbiAgICAgICAgbGV0IGVuZFggPSAxNjtcclxuICAgICAgICBsZXQgZW5kWSA9IDM7XHJcbiAgICAgICAgdGhpcy5ncmlkc0xzdFtzdGFydFhdW3N0YXJ0WV0udHlwZSA9IEdyaWRUeXBlLlN0YXJ0O1xyXG4gICAgICAgIHRoaXMuRHJhdyhzdGFydFgsIHN0YXJ0WSwgQ29sb3IuTUFHRU5UQSk7XHJcblxyXG4gICAgICAgIHRoaXMuZ3JpZHNMc3RbZW5kWF1bZW5kWV0udHlwZSA9IEdyaWRUeXBlLkVuZDtcclxuICAgICAgICB0aGlzLkRyYXcoZW5kWCwgZW5kWSwgQ29sb3IuQkxVRSk7XHJcbiAgICB9XHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiDmt7vliqDmoLzlrZBcclxuICAgICAqIEBwYXJhbSB4IOWIl1xyXG4gICAgICogQHBhcmFtIHkg6KGMXHJcbiAgICAgKiBAcGFyYW0gdHlwZSDmoLzlrZDnsbvlnotcclxuICAgICAqL1xyXG4gICAgcHVibGljIEFkZEdyaWQoeDogbnVtYmVyLCB5OiBudW1iZXIsIHR5cGU6IEdyaWRUeXBlKSB7XHJcblxyXG4gICAgICAgIGxldCBncmlkOiBHcmlkID0gbmV3IEdyaWQoKTtcclxuICAgICAgICBncmlkLnggPSB4O1xyXG4gICAgICAgIGdyaWQueSA9IHk7XHJcbiAgICAgICAgZ3JpZC50eXBlID0gdHlwZTtcclxuICAgICAgICB0aGlzLmdyaWRzTHN0W3hdW3ldID0gZ3JpZDtcclxuICAgIH1cclxuXHJcbiAgICAvKipcclxuICAgICAqIOaOkuW6j+aWueazlVxyXG4gICAgICogQHBhcmFtIHgg5qC85a2QMVxyXG4gICAgICogQHBhcmFtIHkg5qC85a2QMlxyXG4gICAgICovXHJcbiAgICBwcml2YXRlIFNvcnRGdW5jKHg6IEdyaWQsIHk6IEdyaWQpIHtcclxuICAgICAgICByZXR1cm4geC5mIC0geS5mO1xyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAqIOeUn+aIkOi3r+W+hFxyXG4gICAgICogQHBhcmFtIGdyaWQgXHJcbiAgICAgKi9cclxuICAgIHByaXZhdGUgR2VuZXJhdGVQYXRoKGdyaWQ6IEdyaWQpIHtcclxuICAgICAgICB0aGlzLnBhdGgucHVzaChncmlkKTtcclxuICAgICAgICB3aGlsZSAoZ3JpZC5wYXJlbnQpIHtcclxuICAgICAgICAgICAgZ3JpZCA9IGdyaWQucGFyZW50O1xyXG4gICAgICAgICAgICB0aGlzLnBhdGgucHVzaChncmlkKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJQYXRoLmxlbmd0aDogXCIgKyB0aGlzLnBhdGgubGVuZ3RoKTtcclxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRoaXMucGF0aC5sZW5ndGg7IGkrKykge1xyXG4gICAgICAgICAgICAvLyDotbfngrnnu4jngrnkuI3opobnm5bvvIzmlrnkvr/nnIvmlYjmnpxcclxuICAgICAgICAgICAgaWYgKGkgIT0gMCAmJiBpICE9IHRoaXMucGF0aC5sZW5ndGggLSAxKSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgZ3JpZCA9IHRoaXMucGF0aFtpXTtcclxuICAgICAgICAgICAgICAgIHRoaXMuRHJhdyhncmlkLngsIGdyaWQueSwgQ29sb3IuR1JFRU4pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuXHJcbiAgICAvKipcclxuICAgICAgKiDmib7liLDot6/lvoRcclxuICAgICAgKiBAcGFyYW0gc3RhcnRQb3Mg6LW354K5XHJcbiAgICAgICogQHBhcmFtIGVuZFBvcyDnu4jngrlcclxuICAgICAgKi9cclxuICAgIHByaXZhdGUgRmluZFBhdGgoc3RhcnRQb3M6IFZlYzIsIGVuZFBvczogVmVjMikge1xyXG5cclxuXHJcbiAgICAgICAgLy/pppblhYjliKTmlq0g5Lyg5YWl55qE5Lik5Liq54K5IOaYr+WQpuWQiOazlVxyXG4gICAgICAgIC8vMS7pppblhYgg6KaB5Zyo5Zyw5Zu+6IyD5Zu05YaFXHJcbiAgICAgICAgLy/lpoLmnpzkuI3lkIjms5Ug5bqU6K+l55u05o6lIOi/lOWbnm51bGwg5oSP5ZGz552A5LiN6IO95a+76LevXHJcbiAgICAgICAgaWYgKHN0YXJ0UG9zLnggPCAwIHx8IHN0YXJ0UG9zLnggPj0gdGhpcy5tYXBXXHJcbiAgICAgICAgICAgIHx8IHN0YXJ0UG9zLnkgPCAwIHx8IHN0YXJ0UG9zLnkgPj0gdGhpcy5tYXBIXHJcbiAgICAgICAgICAgIHx8IGVuZFBvcy54IDwgMCB8fCBlbmRQb3MueSA+PSB0aGlzLm1hcEgpIHtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCLlvIDlp4vmiJbogIXnu5PmnZ/ngrnlnKjlnLDlm77moLzlrZDojIPlm7TlpJZcIik7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgZWxzZSB7XHJcblxyXG4gICAgICAgICAgICAvL+imgeS4jeaYr+mYu+aMoVxyXG4gICAgICAgICAgICAvL+W+l+WIsOi1t+eCueWSjOe7iOeCuSDlr7nlupTnmoTmoLzlrZBcclxuICAgICAgICAgICAgbGV0IHN0YXJ0R3JpZDogR3JpZCA9IHRoaXMuZ3JpZHNMc3Rbc3RhcnRQb3MueF1bc3RhcnRQb3MueV07XHJcbiAgICAgICAgICAgIGxldCBlbmRHcmlkOiBHcmlkID0gdGhpcy5ncmlkc0xzdFtlbmRQb3MueF1bZW5kUG9zLnldO1xyXG5cclxuICAgICAgICAgICAgdGhpcy5vcGVuTHN0LnB1c2goc3RhcnRHcmlkKTtcclxuICAgICAgICAgICAgbGV0IGN1ckdyaWQ6IEdyaWQgPSB0aGlzLm9wZW5Mc3RbMF07XHJcbiAgICAgICAgICAgIHdoaWxlICh0aGlzLm9wZW5Mc3QubGVuZ3RoID4gMCAmJiBjdXJHcmlkLnR5cGUgIT0gR3JpZFR5cGUuU3RhcnQpIHtcclxuICAgICAgICAgICAgICAgIC8vIOavj+asoemDveWPluWHumblgLzmnIDlsI/nmoToioLngrnov5vooYzmn6Xmib5cclxuICAgICAgICAgICAgICAgIGN1ckdyaWQgPSB0aGlzLm9wZW5Mc3RbMF07XHJcbiAgICAgICAgICAgICAgICBpZiAoY3VyR3JpZC50eXBlID09IEdyaWRUeXBlLlN0YXJ0KSB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCJGaW5kIHBhdGggc3VjY2Vzcy5cIik7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5HZW5lcmF0ZVBhdGgoY3VyR3JpZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAtMTsgaSA8PSAxOyBpKyspIHtcclxuICAgICAgICAgICAgICAgICAgICBmb3IgKGxldCBqID0gLTE7IGogPD0gMTsgaisrKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpICE9IDAgfHwgaiAhPSAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgY29sID0gY3VyR3JpZC54ICsgaTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxldCByb3cgPSBjdXJHcmlkLnkgKyBqO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNvbCA+PSAwICYmIHJvdyA+PSAwICYmIGNvbCA8PSB0aGlzLm1hcFcgJiYgcm93IDw9IHRoaXMubWFwSFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICYmIHRoaXMuZ3JpZHNMc3RbY29sXVtyb3ddLnR5cGUgIT0gR3JpZFR5cGUuQmFycmllclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICYmIHRoaXMuY2xvc2VMc3QuaW5kZXhPZih0aGlzLmdyaWRzTHN0W2NvbF1bcm93XSkgPCAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuaXM4ZGlyKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIDjmlrnlkJEg5pac5ZCR6LWw5Yqo5pe26KaB6ICD6JmR55u46YK755qE5piv5LiN5piv6Zqc56KN54mpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmdyaWRzTHN0W2NvbCAtIGldW3Jvd10udHlwZSA9PSBHcmlkVHlwZS5CYXJyaWVyIHx8IHRoaXMuZ3JpZHNMc3RbY29sXVtyb3cgLSBqXS50eXBlID09IEdyaWRUeXBlLkJhcnJpZXIpIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8g5Zub5pa55b2i6KGM6LWwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChNYXRoLmFicyhpKSA9PSBNYXRoLmFicyhqKSkge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIOiuoeeul2flgLxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsZXQgZyA9IGN1ckdyaWQuZyArIHBhcnNlSW50KE1hdGguc3FydChNYXRoLnBvdyhpICogMTAsIDIpICsgTWF0aC5wb3coaiAqIDEwLCAyKSkudG9TdHJpbmcoKSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuZ3JpZHNMc3RbY29sXVtyb3ddLmcgPT0gMCB8fCB0aGlzLmdyaWRzTHN0W2NvbF1bcm93XS5nID4gZykge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmdyaWRzTHN0W2NvbF1bcm93XS5nID0gZztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8g5pu05paw54i26IqC54K5XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZ3JpZHNMc3RbY29sXVtyb3ddLnBhcmVudCA9IGN1ckdyaWQ7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIOiuoeeul2jlgLwgbWFuaGF0dGFu5Lyw566X5rOVXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5ncmlkc0xzdFtjb2xdW3Jvd10uaCA9IE1hdGguYWJzKGVuZFBvcy54IC0gY29sKSArIE1hdGguYWJzKGVuZFBvcy55IC0gcm93KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyDmm7TmlrBm5YC8XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5ncmlkc0xzdFtjb2xdW3Jvd10uZiA9IHRoaXMuZ3JpZHNMc3RbY29sXVtyb3ddLmcgKyB0aGlzLmdyaWRzTHN0W2NvbF1bcm93XS5oO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIOWmguaenOS4jeWcqOW8gOaUvuWIl+ihqOmHjOWImea3u+WKoOWIsOW8gOaUvuWIl+ihqOmHjFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLm9wZW5Mc3QuaW5kZXhPZih0aGlzLmdyaWRzTHN0W2NvbF1bcm93XSkgPCAwKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMub3BlbkxzdC5wdXNoKHRoaXMuZ3JpZHNMc3RbY29sXVtyb3ddKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gLy8g6YeN5paw5oyJ54WnZuWAvOaOkuW6j++8iOWNh+W6j+aOkuWIlylcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB0aGlzLm9wZW5MaXN0LnNvcnQodGhpcy5fc29ydEZ1bmMpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy8g6YGN5Y6G5a6M5Zub5ZGo6IqC54K55ZCO5oqK5b2T5YmN6IqC54K55Yqg5YWl5YWz6Zet5YiX6KGoXHJcbiAgICAgICAgICAgICAgICB0aGlzLmNsb3NlTHN0LnB1c2goY3VyR3JpZCk7XHJcbiAgICAgICAgICAgICAgICAvLyDku47lvIDmlL7liJfooajmiorlvZPliY3oioLngrnnp7vpmaRcclxuICAgICAgICAgICAgICAgIHRoaXMub3BlbkxzdC5zcGxpY2UodGhpcy5vcGVuTHN0LmluZGV4T2YoY3VyR3JpZCksIDEpO1xyXG4gICAgICAgICAgICAgICAgaWYgKHRoaXMub3BlbkxzdC5sZW5ndGggPD0gMCkge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiRmluZCBwYXRoIGZhaWxlZC5cIik7XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgLy8g6YeN5paw5oyJ54WnZuWAvOaOkuW6j++8iOWNh+W6j+aOkuWIlylcclxuICAgICAgICAgICAgICAgIHRoaXMub3BlbkxzdC5zb3J0KHRoaXMuU29ydEZ1bmMpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8qKlxyXG4gICAgICog5YiS57q/XHJcbiAgICAgKiBAcGFyYW0gY29sIOWIl1xyXG4gICAgICogQHBhcmFtIHJvdyDooYxcclxuICAgICAqIEBwYXJhbSBjb2xvciDpopzoibJcclxuICAgICAqL1xyXG4gICAgcHJpdmF0ZSBEcmF3KGNvbDogYW55LCByb3c6IGFueSwgY29sb3I6IENvbG9yKSB7XHJcbiAgICAgIFxyXG4gICAgICAgIGNvbG9yID0gY29sb3IgIT0gdW5kZWZpbmVkID8gY29sb3IgOiBDb2xvci5HUkFZO1xyXG4gICAgICAgIHRoaXMubWFwLmZpbGxDb2xvciA9IGNvbG9yO1xyXG4gICAgICAgIGxldCBwb3NYID0gMiArIGNvbCAqICh0aGlzLmdyaWRXICsgMik7XHJcbiAgICAgICAgbGV0IHBvc1kgPSAyICsgcm93ICogKHRoaXMuZ3JpZEggKyAyKTtcclxuICAgICAgICB0aGlzLm1hcC5maWxsUmVjdChwb3NYLCBwb3NZLCB0aGlzLmdyaWRXLCB0aGlzLmdyaWRIKTtcclxuICAgIH1cclxuXHJcbiAgXHJcbn1cclxuIl19