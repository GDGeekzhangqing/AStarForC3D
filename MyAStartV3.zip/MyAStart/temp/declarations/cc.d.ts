/// <reference path="E:\CocosCreator3D-v1.1.0-win32-041716\resources\resources\3d\engine\bin\.declarations\cc.d.ts"/>
